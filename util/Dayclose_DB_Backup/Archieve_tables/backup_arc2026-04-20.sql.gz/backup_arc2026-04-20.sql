-- Generation time: Mon, 20 Apr 2026 11:31:00 +0530
-- Host: 192.168.0.49
-- DB name: exposvn
/*!40030 SET NAMES UTF8 */;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

SET FOREIGN_KEY_CHECKS = 0;DROP TABLE IF EXISTS `tbl_account_settings`;
CREATE TABLE `tbl_account_settings` (
  `tas_profit` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tas_loss` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`tas_profit`,`tas_loss`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_account_stock`;
CREATE TABLE `tbl_account_stock` (
  `tas_id` int(11) NOT NULL AUTO_INCREMENT,
  `tas_date` date NOT NULL,
  `tas_open_stock_value` decimal(15,3) DEFAULT '0.000',
  `tas_close_stock_value` decimal(15,3) DEFAULT '0.000',
  `tas_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`tas_id`),
  UNIQUE KEY `tas_date` (`tas_date`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_accounthead`;
CREATE TABLE `tbl_accounthead` (
  `ac_accountid` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `ac_accountname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ac_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ac_accountid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_advance_day_detail`;
CREATE TABLE `tbl_advance_day_detail` (
  `tdd_id` int(11) NOT NULL AUTO_INCREMENT,
  `tdd_ref_id` int(11) DEFAULT NULL,
  `tdd_advance_amount` decimal(15,3) DEFAULT NULL,
  `tdd_dayclose_date` date DEFAULT NULL,
  `tdd_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tdd_pay_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tdd_bank` int(11) DEFAULT NULL,
  PRIMARY KEY (`tdd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_advance_pay_menu_details`;
CREATE TABLE `tbl_advance_pay_menu_details` (
  `tmd_id` int(11) NOT NULL AUTO_INCREMENT,
  `tmd_ref_id` int(11) DEFAULT NULL,
  `tmd_menu` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmd_qty` float DEFAULT NULL,
  `tmd_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmd_rate` decimal(15,3) DEFAULT NULL,
  `tmd_total` decimal(15,3) DEFAULT NULL,
  `tmd_description` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmd_weight` decimal(15,3) DEFAULT NULL,
  `tmd_total_weight` decimal(15,3) DEFAULT NULL,
  `tmd_menuid` int(11) DEFAULT NULL,
  `tmd_billed` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`tmd_id`),
  UNIQUE KEY `tmd_ref_id` (`tmd_ref_id`,`tmd_menu`,`tmd_weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_advance_payment`;
CREATE TABLE `tbl_advance_payment` (
  `tp_id` int(11) NOT NULL AUTO_INCREMENT,
  `tp_amount` decimal(15,3) DEFAULT NULL,
  `tp_delivery_date` date DEFAULT NULL,
  `tp_delivery_note` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_customer` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_mode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_dayclose` date DEFAULT NULL,
  `tp_delivery_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tp_status` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_cancel_date` datetime DEFAULT NULL,
  `tp_cancel_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_subtotal` decimal(15,3) DEFAULT '0.000',
  `tp_tax` decimal(15,3) DEFAULT '0.000',
  `tp_final` decimal(15,3) DEFAULT '0.000',
  `tp_delivery_charge` decimal(15,3) DEFAULT NULL,
  `tp_mail` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_bank` int(11) DEFAULT NULL,
  `tp_cs_bill` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_amc_setup`;
CREATE TABLE `tbl_amc_setup` (
  `tmc_id` int(11) NOT NULL AUTO_INCREMENT,
  `tm_from` date DEFAULT NULL,
  `tm_to` date DEFAULT NULL,
  `tm_add_by` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tm_entry_time` datetime DEFAULT NULL,
  `tm_pay_type` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_added` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tm_ref_id_client` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tm_install_on` date DEFAULT NULL,
  `tm_cloud_active` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tm_cloud_expiry` date DEFAULT NULL,
  `tm_amc_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tm_cloud_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tmc_tax` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`tmc_id`),
  UNIQUE KEY `tm_to` (`tm_to`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_amc_setup` VALUES ('62','2020-11-23','2027-03-27','CRM','2026-04-20 11:30:09','RENEW','N','N','57','2020-11-23','N',NULL,'1.000','0.000','0.180'); 


DROP TABLE IF EXISTS `tbl_app_permissions`;
CREATE TABLE `tbl_app_permissions` (
  `tap_id` int(11) NOT NULL AUTO_INCREMENT,
  `tap_staffname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tap_staff_id` int(11) NOT NULL,
  `tap_app_login` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_dinein_module` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_tahd_module` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_cs_module` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_item_cancel` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_bill_cancel` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_table_change` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_bill_reprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_settle_dinein` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_settle_ta_hd` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_settle_cs` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_shift` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tap_discount` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_regenerate` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_complimentary` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_tip` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_hold` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_enable_type` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tap_all_settle` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tap_id`),
  UNIQUE KEY `tap_staff_id` (`tap_staff_id`),
  UNIQUE KEY `tap_staff_id_2` (`tap_staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_appmachinedetails`;
CREATE TABLE `tbl_appmachinedetails` (
  `as_appmachineid` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `as_appmachiesych` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_appmachiesychid` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `as_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `as_lastupdated` datetime DEFAULT NULL,
  `as_cur_ver` int(11) DEFAULT NULL,
  `as_new_ver` int(11) DEFAULT NULL,
  `as_update_found` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_em_lastupdated` datetime DEFAULT NULL,
  `as_em_cur_ver` int(11) DEFAULT NULL,
  `as_em_new_ver` int(11) DEFAULT NULL,
  `as_em_update_found` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_enable_cash_drawer` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_cash_drawer_ip` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `as_cash_drawer_port` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `as_cash_drawer_usb` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_floormaster` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_kotcounter` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_prefemaster` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_menumaincat` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_menusubcat` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_portionmas` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_menumaster` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_menuprefemaster` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_menuratemaster` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_counterrate` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_menustock` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_menuimage` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_menucombination` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_nutrition` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `as_sync_ingredient` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`as_appmachineid`),
  UNIQUE KEY `as_appmachiesychid` (`as_appmachiesychid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_archive_settings`;
CREATE TABLE `tbl_archive_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clear_tables` text COLLATE utf8_unicode_ci,
  `archive_db` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archive_enabled` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `all_time_sync_tables` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_archive_settings_log`;
CREATE TABLE `tbl_archive_settings_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_asset_category`;
CREATE TABLE `tbl_asset_category` (
  `tsc_id` int(11) NOT NULL AUTO_INCREMENT,
  `tsc_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tsc_order` int(11) DEFAULT NULL,
  `tsc_status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tsc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_asset_invoice_tax_details`;
CREATE TABLE `tbl_asset_invoice_tax_details` (
  `txd_id` int(11) NOT NULL AUTO_INCREMENT,
  `txd_tax_name` int(11) DEFAULT NULL,
  `txd_value` decimal(15,3) DEFAULT NULL,
  `txd_inclusive` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `txd_status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `txd_invoice` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `txd_vendor` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `txd_date` date DEFAULT NULL,
  PRIMARY KEY (`txd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_asset_master`;
CREATE TABLE `tbl_asset_master` (
  `tam_id` int(11) NOT NULL AUTO_INCREMENT,
  `tam_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tam_asset_category` int(11) DEFAULT NULL,
  `tam_status` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tam_depriciation` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tam_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_asset_purchase`;
CREATE TABLE `tbl_asset_purchase` (
  `tap_id` int(11) NOT NULL AUTO_INCREMENT,
  `tap_vendor_id` int(11) DEFAULT NULL,
  `tap_date` date DEFAULT NULL,
  `tap_invoice_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tap_asset_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tap_qty` int(11) DEFAULT NULL,
  `tap_unit_rate` decimal(15,3) DEFAULT NULL,
  `tap_total` decimal(15,3) DEFAULT NULL,
  `tap_status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tap_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_asset_purchase_invoice_detail`;
CREATE TABLE `tbl_asset_purchase_invoice_detail` (
  `tpd_id` int(11) NOT NULL AUTO_INCREMENT,
  `tpd_invoice` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpd_vendor` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpd_date` date DEFAULT NULL,
  `tpd_subtotal` decimal(15,3) DEFAULT NULL,
  `tpd_tax_total` decimal(15,3) DEFAULT NULL,
  `tpd_netamount` decimal(15,3) DEFAULT NULL,
  `tpd_from_acc` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpd_paid_amount` decimal(15,3) DEFAULT NULL,
  `tpd_credit_amount` decimal(15,3) DEFAULT NULL,
  `tpd_trn_detail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpd_remarks` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpd_entry_date` date DEFAULT NULL,
  `tpd_type_pay` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpd_discount` decimal(15,3) DEFAULT NULL,
  `tpd_to_acc` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tpd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_attendance`;
CREATE TABLE `tbl_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `att_date` date DEFAULT NULL,
  `status` enum('P','A') COLLATE utf8_unicode_ci DEFAULT 'A',
  `month_id` int(11) DEFAULT NULL,
  `year_id` int(11) DEFAULT NULL,
  `edit_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_att` (`staff_id`,`att_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2763 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_bankmaster`;
CREATE TABLE `tbl_bankmaster` (
  `bm_id` int(11) NOT NULL AUTO_INCREMENT,
  `bm_name` varchar(2500) COLLATE utf8_unicode_ci NOT NULL,
  `bm_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bm_account` int(11) DEFAULT NULL,
  `bm_lukado` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_base_unit_master`;
CREATE TABLE `tbl_base_unit_master` (
  `bu_id` int(11) NOT NULL AUTO_INCREMENT,
  `bu_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bu_is_central` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_batch_stock`;
CREATE TABLE `tbl_batch_stock` (
  `tbs_id` int(11) NOT NULL AUTO_INCREMENT,
  `tbs_menu` int(11) DEFAULT NULL,
  `tbs_added` decimal(15,3) DEFAULT NULL,
  `tbs_stock_set` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tbs_batch_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tbs_date` date DEFAULT NULL,
  `tbs_ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tbs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_bill_card_payments`;
CREATE TABLE `tbl_bill_card_payments` (
  `mc_id` int(11) NOT NULL AUTO_INCREMENT,
  `mc_billno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `mc_slno` smallint(6) NOT NULL,
  `mc_cardtype` int(11) DEFAULT NULL,
  `mc_cardamount` decimal(15,3) NOT NULL,
  `mc_carnumber` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mc_to_bank` int(11) DEFAULT NULL,
  PRIMARY KEY (`mc_id`),
  UNIQUE KEY `mc_billno` (`mc_billno`,`mc_cardamount`,`mc_to_bank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_billcancel_log`;
CREATE TABLE `tbl_billcancel_log` (
  `bc_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bc_date` date NOT NULL,
  `bc_details` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `bc_datetime` datetime NOT NULL,
  `bc_sms_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bc_email_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bc_sms_time` datetime DEFAULT NULL,
  `bc_email_time` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bc_billno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_br_cloud_tables`;
CREATE TABLE `tbl_br_cloud_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_br_cloud_tables` VALUES ('1','tbl_tableorder','N'),
('2','tbl_tableorder_changes','N'),
('3','tbl_takeaway_cancel_items','N'),
('4','tbl_online_order','N'),
('5','tbl_menumaster','Y'),
('6','tbl_menurate_counter','N'),
('7','tbl_menuratemaster','Y'),
('8','tbl_menuratetakeaway','N'),
('9','tbl_portionmaster','Y'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('10','tbl_floormaster','Y'),
('11','tbl_menumaincategory','Y'),
('12','tbl_extra_tax_master','N'),
('13','tbl_menusubcategory','N'),
('14','tbl_staffmaster','Y'),
('15','tbl_takeaway_customer','N'),
('16','tbl_unit_master','N'),
('17','tbl_unit_master_combination','Y'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('18','tbl_base_unit_master','N'),
('19','tbl_paymentmode','Y'),
('20','tbl_credit_master','N'),
('21','tbl_credit_types','Y'),
('22','tbl_bankmaster','N'),
('23','tbl_kotmaster','N'),
('24','tbl_tablemaster','Y'),
('25','tbl_loyalty_reg','N'),
('26','tbl_corporatemaster','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('27','tbl_discountmaster','N'),
('28','tbl_logindetails','Y'),
('29','tbl_dayclose','Y'),
('30','tbl_menustock','Y'),
('31','tbl_departmentmaster','Y'),
('32','tbl_designationmaster','Y'),
('33','tbl_floor_tax','N'),
('34','tbl_bill_card_payments','N'),
('35','tbl_cancellation_reasons','Y'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('36','tbl_cardmaster','N'),
('37','tbl_combo_bill_details','N'),
('38','tbl_combo_bill_details_ta','N'),
('39','tbl_combo_stock','N'),
('40','tbl_complementory_reasons','N'),
('41','tbl_couponcompany','N'),
('42','tbl_currency_conv_rate','Y'),
('43','tbl_currency_master','Y'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('44','tbl_delivery_status','Y'),
('45','tbl_denomination_master','N'),
('46','tbl_kotcountermaster','Y'),
('47','tbl_expodine_machines','N'),
('48','tbl_feedbackmaster','N'),
('49','tbl_feedbackrating','N'),
('50','tbl_feedbackratingcount','Y'),
('51','tbl_function_details','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('52','tbl_function_details_menu','N'),
('53','tbl_function_extra_costs','N'),
('54','tbl_function_invoice','N'),
('55','tbl_function_invoice_extras','N'),
('56','tbl_function_type','N'),
('57','tbl_function_venue','N'),
('58','tbl_ingredientmaster','N'),
('59','tbl_kot_cancellation','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('60','tbl_loyalty_campaign','N'),
('61','tbl_loyalty_discount','N'),
('62','tbl_loyalty_levels','N'),
('63','tbl_loyalty_point_transfers','N'),
('64','tbl_loyalty_pointadd_bill','N'),
('65','tbl_loyalty_pointrule','N'),
('66','tbl_loyalty_redeem_rule','N'),
('67','tbl_loyalty_rules','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('68','tbl_loyalty_rules_type','N'),
('69','tbl_loyalty_sendto','N'),
('70','tbl_loyalty_sms_source','N'),
('71','tbl_loyalty_voucher','N'),
('72','tbl_menu_addons','N'),
('73','tbl_menu_discount','N'),
('74','tbl_menu_tax_master','N'),
('75','tbl_accounthead','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('76','tbl_online_billdetails','N'),
('77','tbl_online_billmaster','N'),
('78','tbl_order_addon','N'),
('79','tbl_order_addon_changes','N'),
('80','tbl_regenerate_reasons','Y'),
('81','tbl_regenrate_log','N'),
('82','tbl_roommaster','N'),
('83','tbl_shift_close_denomination','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('84','tbl_shift_details','N'),
('85','tbl_shift_open_denomination','N'),
('86','tbl_tablebill_paymentchange','N'),
('87','tbl_preferencemaster','N'),
('88','tbl_voucherhead','N'),
('89','tbl_voucherpayment','N'),
('90','tbl_combo_menu_labels','N'),
('91','tbl_combo_name','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('92','tbl_combo_ordering_details','N'),
('93','tbl_combo_packs','N'),
('94','tbl_combo_pack_menus','N'),
('95','tbl_combo_pack_rates','N'),
('96','tbl_combo_type','N'),
('97','tbl_ledger_setting','N'),
('98','tbl_login_restrict_logs','N'),
('99','tbl_loyalty_campaign_group','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('100','tbl_loyalty_group_details','N'),
('101','tbl_shift_card_detail_close','N'),
('102','tbl_shift_card_detail_open','N'),
('103','tbl_menurate_roomservice','N'),
('104','tbl_appmachinedetails','N'),
('105','tbl_tablebill_split','N'),
('106','tbl_credit_details','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('107','tbl_credit_details_payment','N'),
('108','tbl_expense_voucher','N'),
('109','tbl_supplier_voucher','N'),
('110','tbl_employee_voucher','N'),
('111','tbl_ledger_master','N'),
('112','tbl_ledger_group','Y'),
('113','tbl_online_tax','N'),
('114','tbl_store_stock','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('115','tbl_requisition','N'),
('116','tbl_purchase_order','N'),
('117','tbl_grn_order','N'),
('118','tbl_store_transfer','N'),
('119','tbl_physical_stock','N'),
('120','tbl_purchase_return','N'),
('121','tbl_grn_summary','N'),
('122','tbl_consumption','N'),
('123','tbl_inv_settings','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('124','tbl_stock_details','N'),
('125','tbl_wastage','N'),
('126','tbl_production','N'),
('127','tbl_menu_ingredient_detail','N'),
('128','tbl_product_conversion','N'),
('129','tbl_inv_kitchen','N'),
('130','tbl_vendor_master','N'),
('131','tbl_food_cost','N'),
('132','tbl_central_kitchen_transfer','N'); 
INSERT INTO `tbl_br_cloud_tables` VALUES ('133','tbl_amc_setup','Y'); 


DROP TABLE IF EXISTS `tbl_branch_settings_cloud`;
CREATE TABLE `tbl_branch_settings_cloud` (
  `bsc_branchid` int(11) NOT NULL,
  `bsc_cloud_group_id` int(11) NOT NULL DEFAULT '0',
  `bsc_cloud_branchid` int(11) NOT NULL DEFAULT '0',
  `be_cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sync_pswd` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avoid_tables` text COLLATE utf8_unicode_ci,
  `last_sync_time` datetime DEFAULT NULL,
  `current_table` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_sync_time` datetime DEFAULT NULL,
  `cloud_url` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `online_ordering_url` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bsc_firebase_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_update_data` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sync_start_date` date DEFAULT NULL,
  `sync_status` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`bsc_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_branch_settings_cloud` VALUES ('1','0','0','Y','',NULL,NULL,NULL,NULL,'',NULL,'N','N',NULL,NULL); 


DROP TABLE IF EXISTS `tbl_branch_settings_counter`;
CREATE TABLE `tbl_branch_settings_counter` (
  `bsc_branchid` bigint(20) NOT NULL,
  `bsc_nearest_roundoff` decimal(5,4) NOT NULL DEFAULT '1.0000',
  `bsc_kotbypass` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsc_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsc_discount_popup` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsc_bill_before_settle` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsc_default_settle_touchpad` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsc_enable_generate` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsc_enable_hold` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsc_roundoff_visible` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsc_settle_billprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsc_bill_series` int(11) NOT NULL DEFAULT '1',
  `bsc_cs_bill_extra_copy` int(11) NOT NULL DEFAULT '1',
  `bsc_bill_in_hand_device` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsc_kot_in_hand_device` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsc_bill_print` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`bsc_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_branch_settings_counter` VALUES ('1','1.0000','N','Y','N','Y','Y','N','Y','Y','N','1','1','N','N','Y'); 


DROP TABLE IF EXISTS `tbl_branch_settings_loyality`;
CREATE TABLE `tbl_branch_settings_loyality` (
  `bl_branchid` int(11) NOT NULL,
  `bl_loyality_point` int(11) NOT NULL,
  `bl_loyality_cash` decimal(15,3) NOT NULL,
  `bl_redemption_min_point` int(11) NOT NULL,
  `bl_redemption_cash_value` decimal(15,3) NOT NULL,
  PRIMARY KEY (`bl_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_branch_settings_printer`;
CREATE TABLE `tbl_branch_settings_printer` (
  `bp_branchid` bigint(20) NOT NULL,
  `bp_bill_set_ip` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bp_lineseperation_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bp_item_other_lang` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `bp_item_other_lang_kot` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bp_show_steward` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bp_print_proceed_btn` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bp_space_after_item_bill` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bp_long_menu` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `bp_consolidate_kot_iplock` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bp_kot_iplock` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bp_footer` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bp_kot_size` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `bp_bill_size` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NORMAL',
  PRIMARY KEY (`bp_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_branch_settings_printer` VALUES ('1','N','N','N','N','Y','Y','Y','N','N','N','','NORMAL','NORMAL'); 


DROP TABLE IF EXISTS `tbl_branch_settings_ta_hd`;
CREATE TABLE `tbl_branch_settings_ta_hd` (
  `bsth_branchid` bigint(20) NOT NULL,
  `bsth_nearest_roundoff` decimal(5,4) NOT NULL DEFAULT '1.0000',
  `bsth_kotbypass` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsth_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsth_discount_popup` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsth_roundoff_visible` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsth_enable_hold` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsth_settle_billprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bsth_bill_series` int(11) NOT NULL DEFAULT '1',
  `bsth_hd_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsth_hd_bill_extra_copy` int(11) NOT NULL DEFAULT '1',
  `bsth_ta_bill_extra_copy` int(11) NOT NULL DEFAULT '1',
  `bsth_delivery_charge` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bsth_staff_assign_bypass` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsth_bill_print` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsth_bill_before_tahd` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `bsth_kot_before_tahd` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `bsth_kot_after_tahd` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bsth_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_branch_settings_ta_hd` VALUES ('1','1.0000','N','Y','N','Y','Y','N','1','Y','1','1','0.000','Y','Y','Y','Y','N'); 


DROP TABLE IF EXISTS `tbl_branchmaster`;
CREATE TABLE `tbl_branchmaster` (
  `be_branchid` bigint(20) NOT NULL,
  `be_branchname` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `be_branchprefix` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `be_address` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_others1` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_others2` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_others3` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_others4` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_footer1` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_footer2` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_footer3` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_footer4` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_floorcount` tinyint(4) NOT NULL DEFAULT '1',
  `be_kotcount` tinyint(4) NOT NULL DEFAULT '1',
  `be_credit_count` int(11) NOT NULL DEFAULT '1',
  `be_crd_guestcount` int(11) NOT NULL DEFAULT '1',
  `be_tablecount` int(11) NOT NULL DEFAULT '1',
  `be_departmentcount` int(11) NOT NULL DEFAULT '1',
  `be_designationcount` int(11) NOT NULL DEFAULT '1',
  `be_staffidcount` int(11) NOT NULL DEFAULT '1',
  `be_menumaincatcount` int(11) NOT NULL DEFAULT '1',
  `be_menusubcatcount` int(11) DEFAULT '1',
  `be_menucount` int(11) NOT NULL DEFAULT '1',
  `be_loyalityreg_count` int(11) NOT NULL DEFAULT '1',
  `be_discountcount` int(11) NOT NULL DEFAULT '1',
  `be_vouchercount` int(11) NOT NULL DEFAULT '1',
  `be_corporatecount` int(11) NOT NULL DEFAULT '1',
  `be_printercount` int(11) NOT NULL DEFAULT '1',
  `be_feedbackcount` int(11) NOT NULL DEFAULT '1',
  `be_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_takeawaycustcount` int(11) NOT NULL DEFAULT '1',
  `be_voucherhead_count` int(11) DEFAULT '1',
  `be_appstring` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_kotstatuschange` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_listimage` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_fin_year_start` char(4) COLLATE utf8_unicode_ci DEFAULT '0104',
  `be_fin_year_end` char(4) COLLATE utf8_unicode_ci DEFAULT '0331',
  `be_printall` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_personscount` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_inventorylink` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_userpermissionadd` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_ta_kotbypass` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_ta_combkotbill_print` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_tableprefix_split` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_printwithdiscount` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_app_printwithdiscount` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_printwithloyality` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_app_printwithloyality` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_androidpasscode` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_logoinbill` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_billwithportion` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_ratein_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_total_itemcountin_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_staffin_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_slnoin_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_floor_in_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_orderconfirm_bktotablesel` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_androdilogin` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_andr_default_login` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_qtychange_authorise` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_email_on_dayclose` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_bilregen_with_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_compl_manage_auth` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_reportemail_list` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_auth_paymentchange` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_print_on_dayclose` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_sms_on_dayclose` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_sms_list` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_sound_notification` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `be_loyality_reg_msg` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_kod_takeaway` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_kod_dinein` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_consolidated_print` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_voucher_pay_approve_default` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_nearest_roundoff_value` decimal(5,4) NOT NULL DEFAULT '1.0000',
  `be_cash_drawer` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_cash_drawer_settle_btn` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cash_drawer_settle_ta_hd` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cash_drawer_settle_cs` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_roundoff_visible` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_regenerate_enable` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_bill_reprint_enable` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_billref_in_bill` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_emenu_cart_authorization` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_kotwaiter_name_dis` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_dbbackuplocation` varchar(250) COLLATE utf8_unicode_ci DEFAULT 'C:\\\\Expodine_backup',
  `be_kot_cancellation_print` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_staff_selection` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Drop_Down',
  `be_authorise_with_code` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_dayclose_authorise` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_reprint_authorise` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_bill_split_authorise` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_login_mode` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Normal',
  `be_change_with_autherise` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_deno_pop_up` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_kod_image` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_eat_in` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_settle_billprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_decimal` tinyint(4) NOT NULL DEFAULT '2',
  `be_menuimage_in_android` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_count_on` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_kod_screen` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Option_1',
  `be_android_staffwise_occupied` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_time_zone` varchar(100) COLLATE utf8_unicode_ci DEFAULT 'Asia/Kolkata',
  `be_base_currency` int(11) DEFAULT NULL,
  `be_show_currency` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_bill_cancel_auth` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_app_login_code` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_app_auth_code` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_email_void` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_sms_void` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_kod_sound` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_multicard` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_gameurl` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_game_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_search_focus` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'search',
  `be_gst_info` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_expolitelink` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_android_kotprint` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_android_kot_consolidated` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_pole_display` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_order_split` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_order_split_authorise` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_loyalty_settle` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_min_redeem_point` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_loyalty_greetings_bday` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_loyalty_greetings_anvy` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_timely_sms` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_comport` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_pole_message` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_combo_enable` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_db_archive_api` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_print_with_preference` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_search_focus_counter` varchar(100) COLLATE utf8_unicode_ci DEFAULT 'search',
  `be_banquet_gst` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_inventory_staff_add` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_online_company_default` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_onscreen_keyboard` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_floor_table_change` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_cs_kot_before_settle` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_cs_kot_after_settle` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_phone_order` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_phone_order_enable` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_pax_kot_show` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_single_shift` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_shift_mail` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_data_save` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_uae_tax_concept` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_uae_tax_value` decimal(15,3) DEFAULT '0.000',
  `be_ta_settle_auth` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_cs_settle_auth` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_billprint_option` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `be_bill_print_on` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `be_inventory_db_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_daily_stock_update` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_sms_bill` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_store_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT '0',
  `be_store_db` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_qrcode_db` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_online_order_enable` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `be_cloud_menu_change` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `be_inv_stock_api` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_urban_api_key` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_urban_api_url` varchar(250) COLLATE utf8_unicode_ci DEFAULT 'https://api.urbanpiper.com',
  `be_barcode_location` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_menu_list_theme` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Theme_2',
  `be_common_alerts` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_incl_bill_format` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_kot_generate_tahd` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_single_click_add` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_accounts_start_date` date DEFAULT '2030-07-01',
  `be_barcode_printer_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT 'TSC',
  `be_rate_on_button` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_kot_miss_check` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_saudi_format` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_arabic_address` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_di_settle_auth` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_central_kitchen` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_disc_after` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_lukado_on` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_lukado_api` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_lukado_store_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_lukado_key` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_multistore_staff` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `be_inv_sales_stock_reduce` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_bill_print_on_ta` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_bill_print_on_di` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `be_kot_miss_check_ta` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `be_kot_cons_miss_ta` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_kot_cons_miss_di` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`be_branchid`),
  UNIQUE KEY `be_branchname` (`be_branchname`),
  UNIQUE KEY `be_branchprefix` (`be_branchprefix`),
  KEY `be_base_currency` (`be_base_currency`),
  CONSTRAINT `fk_branchmaster_curreny` FOREIGN KEY (`be_base_currency`) REFERENCES `tbl_currency_master` (`c_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_branchmaster` VALUES ('1','Explore','B','ABCD','','','','','','Thank You Visit Again','','Parcel Food Should Be Consumed Within 2 HRS','POWERED BY - EXPODINE.COM','2','2','1','1','9','2','13','8','23','2','123','1','1','1','1','9','1','','1','1','http://192.168.0.150:8021/Dropbox/expodine','N','N','0104','0331','Y','Y','','Y','Y','Y','N','N','N','N','N','','Y','Y','N','Y','Y','N','N','Y','Y','Accountant','Y','Y','Y','N','','Y','Y','N','','N','','N','N','N','Y','1.0000','N','N','N','N','Y','Y','Y','N','N','N','C:Expodine_backup','Y','Drop_Down','Y','Y','Y','Y','Card/Pin',NULL,'Y','N','N','N','2','N','N','Option_1','N','Asia/Kolkata','1','N','Y','N','Y','N','N','N','Y','','N','search','Y','','Y','Y','N','N','N','N','','','','N','N','','','N','','N','search','','N','Y','N','N','N','Y',NULL,'N','N','N','N','Y','N','0.000','N','N','N','Y','','N','N','0','','','N','N','',NULL,'https://api.urbanpiper.com','C:/Users/Downloads/','Theme_2','N','N','N','Y','2030-07-01','TSC','N','N','N','','N','N','N','N',NULL,NULL,NULL,'N','Y','Y','Y','N','N','N'); 


DROP TABLE IF EXISTS `tbl_branchsettings_android`;
CREATE TABLE `tbl_branchsettings_android` (
  `an_id` int(11) NOT NULL AUTO_INCREMENT,
  `an_login_mode` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Normal',
  `an_reprint_auth` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`an_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_branchsettings_android` VALUES ('1','Normal','N','N'); 


DROP TABLE IF EXISTS `tbl_cancellation_reasons`;
CREATE TABLE `tbl_cancellation_reasons` (
  `cr_id` int(11) NOT NULL DEFAULT '1',
  `cr_reason` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `cr_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_cancellation_reasons` VALUES ('1','Wrong Entry','Y','N'),
('2','Customer Returned','Y','N'),
('3','Order Delayed','Y','N'); 


DROP TABLE IF EXISTS `tbl_cardmaster`;
CREATE TABLE `tbl_cardmaster` (
  `crd_id` int(15) NOT NULL AUTO_INCREMENT,
  `crd_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `crd_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `crd_imageurl` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`crd_id`),
  UNIQUE KEY `crd_name` (`crd_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_cash_drawer_log`;
CREATE TABLE `tbl_cash_drawer_log` (
  `cdl_id` int(11) NOT NULL AUTO_INCREMENT,
  `cdl_date` date DEFAULT NULL,
  `cdl_time` time DEFAULT NULL,
  `cdl_login` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cdl_interface` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'W',
  `cdl_machineid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cdl_app_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`cdl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_central_kitchen_transfer`;
CREATE TABLE `tbl_central_kitchen_transfer` (
  `tct_id` int(11) NOT NULL AUTO_INCREMENT,
  `tct_central_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_product` int(11) DEFAULT NULL,
  `tct_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_unit_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_qty` decimal(15,3) DEFAULT NULL,
  `tct_weight` decimal(15,3) DEFAULT NULL,
  `tct_rate` decimal(15,3) DEFAULT NULL,
  `tct_total` decimal(15,3) DEFAULT NULL,
  `tct_tax` decimal(15,3) DEFAULT '0.000',
  `tct_total_tax` decimal(15,3) DEFAULT '0.000',
  `tct_final_total` decimal(15,3) DEFAULT NULL,
  `tct_date` datetime DEFAULT NULL,
  `tct_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_local_branch` int(11) DEFAULT NULL,
  `tct_local_store` int(11) DEFAULT NULL,
  `tct_to_branch` int(11) DEFAULT NULL,
  `tct_to_store` int(11) DEFAULT NULL,
  `tct_set` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Z',
  `tct_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_current_stock` decimal(15,3) DEFAULT NULL,
  `tct_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_mode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_received` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tct_receive_time` datetime DEFAULT NULL,
  `tct_receive_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_status_live` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_cancel_time` datetime DEFAULT NULL,
  `tc_cancel_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_receieved_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_central_menu_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_reject_update` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_reject_reason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_edit_value` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tct_edited_by` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_edited_stage` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_edited_time` datetime DEFAULT NULL,
  `tct_from_store_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_to_store_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_from_branch_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_to_branch_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_live_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tct_live_or_local` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Local',
  `tct_option` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_city`;
CREATE TABLE `tbl_city` (
  `cy_cityid` bigint(20) NOT NULL,
  `cy_cityname` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `cy_stateid` bigint(20) NOT NULL,
  `cy_countryid` smallint(6) NOT NULL,
  PRIMARY KEY (`cy_cityid`),
  UNIQUE KEY `cy_cityname` (`cy_cityname`),
  KEY `cy_stateid` (`cy_stateid`),
  KEY `cy_countryid` (`cy_countryid`),
  CONSTRAINT `fk_city_countryid` FOREIGN KEY (`cy_countryid`) REFERENCES `tbl_country` (`cy_countyid`),
  CONSTRAINT `fk_city_stateid` FOREIGN KEY (`cy_stateid`) REFERENCES `tbl_state` (`se_stateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_cloud_backup_history`;
CREATE TABLE `tbl_cloud_backup_history` (
  `cbh_date` date NOT NULL,
  `cbh_slno` int(11) NOT NULL,
  `cbh_time` datetime DEFAULT NULL,
  `cbh_syched` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cbh_date`,`cbh_slno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_combo_bill_details`;
CREATE TABLE `tbl_combo_bill_details` (
  `cbd_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cbd_billslno` int(11) NOT NULL,
  `cbd_count_combo_ordering` int(11) DEFAULT NULL,
  `cbd_combo_id` int(11) DEFAULT NULL,
  `cbd_combo_pack_id` int(11) DEFAULT NULL,
  `cbd_combo_qty` int(11) DEFAULT NULL,
  `cbd_combo_pack_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cbd_combo_total_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cbd_menu_id` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cbd_menu_qty` int(11) DEFAULT NULL,
  `cbd_entry_date` datetime DEFAULT NULL,
  `cbd_dayclosedate` date DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cbd_billno`,`cbd_billslno`),
  CONSTRAINT `fk_combo_bill_details` FOREIGN KEY (`cbd_billno`) REFERENCES `tbl_tablebillmaster` (`bm_billno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_combo_bill_details_ta`;
CREATE TABLE `tbl_combo_bill_details_ta` (
  `cbd_id` int(11) NOT NULL AUTO_INCREMENT,
  `cbd_count_combo_ordering` int(11) DEFAULT NULL,
  `cbd_billno` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cbd_combo_id` int(11) DEFAULT NULL,
  `cbd_combo_pack_id` int(11) DEFAULT NULL,
  `cbd_slno` int(11) NOT NULL DEFAULT '1',
  `cbd_combo_qty` int(11) DEFAULT NULL,
  `cbd_combo_pack_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cbd_combo_total_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cbd_menu_id` int(11) DEFAULT NULL,
  `cbd_menu_qty` int(11) DEFAULT NULL,
  `cbd_combo_preference` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cbd_entry_date` datetime DEFAULT NULL,
  `cbd_dayclosedate` date DEFAULT NULL,
  `cbd_order_status` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cbd_kot_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cbd_cancel` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cbd_regen_status` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`cbd_id`),
  KEY `cbd_billno` (`cbd_billno`),
  CONSTRAINT `fk_combo_bill_details_ta` FOREIGN KEY (`cbd_billno`) REFERENCES `tbl_takeaway_billmaster` (`tab_billno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_combo_menu_labels`;
CREATE TABLE `tbl_combo_menu_labels` (
  `cml_id` int(11) NOT NULL AUTO_INCREMENT,
  `cml_label` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cml_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cml_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_combo_name`;
CREATE TABLE `tbl_combo_name` (
  `cn_id` int(11) NOT NULL AUTO_INCREMENT,
  `cn_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cn_type` int(11) NOT NULL,
  `cn_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cn_stock_check` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_combo_ordering_details`;
CREATE TABLE `tbl_combo_ordering_details` (
  `cod_id` int(11) NOT NULL AUTO_INCREMENT,
  `cod_count_combo_ordering` int(11) DEFAULT NULL,
  `cod_orderno` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cod_combo_id` int(11) DEFAULT NULL,
  `cod_combo_pack_id` int(11) DEFAULT NULL,
  `cod_slno` int(11) NOT NULL DEFAULT '1',
  `cod_combo_qty` int(11) DEFAULT NULL,
  `cod_combo_pack_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cod_combo_total_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cod_menu_id` int(11) DEFAULT NULL,
  `cod_menu_qty` int(11) DEFAULT NULL,
  `cod_combo_preference` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cod_entry_date` datetime DEFAULT NULL,
  `cod_dayclosedate` date DEFAULT NULL,
  `cod_order_status` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cod_kot_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cod_cancel` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_combo_pack_menus`;
CREATE TABLE `tbl_combo_pack_menus` (
  `cpm_id` int(11) NOT NULL AUTO_INCREMENT,
  `cpm_menu_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cpm_combo_pack_id` int(11) NOT NULL,
  `cpm_combo_id` int(11) NOT NULL,
  `cpm_menu_sale_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cpm_menu_type_label_id` int(11) DEFAULT NULL,
  `cpm_menu_qty` int(11) DEFAULT NULL,
  `cpm_menu_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cpm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_combo_pack_rates`;
CREATE TABLE `tbl_combo_pack_rates` (
  `cpr_id` int(11) NOT NULL AUTO_INCREMENT,
  `cpr_combo_pack_id` int(11) NOT NULL,
  `cpr_combo_id` int(11) NOT NULL,
  `cpr_floor_id` int(11) DEFAULT NULL,
  `cpr_mode` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cpr_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cpr_online_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cpr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_combo_packs`;
CREATE TABLE `tbl_combo_packs` (
  `cp_id` int(11) NOT NULL AUTO_INCREMENT,
  `cp_pack_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cp_combo` int(11) DEFAULT NULL,
  `cp_pack_qty` int(11) DEFAULT '0',
  `cp_pack_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_combo_stock`;
CREATE TABLE `tbl_combo_stock` (
  `cs_id` int(11) NOT NULL AUTO_INCREMENT,
  `cs_pack_id` int(11) DEFAULT NULL,
  `cs_combo_id` int(11) DEFAULT NULL,
  `cs_stock_number` int(11) NOT NULL DEFAULT '0',
  `cs_stock_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cs_stock_date` date DEFAULT NULL,
  `cs_last_updated` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_combo_type`;
CREATE TABLE `tbl_combo_type` (
  `ct_id` int(11) NOT NULL AUTO_INCREMENT,
  `ct_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_common_logs_all`;
CREATE TABLE `tbl_common_logs_all` (
  `tcl_id` int(11) NOT NULL AUTO_INCREMENT,
  `tcl_date` date DEFAULT NULL,
  `tcl_data` varchar(2500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcl_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tcl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_complementory_reasons`;
CREATE TABLE `tbl_complementory_reasons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cor_reason` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cor_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_consumption`;
CREATE TABLE `tbl_consumption` (
  `tc_id` int(11) NOT NULL AUTO_INCREMENT,
  `tc_con_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_product` int(11) DEFAULT NULL,
  `tc_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_qty` int(11) DEFAULT NULL,
  `tc_weight` decimal(15,3) DEFAULT NULL,
  `tc_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_unit_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_rate` decimal(15,3) DEFAULT NULL,
  `tc_total` decimal(15,3) DEFAULT NULL,
  `tc_set` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tc_date` date DEFAULT NULL,
  `tc_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_store` int(11) DEFAULT NULL,
  `tc_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_current_stock` decimal(15,3) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tc_balance` decimal(15,3) DEFAULT '0.000',
  PRIMARY KEY (`tc_id`),
  UNIQUE KEY `tc_con_id` (`tc_con_id`,`tc_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_contra_voucher`;
CREATE TABLE `tbl_contra_voucher` (
  `cv_id` int(11) NOT NULL AUTO_INCREMENT,
  `cv_date` date DEFAULT NULL,
  `cv_from_acc` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cv_to_acc` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cv_amount` decimal(15,3) DEFAULT NULL,
  `cv_transaction_data` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cv_remarks` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cv_entry_date` date DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cv_cloud_added` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cv_cloud_edited` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cv_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_corporatemaster`;
CREATE TABLE `tbl_corporatemaster` (
  `ct_corporatecode` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ct_corporatename` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ct_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ct_online_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ct_corporatecode`),
  UNIQUE KEY `ct_corporatename` (`ct_corporatename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_country`;
CREATE TABLE `tbl_country` (
  `cy_countyid` smallint(11) NOT NULL,
  `cy_countryname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cy_countyid`),
  UNIQUE KEY `cy_countryname` (`cy_countryname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_couponcompany`;
CREATE TABLE `tbl_couponcompany` (
  `cy_coupid` int(11) NOT NULL,
  `cy_companyname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cy_active` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Yes',
  `cy_startdate` date NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cy_companyname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_credit_details`;
CREATE TABLE `tbl_credit_details` (
  `cd_slno` int(11) NOT NULL AUTO_INCREMENT,
  `cd_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cd_modeofentry` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cd_masterid` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cd_amount` decimal(15,2) NOT NULL,
  `cd_dateofentry` datetime NOT NULL,
  `cd_settled` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cd_dateofsettle` datetime DEFAULT NULL,
  `cd_dayclosedate` date DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cd_slno`),
  UNIQUE KEY `cd_billno` (`cd_billno`),
  KEY `fk_creditdetails_creditmaster` (`cd_masterid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_credit_details_payment`;
CREATE TABLE `tbl_credit_details_payment` (
  `cdp_master_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cdp_dayclosedate` date NOT NULL,
  `cdp_slno` int(11) NOT NULL,
  `cdp_paid_cash` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cdp_transaction_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cdp_balance` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cdp_entry_time` datetime DEFAULT NULL,
  `cdp_login_id` int(11) DEFAULT NULL,
  `cdp_bank` int(11) DEFAULT NULL,
  PRIMARY KEY (`cdp_master_id`,`cdp_dayclosedate`,`cdp_slno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_credit_master`;
CREATE TABLE `tbl_credit_master` (
  `crd_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `crd_type` int(11) NOT NULL,
  `crd_branchid` bigint(20) NOT NULL,
  `crd_totalamount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `crd_staffid` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `crd_roomid` int(11) DEFAULT NULL,
  `crd_corporateid` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `crd_guestid` int(11) DEFAULT NULL,
  `crd_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`crd_id`),
  UNIQUE KEY `crd_corporateid` (`crd_corporateid`),
  UNIQUE KEY `crd_guestid_2` (`crd_guestid`),
  UNIQUE KEY `crd_staffid_2` (`crd_staffid`),
  KEY `crd_companyid` (`crd_corporateid`),
  KEY `crd_guestid` (`crd_guestid`),
  KEY `crd_roomid` (`crd_roomid`),
  KEY `crd_staffid` (`crd_staffid`),
  KEY `crd_type` (`crd_type`),
  CONSTRAINT `fk_creditmaster_corporateid` FOREIGN KEY (`crd_corporateid`) REFERENCES `tbl_corporatemaster` (`ct_corporatecode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_creditmaster_credtypeid` FOREIGN KEY (`crd_type`) REFERENCES `tbl_credit_types` (`ct_creditid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_creditmaster_loyalityid` FOREIGN KEY (`crd_guestid`) REFERENCES `tbl_loyalty_reg` (`ly_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_creditmaster_roomid` FOREIGN KEY (`crd_roomid`) REFERENCES `tbl_roommaster` (`rm_roomid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_creditmaster_staffid` FOREIGN KEY (`crd_staffid`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_credit_partial_bill`;
CREATE TABLE `tbl_credit_partial_bill` (
  `tcp_id` int(11) NOT NULL AUTO_INCREMENT,
  `tcp_billno` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcp_mode` int(11) DEFAULT NULL,
  `tcp_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tcp_date` datetime DEFAULT NULL,
  `tcp_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tcp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_credit_types`;
CREATE TABLE `tbl_credit_types` (
  `ct_creditid` int(11) NOT NULL,
  `ct_credit_type` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `ct_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ct_labels` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ct_creditid`),
  UNIQUE KEY `ct_credit_type` (`ct_credit_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `tbl_credit_types` VALUES ('1','By Room','N','Room name','N'),
('2','By Staff','Y','Staff name','N'),
('3','By Company','Y','Company Name','N'),
('4','By Guest','Y','Guest Name','N'); 


DROP TABLE IF EXISTS `tbl_currency_conv_rate`;
CREATE TABLE `tbl_currency_conv_rate` (
  `cc_base_currency` int(11) NOT NULL,
  `cc_currency` int(11) NOT NULL,
  `cc_conversion_rate` decimal(15,6) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cc_base_currency`,`cc_currency`),
  KEY `fk_currency_conv_rate_curr` (`cc_currency`),
  CONSTRAINT `fk_currency_conv_rate_base` FOREIGN KEY (`cc_base_currency`) REFERENCES `tbl_currency_master` (`c_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_currency_conv_rate_curr` FOREIGN KEY (`cc_currency`) REFERENCES `tbl_currency_master` (`c_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_currency_conv_rate` VALUES ('1','1','1.000000','N'),
('2','2','1.000000','N'),
('3','3','1.000000','N'),
('4','4','1.000000','N'),
('5','5','1.000000','N'),
('6','6','1.000000','N'),
('7','7','1.000000','N'),
('8','8','1.000000','N'),
('9','9','1.000000','N'),
('10','10','1.000000','N'),
('11','11','1.000000','N'); 


DROP TABLE IF EXISTS `tbl_currency_master`;
CREATE TABLE `tbl_currency_master` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `c_short_code` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `c_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_currency_master` VALUES ('1','Indian Rupees','INR','Active','N'),
('2','Dollar','$','Active','N'),
('3','Dirham','AED','Active','N'),
('4','Qatar Riyal','QAR','Active','N'),
('5','Saudi Riyal','SAR','Active','N'),
('6','Georgian Lari','GEL','Active','N'),
('7','Kuwait Dinar','KWD','Active','N'); 
INSERT INTO `tbl_currency_master` VALUES ('8','Bahrain Dinar','BD','Active','N'),
('9','Oman Rial','OMR','Active','N'),
('10','South African Rand','ZAR','Active','N'),
('11','Fijian Dollar','FJD','Active','N'); 


DROP TABLE IF EXISTS `tbl_customer_ebill_details`;
CREATE TABLE `tbl_customer_ebill_details` (
  `branchid` int(11) DEFAULT NULL,
  `tc_review` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_billno` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  UNIQUE KEY `branchid` (`branchid`,`tc_billno`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_daily_stock_detail`;
CREATE TABLE `tbl_daily_stock_detail` (
  `ts_id` int(11) NOT NULL AUTO_INCREMENT,
  `ts_dayclose` date DEFAULT NULL,
  `ts_menuid` int(11) DEFAULT NULL,
  `ts_portion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_unit_weight` decimal(15,3) DEFAULT '0.000',
  `ts_unit_id` int(11) DEFAULT NULL,
  `ts_base_unit_id` int(11) DEFAULT NULL,
  `ts_open_stock` int(11) DEFAULT NULL,
  `ts_added_stock` int(11) DEFAULT NULL,
  `ts_balance_stock` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ts_id`),
  UNIQUE KEY `ts_dayclose` (`ts_dayclose`,`ts_menuid`,`ts_portion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_databank`;
CREATE TABLE `tbl_databank` (
  `db_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `db_mailtext` text COLLATE utf8_unicode_ci,
  `db_messgaetext` text COLLATE utf8_unicode_ci,
  `db_tomail` text COLLATE utf8_unicode_ci,
  `db_tomessage` text COLLATE utf8_unicode_ci,
  `db_attachment` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_sendto` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_closedate` date NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_datesettings`;
CREATE TABLE `tbl_datesettings` (
  `ds_branchid` bigint(20) NOT NULL,
  `ds_date` date NOT NULL,
  `ds_ordercount` int(11) NOT NULL DEFAULT '1',
  `ds_kotno` int(11) NOT NULL DEFAULT '1',
  `ds_takeawaybillcount` int(11) NOT NULL DEFAULT '1',
  `ds_voucherpay_count` int(11) NOT NULL DEFAULT '1',
  `ds_hold_no` int(11) NOT NULL DEFAULT '1',
  `ds_kot_cancellation_id` int(11) NOT NULL DEFAULT '1',
  `ds_bill_ref_dine_in` int(11) NOT NULL DEFAULT '1',
  `ds_bill_ref_counter` int(11) NOT NULL DEFAULT '1',
  `ds_bill_ref_ta` int(11) NOT NULL DEFAULT '1',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ds_branchid`,`ds_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_dayclose`;
CREATE TABLE `tbl_dayclose` (
  `dc_day` date NOT NULL,
  `dc_id` bigint(20) NOT NULL,
  `dc_dateopen` date NOT NULL,
  `dc_timeopen` time NOT NULL,
  `dc_dateclose` date DEFAULT NULL,
  `dc_timeclose` time DEFAULT NULL,
  `dc_open_total_deno` decimal(15,2) NOT NULL DEFAULT '0.00',
  `dc_close_total_deno` decimal(15,2) NOT NULL DEFAULT '0.00',
  `dc_dayclose_sms_success` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `dc_dayclose_email_success` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `dc_last_sms_time` datetime DEFAULT NULL,
  `dc_last_email_time` datetime DEFAULT NULL,
  `dc_dayclose_sms_attempts` int(1) NOT NULL DEFAULT '0',
  `dc_dayclose_email_attempts` int(1) NOT NULL DEFAULT '0',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `dc_profit` decimal(15,3) DEFAULT '0.000',
  `dc_loss` decimal(15,3) NOT NULL DEFAULT '0.000',
  `dc_asset` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dc_liab` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dc_income` decimal(15,3) NOT NULL DEFAULT '0.000',
  `dc_expense` decimal(15,3) NOT NULL DEFAULT '0.000',
  `dc_closing_user` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dc_closing_pc` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dc_continue_sale` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `dc_monthy_send` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`dc_day`),
  KEY `dayclose` (`dc_day`,`dc_dateopen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_dayclose` VALUES ('2026-04-20','1','2026-04-20','11:21:09',NULL,NULL,'0.00','0.00','N','N',NULL,NULL,'0','0','N','0.000','0.000',NULL,NULL,'0.000','0.000',NULL,NULL,'N','N'); 


DROP TABLE IF EXISTS `tbl_dayclose_revert_log`;
CREATE TABLE `tbl_dayclose_revert_log` (
  `td_id` int(11) NOT NULL AUTO_INCREMENT,
  `td_reverted_by` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `td_date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`td_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_dbsize_detail`;
CREATE TABLE `tbl_dbsize_detail` (
  `tbs_id` int(11) NOT NULL AUTO_INCREMENT,
  `tbs_month` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tbs_size` decimal(15,3) DEFAULT NULL,
  PRIMARY KEY (`tbs_id`),
  UNIQUE KEY `tbs_month` (`tbs_month`),
  UNIQUE KEY `tbs_month_2` (`tbs_month`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_delivery_status`;
CREATE TABLE `tbl_delivery_status` (
  `ds_id` int(11) NOT NULL AUTO_INCREMENT,
  `ds_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ds_short_code` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ds_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_delivery_status` VALUES ('1','Delivered','D','N'),
('2','Change Del. Boy','NA','N'); 


DROP TABLE IF EXISTS `tbl_denomination_master`;
CREATE TABLE `tbl_denomination_master` (
  `dm_id` int(11) NOT NULL AUTO_INCREMENT,
  `dm_denomination` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `dm_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `dm_display_order` int(11) NOT NULL DEFAULT '1',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`dm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_departmentmaster`;
CREATE TABLE `tbl_departmentmaster` (
  `der_departmentid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `der_departmentname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `der_branch` bigint(20) NOT NULL DEFAULT '1',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`der_departmentid`),
  UNIQUE KEY `der_departmentname` (`der_departmentname`),
  KEY `fk_department_branch` (`der_branch`),
  CONSTRAINT `fk_department_branch` FOREIGN KEY (`der_branch`) REFERENCES `tbl_branchmaster` (`be_branchid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `tbl_departmentmaster` VALUES ('1','Restaurant','1','N'); 


DROP TABLE IF EXISTS `tbl_designationmaster`;
CREATE TABLE `tbl_designationmaster` (
  `dr_designationid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `dr_designationname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `dr_branch` bigint(20) NOT NULL DEFAULT '1',
  `dr_login` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Yes',
  `dr_takeorder` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `dr_authorisation_code` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`dr_designationid`),
  UNIQUE KEY `dr_designationname` (`dr_designationname`),
  KEY `fk_designation_branch` (`dr_branch`),
  CONSTRAINT `fk_designation_branch` FOREIGN KEY (`dr_branch`) REFERENCES `tbl_branchmaster` (`be_branchid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_designationmaster` VALUES ('1','Manager','1','Yes','N','Y','N'),
('10','Waiter','1','Yes','N','N','N'),
('11','Captain','1','Yes','N','Y','N'),
('12','Accountant','1','Yes','N','Y','N'),
('2','Others','1','No','N','N','N'),
('3','Super Admin','1','Yes','N','Y','N'),
('4','KOT Manager','1','Yes','N','Y','N'); 
INSERT INTO `tbl_designationmaster` VALUES ('5','Store Manager','1','Yes','N','N','N'),
('6','Delivery Boy','1','No','N','N','N'),
('7','Steward','1','Yes','Y','Y','N'),
('8','Cashier','1','Yes','N','Y','N'),
('9','Supervisor','1','Yes','N','N','N'); 


DROP TABLE IF EXISTS `tbl_discountmaster`;
CREATE TABLE `tbl_discountmaster` (
  `ds_discountid` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ds_discountname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ds_item_discount` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ds_branchid` bigint(20) NOT NULL,
  `ds_status` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `ds_discountof` decimal(8,3) NOT NULL,
  `ds_mode` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ds_cloud_added` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ds_cloud_edit` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ds_discountid`),
  UNIQUE KEY `ds_discountname` (`ds_discountname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_employee_master`;
CREATE TABLE `tbl_employee_master` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_first_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_last_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_employee_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_vendor` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_department` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_designation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_mail` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_salary` decimal(15,3) DEFAULT NULL,
  `emp_mode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_alternate_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_dob` date DEFAULT NULL,
  `emp_join_date` date DEFAULT NULL,
  `emp_id_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_id_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_remarks` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`emp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_employee_salary`;
CREATE TABLE `tbl_employee_salary` (
  `tes_id` int(11) NOT NULL AUTO_INCREMENT,
  `tes_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tes_year` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tes_emp_id` int(11) DEFAULT NULL,
  `tes_workdays` int(11) DEFAULT NULL,
  `tes_lopdays` int(11) DEFAULT NULL,
  `tes_extradays` int(11) DEFAULT NULL,
  `tes_deduction` decimal(15,3) DEFAULT NULL,
  `tes_extrapay` decimal(15,3) DEFAULT NULL,
  `tes_netsalary` decimal(15,3) DEFAULT NULL,
  `tes_entrydate` datetime DEFAULT NULL,
  `tes_advance` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tes_paid` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`tes_id`),
  UNIQUE KEY `tes_month` (`tes_month`,`tes_year`,`tes_emp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=339 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_employee_voucher`;
CREATE TABLE `tbl_employee_voucher` (
  `ev_id` int(11) NOT NULL AUTO_INCREMENT,
  `ev_employee_id` int(11) DEFAULT NULL,
  `ev_department` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_pay_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_date` date DEFAULT NULL,
  `ev_amount` decimal(15,3) DEFAULT NULL,
  `ev_from` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_approved_by` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_trans` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_remarks` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_entry_date` date DEFAULT NULL,
  `ev_entry_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_year` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_pay_type_acc` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_net_salary_new` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ev_entry_time` datetime DEFAULT NULL,
  `ev_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_cloud_added` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_cloud_edited` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ev_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_expense_voucher`;
CREATE TABLE `tbl_expense_voucher` (
  `ev_id` int(11) NOT NULL AUTO_INCREMENT,
  `ev_date` date DEFAULT NULL,
  `ev_acc_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_from_acc` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_to_acc` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_amount` decimal(15,3) DEFAULT NULL,
  `ev_transaction_data` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_remarks` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_entry_date` date DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ev_entry_time` datetime DEFAULT NULL,
  `ev_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ev_cloud_added` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ev_cloud_edited` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ev_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_expodine_machines`;
CREATE TABLE `tbl_expodine_machines` (
  `cm_id` int(11) NOT NULL AUTO_INCREMENT,
  `cm_ip_address` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cm_ip_port` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cm_ip_folder` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cm_is_server` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cm_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cm_lastupdated_time` datetime DEFAULT NULL,
  `cm_xml_update_found` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cm_xml_update_from_link` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cm_xml_update_found_time` datetime DEFAULT NULL,
  `cm_ip_remarks` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cm_enable_cash_drawer` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cm_cash_drawer_ip` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cm_cash_drawer_port` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cm_cash_drawer_usb` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cm_machine_type` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cm_id`),
  UNIQUE KEY `cm_ip_address` (`cm_ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_extra_tax_master`;
CREATE TABLE `tbl_extra_tax_master` (
  `amc_id` int(11) NOT NULL AUTO_INCREMENT,
  `amc_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `amc_value` decimal(5,2) NOT NULL DEFAULT '0.00',
  `amc_unit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `amc_label` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `amc_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `amc_symbol` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amc_entrydate` datetime DEFAULT NULL,
  `amc_modified_date` datetime DEFAULT NULL,
  `amc_item_tax` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `amc_enable_cs` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `amc_enable_ta` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `amc_enable_hd` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`amc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_feedback_remark_entry`;
CREATE TABLE `tbl_feedback_remark_entry` (
  `tfb_id` int(11) NOT NULL AUTO_INCREMENT,
  `tfb_customer` int(11) DEFAULT NULL,
  `tfb_remarks` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tfb_datetime` datetime DEFAULT NULL,
  `tfb_billno` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tfb_mobile` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tfb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_feedbackmaster`;
CREATE TABLE `tbl_feedbackmaster` (
  `fbm_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fbm_question` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `fbm_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `fbm_branchid` bigint(20) DEFAULT NULL,
  `fbm_avgrating` decimal(2,1) NOT NULL DEFAULT '0.0',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fbm_id`),
  KEY `fbm_branchid` (`fbm_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_feedbackrating`;
CREATE TABLE `tbl_feedbackrating` (
  `fbr_id` int(11) NOT NULL AUTO_INCREMENT,
  `fbr_fbm_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fbr_rate` decimal(2,1) DEFAULT NULL,
  `fbr_table` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fbr_entrytime` datetime DEFAULT NULL,
  `fbr_orderid` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fbr_id`),
  KEY `fbr_fbm_id` (`fbr_fbm_id`),
  KEY `fbr_orderid` (`fbr_orderid`),
  KEY `fbr_table` (`fbr_table`),
  CONSTRAINT `fk_feedbackrating_feedbackid` FOREIGN KEY (`fbr_fbm_id`) REFERENCES `tbl_feedbackmaster` (`fbm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_feedbackratingcount`;
CREATE TABLE `tbl_feedbackratingcount` (
  `frc_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `frc_5star` int(11) NOT NULL DEFAULT '0',
  `frc_4star` int(11) NOT NULL DEFAULT '0',
  `frc_3star` int(11) NOT NULL DEFAULT '0',
  `frc_2star` int(11) NOT NULL DEFAULT '0',
  `frc_1star` int(11) NOT NULL DEFAULT '0',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`frc_menuid`),
  CONSTRAINT `fk_feedratingcount_menuid` FOREIGN KEY (`frc_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `tbl_feedbackratingcount` VALUES ('1','0','0','0','0','0','N'),
('10','0','0','0','0','0','N'),
('100','0','0','0','0','0','N'),
('101','0','0','0','0','0','N'),
('102','0','0','0','0','0','N'),
('103','0','0','0','0','0','N'),
('104','0','0','0','0','0','N'),
('105','0','0','0','0','0','N'),
('106','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('107','0','0','0','0','0','N'),
('108','0','0','0','0','0','N'),
('109','0','0','0','0','0','N'),
('11','0','0','0','0','0','N'),
('110','0','0','0','0','0','N'),
('111','0','0','0','0','0','N'),
('112','0','0','0','0','0','N'),
('113','0','0','0','0','0','N'),
('114','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('115','0','0','0','0','0','N'),
('116','0','0','0','0','0','N'),
('117','0','0','0','0','0','N'),
('118','0','0','0','0','0','N'),
('119','0','0','0','0','0','N'),
('12','0','0','0','0','0','N'),
('120','0','0','0','0','0','N'),
('121','0','0','0','0','0','N'),
('122','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('13','0','0','0','0','0','N'),
('14','0','0','0','0','0','N'),
('15','0','0','0','0','0','N'),
('16','0','0','0','0','0','N'),
('17','0','0','0','0','0','N'),
('18','0','0','0','0','0','N'),
('19','0','0','0','0','0','N'),
('2','0','0','0','0','0','N'),
('20','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('21','0','0','0','0','0','N'),
('22','0','0','0','0','0','N'),
('23','0','0','0','0','0','N'),
('24','0','0','0','0','0','N'),
('25','0','0','0','0','0','N'),
('26','0','0','0','0','0','N'),
('27','0','0','0','0','0','N'),
('28','0','0','0','0','0','N'),
('29','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('3','0','0','0','0','0','N'),
('30','0','0','0','0','0','N'),
('31','0','0','0','0','0','N'),
('32','0','0','0','0','0','N'),
('33','0','0','0','0','0','N'),
('34','0','0','0','0','0','N'),
('35','0','0','0','0','0','N'),
('36','0','0','0','0','0','N'),
('37','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('38','0','0','0','0','0','N'),
('39','0','0','0','0','0','N'),
('4','0','0','0','0','0','N'),
('40','0','0','0','0','0','N'),
('41','0','0','0','0','0','N'),
('42','0','0','0','0','0','N'),
('43','0','0','0','0','0','N'),
('44','0','0','0','0','0','N'),
('45','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('46','0','0','0','0','0','N'),
('47','0','0','0','0','0','N'),
('48','0','0','0','0','0','N'),
('49','0','0','0','0','0','N'),
('5','0','0','0','0','0','N'),
('50','0','0','0','0','0','N'),
('51','0','0','0','0','0','N'),
('52','0','0','0','0','0','N'),
('53','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('54','0','0','0','0','0','N'),
('55','0','0','0','0','0','N'),
('56','0','0','0','0','0','N'),
('57','0','0','0','0','0','N'),
('58','0','0','0','0','0','N'),
('59','0','0','0','0','0','N'),
('6','0','0','0','0','0','N'),
('60','0','0','0','0','0','N'),
('61','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('62','0','0','0','0','0','N'),
('63','0','0','0','0','0','N'),
('64','0','0','0','0','0','N'),
('65','0','0','0','0','0','N'),
('66','0','0','0','0','0','N'),
('67','0','0','0','0','0','N'),
('68','0','0','0','0','0','N'),
('69','0','0','0','0','0','N'),
('7','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('70','0','0','0','0','0','N'),
('71','0','0','0','0','0','N'),
('72','0','0','0','0','0','N'),
('73','0','0','0','0','0','N'),
('74','0','0','0','0','0','N'),
('75','0','0','0','0','0','N'),
('76','0','0','0','0','0','N'),
('77','0','0','0','0','0','N'),
('78','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('79','0','0','0','0','0','N'),
('8','0','0','0','0','0','N'),
('80','0','0','0','0','0','N'),
('81','0','0','0','0','0','N'),
('82','0','0','0','0','0','N'),
('83','0','0','0','0','0','N'),
('84','0','0','0','0','0','N'),
('85','0','0','0','0','0','N'),
('86','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('87','0','0','0','0','0','N'),
('88','0','0','0','0','0','N'),
('89','0','0','0','0','0','N'),
('9','0','0','0','0','0','N'),
('90','0','0','0','0','0','N'),
('91','0','0','0','0','0','N'),
('92','0','0','0','0','0','N'),
('93','0','0','0','0','0','N'),
('94','0','0','0','0','0','N'); 
INSERT INTO `tbl_feedbackratingcount` VALUES ('95','0','0','0','0','0','N'),
('96','0','0','0','0','0','N'),
('97','0','0','0','0','0','N'),
('98','0','0','0','0','0','N'),
('99','0','0','0','0','0','N'); 


DROP TABLE IF EXISTS `tbl_firebase_notification_report`;
CREATE TABLE `tbl_firebase_notification_report` (
  `tf_id` int(11) NOT NULL AUTO_INCREMENT,
  `tf_report_head` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tf_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tf_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_firebase_notification_report` VALUES ('1','Day Open','Y'),
('2','Day Close','Y'),
('3','Bill Cancel','Y'),
('4','Item Cancel','Y'),
('5','Complimentary Settle','Y'),
('6','Credit Settle','Y'),
('7','Timely Report','Y'),
('8','Regenerate','Y'),
('9','Dayclose Revert','Y'); 


DROP TABLE IF EXISTS `tbl_floor_tax`;
CREATE TABLE `tbl_floor_tax` (
  `ft_floorid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ft_tax_id` int(11) NOT NULL,
  `ft_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ft_entry_date` date DEFAULT NULL,
  `ft_modified_date` date DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ft_floorid`,`ft_tax_id`),
  KEY `fk_floortax_taxid` (`ft_tax_id`),
  CONSTRAINT `fk_floortax_floorid` FOREIGN KEY (`ft_floorid`) REFERENCES `tbl_floormaster` (`fr_floorid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_floortax_taxid` FOREIGN KEY (`ft_tax_id`) REFERENCES `tbl_extra_tax_master` (`amc_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_floormaster`;
CREATE TABLE `tbl_floormaster` (
  `fr_floorid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `fr_branchid` bigint(20) NOT NULL,
  `fr_floorname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `fr_status` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `fr_vbill_discount` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `fr_enable_extra_tax` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `fr_extra_prefix` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fr_bill_series` int(11) NOT NULL DEFAULT '1',
  `fr_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `fr_order_display` int(11) DEFAULT NULL,
  `fr_qr_order` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bu_is_central` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fr_floorid`),
  KEY `fr_branchid` (`fr_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_floormaster` VALUES ('1','1','Dine In','Active','Y','N',NULL,'1','Y','N',NULL,'N','N'); 


DROP TABLE IF EXISTS `tbl_food_cost`;
CREATE TABLE `tbl_food_cost` (
  `tfc_id` int(11) NOT NULL AUTO_INCREMENT,
  `tfc_menu` int(11) DEFAULT NULL,
  `tfc_portion` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tfc_ing_menu` int(11) DEFAULT NULL,
  `tfc_qty` decimal(15,3) DEFAULT NULL,
  `tfc_weight` decimal(15,3) DEFAULT NULL,
  `tfc_rate` decimal(15,3) DEFAULT NULL,
  `tfc_total` decimal(15,3) DEFAULT NULL,
  `tfc_date` datetime DEFAULT NULL,
  `tfc_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tfc_di` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tfc_ta` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tfc_hd` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tfc_cs` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tfc_store` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tfc_yield` decimal(15,3) DEFAULT NULL,
  PRIMARY KEY (`tfc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_function_details`;
CREATE TABLE `tbl_function_details` (
  `fd_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fd_reg_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fd_date` date NOT NULL,
  `fd_time` time NOT NULL,
  `fd_session` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fd_function_type` int(11) NOT NULL,
  `fd_venue` int(11) NOT NULL,
  `fd_billing_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fd_no_of_pax` int(11) NOT NULL,
  `fd_per_head_cost` decimal(15,3) NOT NULL,
  `fd_customer` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `fd_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fd_mobile_1` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fd_mobile_2` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fd_landline` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fd_contact_person` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fd_address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `fd_remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `fd_total_rate` float NOT NULL DEFAULT '0',
  `fd_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Open',
  `fd_advance_given` decimal(15,3) NOT NULL DEFAULT '0.000',
  `fd_reg_date` date NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `fd_dayclosedate` date DEFAULT NULL,
  PRIMARY KEY (`fd_id`),
  KEY `fd_function_type` (`fd_function_type`),
  KEY `fd_venue` (`fd_venue`),
  CONSTRAINT `fk_function_type` FOREIGN KEY (`fd_function_type`) REFERENCES `tbl_function_type` (`ft_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_function_venue` FOREIGN KEY (`fd_venue`) REFERENCES `tbl_function_venue` (`fv_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_function_details_menu`;
CREATE TABLE `tbl_function_details_menu` (
  `fdm_function_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fdm_slno` int(11) NOT NULL,
  `fdm_menu` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `fdm_qty` decimal(15,3) NOT NULL DEFAULT '1.000',
  `fdm_unit_rate` float NOT NULL DEFAULT '0',
  `fdm_total_rate` float NOT NULL DEFAULT '0',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fdm_function_id`,`fdm_slno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_function_extra_costs`;
CREATE TABLE `tbl_function_extra_costs` (
  `fec_id` int(11) NOT NULL AUTO_INCREMENT,
  `fec_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fec_cost` decimal(15,3) NOT NULL DEFAULT '0.000',
  `fec_unit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'V',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_function_invoice`;
CREATE TABLE `tbl_function_invoice` (
  `fi_invoice_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fi_function_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fi_total_cost` decimal(15,3) NOT NULL,
  `fi_total_extra_cost` decimal(15,3) NOT NULL,
  `fi_total_discount` decimal(15,3) NOT NULL,
  `fi_total_final_rate` decimal(15,3) NOT NULL,
  `fi_discount_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `fi_paid_by_mode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fi_balance_amt` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fi_invoice_no`),
  UNIQUE KEY `fi_invoice_no` (`fi_invoice_no`,`fi_function_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_function_invoice_extras`;
CREATE TABLE `tbl_function_invoice_extras` (
  `fi_invoice_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fi_slno` int(11) NOT NULL,
  `fi_extra_id` int(11) NOT NULL,
  `fi_extra_cost` decimal(15,3) NOT NULL,
  `fi_extra_rate` decimal(15,3) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fi_invoice_no`,`fi_slno`),
  KEY `fi_extra_id` (`fi_extra_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_function_type`;
CREATE TABLE `tbl_function_type` (
  `ft_id` int(11) NOT NULL AUTO_INCREMENT,
  `ft_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ft_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ft_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_function_venue`;
CREATE TABLE `tbl_function_venue` (
  `fv_id` int(11) NOT NULL AUTO_INCREMENT,
  `fv_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `fv_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_general_settings_log`;
CREATE TABLE `tbl_general_settings_log` (
  `tg_id` int(11) NOT NULL AUTO_INCREMENT,
  `tg_message` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`tg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_general_settings_log` VALUES ('1','Super Admin Settings  have been updated by admin','2026-04-20 11:21:39'),
('2','Super Admin Settings  have been updated by admin','2026-04-20 11:25:23'),
('3','Super Admin Settings  have been updated by admin','2026-04-20 11:26:50'); 


DROP TABLE IF EXISTS `tbl_generalsettings`;
CREATE TABLE `tbl_generalsettings` (
  `be_id` int(11) NOT NULL AUTO_INCREMENT,
  `be_mail_server` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_mail_port` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_mail_emailid` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_mail_password` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_mail_secure` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_mail_from` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_sms_username` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_sms_apipassword` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_sms_senderid` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_sms_domainid` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_sms_priority` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_sms_method` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_merchant_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_collector_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_client_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_client_secret` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_merchant_username` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_merchant_password` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_upi_auth_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_client_hash_salt` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_upi_money_api` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `be_upi_status_api` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `be_sms_api_dynamic` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dynamic_invoice_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_otp` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auto_dayclose_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'N',
  `manual_pref_item` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `ebill_link` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `kot_detail_print` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `accounts_section` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `steward_app_menu_change` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `live_table_cloud` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `overdue_pay_check` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `bill_cancel_cloud` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `dayclose_shifts_name` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otp_bill_cancel` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `otp_item_cancel` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `otp_mail` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shortlink_api` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shortlink_token` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auto_accept_qr` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `amc_otp` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_overdue_date` date DEFAULT '2050-01-01',
  `overdue_crm` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `lock_crm` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `admin_logon_otp` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_otp_validity` time DEFAULT NULL,
  `admin_login_via_otp` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `search_popup_single` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`be_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_generalsettings` VALUES ('1','smtp.gmail.com','587','alerts@expodine.com','ksmr tnqc jqur ytdt','TLS','noreply@expodine.com','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'N','','',NULL,'N','N','N','N','N','N','N','N','N',NULL,'N','N','','https://api-ssl.bitly.com/v4/shorten','1973908bf1947a7dd341e60a3a4fc3ccaeadd790','N',NULL,'2050-01-01','N','N',NULL,NULL,'N','Y'); 


DROP TABLE IF EXISTS `tbl_grn_order`;
CREATE TABLE `tbl_grn_order` (
  `tg_id` int(11) NOT NULL AUTO_INCREMENT,
  `tg_grn_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_dayclosedate` date DEFAULT NULL,
  `tg_product` int(11) DEFAULT NULL,
  `tg_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_unittype` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_weight` decimal(15,3) DEFAULT '0.000',
  `tg_qty` int(11) DEFAULT NULL,
  `tg_unit_rate` decimal(15,3) DEFAULT NULL,
  `tg_total_rate` decimal(15,3) DEFAULT NULL,
  `tg_tax_percent` decimal(15,3) DEFAULT NULL,
  `tg_tax_rate` decimal(15,3) DEFAULT NULL,
  `tg_final_rate` decimal(15,3) DEFAULT NULL,
  `tg_expiry_date` date DEFAULT NULL,
  `tg_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_supplier` int(11) DEFAULT NULL,
  `tg_store` int(11) DEFAULT NULL,
  `tg_set` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tg_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_status_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_status_date` datetime DEFAULT NULL,
  `tg_status` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_direct_transfer` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tg_ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_direct_accept` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tg_accept_direct_by` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_accept_direct_time` datetime DEFAULT NULL,
  `tg_batch_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_grn_summary`;
CREATE TABLE `tbl_grn_summary` (
  `tgs_id` int(11) NOT NULL AUTO_INCREMENT,
  `tgs_grn_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tg_final_total` decimal(15,3) DEFAULT NULL,
  `tg_tax` decimal(15,3) DEFAULT NULL,
  `tg_tax_amount` decimal(15,3) DEFAULT NULL,
  `tg_grand_total` decimal(15,3) DEFAULT NULL,
  `tg_date` date DEFAULT NULL,
  `tgs_invoice_no` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tgs_adjustment` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tgs_ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tgs_remarks` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tgs_edited_time` datetime DEFAULT NULL,
  `tgs_edit_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tgs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_hold_data`;
CREATE TABLE `tbl_hold_data` (
  `th_id` int(11) NOT NULL AUTO_INCREMENT,
  `th_hold_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `th_date` date DEFAULT NULL,
  `th_mode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`th_id`),
  UNIQUE KEY `th_hold_id` (`th_hold_id`,`th_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_indent_partial`;
CREATE TABLE `tbl_indent_partial` (
  `tip_id` int(11) NOT NULL AUTO_INCREMENT,
  `tip_req_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tip_transfer_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tip_qty_weight` decimal(15,3) DEFAULT NULL,
  `tip_date` datetime DEFAULT NULL,
  `tip_menuid` int(11) DEFAULT NULL,
  `tip_done` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_ingredientmaster`;
CREATE TABLE `tbl_ingredientmaster` (
  `ir_ingredientid` bigint(20) NOT NULL,
  `ir_ingredientname` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `ir_headofficeid` bigint(20) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ir_ingredientid`),
  UNIQUE KEY `ir_ingredientname` (`ir_ingredientname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_inv_daily_store_stock`;
CREATE TABLE `tbl_inv_daily_store_stock` (
  `tis_id` int(11) NOT NULL AUTO_INCREMENT,
  `tis_date` date DEFAULT NULL,
  `tis_product` int(11) DEFAULT NULL,
  `tis_weight` decimal(15,3) DEFAULT NULL,
  `tis_qty` decimal(15,3) DEFAULT NULL,
  `tis_rate` decimal(15,3) DEFAULT NULL,
  `tis_tax` decimal(15,3) DEFAULT NULL,
  `tis_total` decimal(15,3) DEFAULT NULL,
  `tis_store` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tis_id`),
  UNIQUE KEY `tis_date` (`tis_date`,`tis_product`,`tis_store`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_inv_kitchen`;
CREATE TABLE `tbl_inv_kitchen` (
  `ti_id` int(11) NOT NULL AUTO_INCREMENT,
  `ti_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ti_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ti_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `central_created` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_in_local` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `central_edited` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ti_id`),
  UNIQUE KEY `ti_name` (`ti_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_inv_settings`;
CREATE TABLE `tbl_inv_settings` (
  `ti_id` int(11) NOT NULL AUTO_INCREMENT,
  `ti_requistion_id` int(11) DEFAULT '1',
  `ti_purchase_id` int(11) DEFAULT '1',
  `ti_grn_id` int(11) DEFAULT '1',
  `ti_transfer_id` int(11) NOT NULL DEFAULT '1',
  `ti_physical_id` int(11) NOT NULL DEFAULT '1',
  `ti_return_id` int(11) DEFAULT '1',
  `ti_consumption_id` int(11) DEFAULT '1',
  `ti_wastage_id` int(11) DEFAULT '1',
  `ti_production_id` int(11) NOT NULL DEFAULT '1',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ti_central_id` int(11) DEFAULT '1',
  PRIMARY KEY (`ti_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_kot_cancellation`;
CREATE TABLE `tbl_kot_cancellation` (
  `kc_cancellation_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `kc_date` date NOT NULL,
  `kc_time` time NOT NULL,
  `kc_table` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `kc_login` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`kc_cancellation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_kotcountermaster`;
CREATE TABLE `tbl_kotcountermaster` (
  `kr_kotcode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `kr_branchid` bigint(20) NOT NULL,
  `kr_kotname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `kr_printerid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kr_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `new_from_cloud` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `central_edited` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `central_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`kr_kotcode`),
  KEY `kr_branchid` (`kr_branchid`),
  KEY `kr_printerid` (`kr_printerid`),
  CONSTRAINT `fk_kotcountermater_branchid` FOREIGN KEY (`kr_branchid`) REFERENCES `tbl_branchmaster` (`be_branchid`),
  CONSTRAINT `fk_kotcountermater_printerid` FOREIGN KEY (`kr_printerid`) REFERENCES `tbl_printersettings` (`pr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_kotcountermaster` VALUES ('1','1','MAIN KITCHEN',NULL,'Y','N','N','N',NULL); 


DROP TABLE IF EXISTS `tbl_kotmaster`;
CREATE TABLE `tbl_kotmaster` (
  `kr_date` date NOT NULL,
  `kr_kotno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `kr_print` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `kr_firstprint` datetime DEFAULT NULL,
  `kr_lastprint` datetime DEFAULT NULL,
  `kr_time` time DEFAULT NULL,
  `kr_mode_of_order` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `kr_order_confirming_staff` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`kr_date`,`kr_kotno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_feedback`;
CREATE TABLE `tbl_language_feedback` (
  `fe_lang_id` int(11) NOT NULL,
  `fe_feedback_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fe_feedback_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`fe_lang_id`,`fe_feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_floor`;
CREATE TABLE `tbl_language_floor` (
  `f_lang_id` int(11) NOT NULL,
  `f_floor_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `f_floor_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`f_lang_id`,`f_floor_id`),
  KEY `fk_language_floorid` (`f_floor_id`),
  CONSTRAINT `fk_language_floor_floor` FOREIGN KEY (`f_floor_id`) REFERENCES `tbl_floormaster` (`fr_floorid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_language_floor_lang_id` FOREIGN KEY (`f_lang_id`) REFERENCES `tbl_languages` (`ls_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_menu_main`;
CREATE TABLE `tbl_language_menu_main` (
  `mm_lang_id` int(11) NOT NULL,
  `mm_categoryid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mm_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`mm_lang_id`,`mm_categoryid`),
  KEY `fk_language_mmc` (`mm_categoryid`),
  CONSTRAINT `fk_language_menu_main_catid` FOREIGN KEY (`mm_categoryid`) REFERENCES `tbl_menumaincategory` (`mmy_maincategoryid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_language_menu_main_langid` FOREIGN KEY (`mm_lang_id`) REFERENCES `tbl_languages` (`ls_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_menu_master`;
CREATE TABLE `tbl_language_menu_master` (
  `lm_language_id` int(11) NOT NULL,
  `lm_menu_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lm_menu_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lm_menu_print` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lm_menu_description` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lm_menu_diet` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lm_menu_prepmode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`lm_language_id`,`lm_menu_id`),
  KEY `fk_language_menu` (`lm_menu_id`),
  CONSTRAINT `fk_language_menu_master_langid` FOREIGN KEY (`lm_language_id`) REFERENCES `tbl_languages` (`ls_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_language_menu_master_menuid` FOREIGN KEY (`lm_menu_id`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_menu_sub`;
CREATE TABLE `tbl_language_menu_sub` (
  `mm_lang_id` int(11) NOT NULL,
  `mm_sub_category_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mm_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`mm_lang_id`,`mm_sub_category_id`),
  KEY `fk_language_menu_sub_subid` (`mm_sub_category_id`),
  CONSTRAINT `fk_language_menu_sub_langid` FOREIGN KEY (`mm_lang_id`) REFERENCES `tbl_languages` (`ls_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_language_menu_sub_subid` FOREIGN KEY (`mm_sub_category_id`) REFERENCES `tbl_menusubcategory` (`msy_subcategoryid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_portion`;
CREATE TABLE `tbl_language_portion` (
  `lm_language_id` int(11) NOT NULL,
  `lm_portion_id` int(11) NOT NULL,
  `lm_portion_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`lm_language_id`,`lm_portion_id`),
  KEY `fk_language_portion_name` (`lm_portion_id`),
  CONSTRAINT `fk_language_portion_langid` FOREIGN KEY (`lm_language_id`) REFERENCES `tbl_languages` (`ls_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_language_portion_portionid` FOREIGN KEY (`lm_portion_id`) REFERENCES `tbl_portionmaster` (`pm_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_preference`;
CREATE TABLE `tbl_language_preference` (
  `l_lang_id` int(11) NOT NULL,
  `l_pref_id` int(11) NOT NULL,
  `l_pref_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`l_lang_id`,`l_pref_id`),
  KEY `fk_language_preference_pref_id` (`l_pref_id`),
  CONSTRAINT `fk_language_preference_lang_id` FOREIGN KEY (`l_lang_id`) REFERENCES `tbl_languages` (`ls_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_language_preference_pref_id` FOREIGN KEY (`l_pref_id`) REFERENCES `tbl_preferencemaster` (`pmr_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_staff`;
CREATE TABLE `tbl_language_staff` (
  `s_lang_id` int(11) NOT NULL,
  `s_staff_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `s_staff_first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `s_staff_last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`s_lang_id`,`s_staff_id`),
  KEY `fk_language_staff_staffid` (`s_staff_id`),
  CONSTRAINT `fk_language_staff_langid` FOREIGN KEY (`s_lang_id`) REFERENCES `tbl_languages` (`ls_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_language_staff_staffid` FOREIGN KEY (`s_staff_id`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_language_table_master`;
CREATE TABLE `tbl_language_table_master` (
  `t_lang_id` int(11) NOT NULL,
  `t_table_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `t_table_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`t_lang_id`,`t_table_id`),
  KEY `fk_language_table_tableid` (`t_table_id`),
  CONSTRAINT `fk_language_table_langid` FOREIGN KEY (`t_lang_id`) REFERENCES `tbl_languages` (`ls_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_language_table_tableid` FOREIGN KEY (`t_table_id`) REFERENCES `tbl_tablemaster` (`tr_tableid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_languages`;
CREATE TABLE `tbl_languages` (
  `ls_id` int(11) NOT NULL AUTO_INCREMENT,
  `ls_language` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ls_shortcode` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ls_status` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ls_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_languages` VALUES ('1','english',NULL,'Y'),
('2','arabic',NULL,'N'); 


DROP TABLE IF EXISTS `tbl_ledger_group`;
CREATE TABLE `tbl_ledger_group` (
  `tlg_id` int(11) NOT NULL AUTO_INCREMENT,
  `tlg_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlg_status` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `tlg_group_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlg_exp_inc_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_edited` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_edited_by` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tlg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_ledger_group` VALUES ('1','Current Assets','Y','asset',NULL,'N',NULL,NULL),
('2','Fixed Assets','Y','asset',NULL,'N',NULL,NULL),
('3','Current Liability','Y','liability',NULL,'N',NULL,NULL),
('4','Direct Expense','Y',NULL,'expense','N',NULL,NULL),
('5','Indirect Expense','Y',NULL,'expense','N',NULL,NULL); 
INSERT INTO `tbl_ledger_group` VALUES ('6','Direct Income','Y',NULL,'income','N',NULL,NULL),
('7','Indirect Income','Y',NULL,'income','N',NULL,NULL),
('8','Purchase Acc','Y',NULL,'expense','N',NULL,NULL),
('9','Sales Acc','Y',NULL,'income','N',NULL,NULL),
('10','Capital Account','Y','liability',NULL,'N',NULL,NULL); 
INSERT INTO `tbl_ledger_group` VALUES ('11','Investments','Y','asset',NULL,'N',NULL,NULL),
('12','Loan (Liability)','Y','liability',NULL,'N',NULL,NULL),
('13','Sales Return','Y',NULL,'expense','N',NULL,NULL),
('14','Purchase Return','Y',NULL,'income','N',NULL,NULL),
('15','Deposits (Assets)','Y','asset',NULL,'N',NULL,NULL); 
INSERT INTO `tbl_ledger_group` VALUES ('16','Cash in Hand','Y','asset',NULL,'N',NULL,NULL),
('17','Bank Accounts','Y','asset',NULL,'N',NULL,NULL),
('18','Sundry Debtors','Y','asset',NULL,'N',NULL,NULL),
('19','Bank OD/CC ACC','Y','liability',NULL,'N',NULL,NULL),
('20','Sundry Creditors','Y','liability',NULL,'N',NULL,NULL); 
INSERT INTO `tbl_ledger_group` VALUES ('21','Loans and Advances','Y','asset',NULL,'N',NULL,NULL); 


DROP TABLE IF EXISTS `tbl_ledger_master`;
CREATE TABLE `tbl_ledger_master` (
  `tlm_id` int(11) NOT NULL AUTO_INCREMENT,
  `tlm_ledger_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlm_group` int(11) NOT NULL,
  `tlm_open_bal` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tlm_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT 'Normal',
  `tlm_vendor_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlm_staff_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlm_guest_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlm_company_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlm_close_bal` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tlm_capital_cb` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tlm_cloud_add` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tlm_cloud_add_by` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlm_cloud_edit` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tlm_cloud_edit_by` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tlm_id`),
  UNIQUE KEY `tlm_ledger_name` (`tlm_ledger_name`)
) ENGINE=MyISAM AUTO_INCREMENT=433 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_ledger_openbal_log`;
CREATE TABLE `tbl_ledger_openbal_log` (
  `top_id` int(11) NOT NULL AUTO_INCREMENT,
  `top_ledger` int(11) DEFAULT NULL,
  `top_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_date` datetime DEFAULT NULL,
  `top_amount_now` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`top_id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_ledger_setting`;
CREATE TABLE `tbl_ledger_setting` (
  `tps_id` int(11) NOT NULL AUTO_INCREMENT,
  `tps_ledger_id` int(11) DEFAULT NULL,
  `tps_ledger_open_bal` decimal(15,3) DEFAULT NULL,
  `tps_closing_balance` decimal(15,3) DEFAULT NULL,
  `tps_dayclosedate` date DEFAULT NULL,
  `tps_open_bal_updated` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tps_id`),
  UNIQUE KEY `tps_ledger_id` (`tps_ledger_id`,`tps_dayclosedate`),
  UNIQUE KEY `tps_ledger_id_2` (`tps_ledger_id`,`tps_dayclosedate`)
) ENGINE=MyISAM AUTO_INCREMENT=52662 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_loan_advance`;
CREATE TABLE `tbl_loan_advance` (
  `tla_id` int(11) NOT NULL AUTO_INCREMENT,
  `tla_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tla_acc_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tla_date` date DEFAULT NULL,
  `tla_from` int(11) DEFAULT NULL,
  `tla_to` int(11) DEFAULT NULL,
  `tla_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tla_paid` decimal(15,3) DEFAULT NULL,
  `tla_transaction` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tla_particulars` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tla_receive` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tla_entry_date` datetime DEFAULT NULL,
  `tla_pay_entry` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tla_voucher_no` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tla_main_acc` int(11) DEFAULT NULL,
  PRIMARY KEY (`tla_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_login_restrict_logs`;
CREATE TABLE `tbl_login_restrict_logs` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_date` datetime NOT NULL,
  `r_message` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_logindetails`;
CREATE TABLE `tbl_logindetails` (
  `ls_username` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `ls_password` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `ls_branchid` bigint(20) DEFAULT NULL,
  `ls_applogin` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ls_staffid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ls_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ls_restrict_login` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ls_login_status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ls_login_time` datetime DEFAULT NULL,
  `ls_logout_time` datetime DEFAULT NULL,
  `ls_login_machineip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ls_username`),
  UNIQUE KEY `ls_branchid_2` (`ls_branchid`,`ls_staffid`),
  UNIQUE KEY `ls_headofficeid_2` (`ls_staffid`),
  UNIQUE KEY `ls_staffid_2` (`ls_staffid`),
  KEY `ls_branchid` (`ls_branchid`),
  KEY `ls_staffid` (`ls_staffid`),
  CONSTRAINT `fk_logindetails_branchid` FOREIGN KEY (`ls_branchid`) REFERENCES `tbl_branchmaster` (`be_branchid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_logindetails_staffid` FOREIGN KEY (`ls_staffid`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `tbl_logindetails` VALUES ('Accountant','567fac0b4d21b7c285272bd515f68ee4','1','Y','7','Y','N',NULL,NULL,NULL,NULL,'N'),
('admin','e6e061838856bf47e1de730719fb2609','1','Y','1','Y','N','Y','2026-04-20 11:30:53',NULL,'192.168.0.139','N'),
('cashier','6ac2470ed8ccf204fd5ff89b32a355cf','1','N','3','Y','N',NULL,NULL,NULL,NULL,'N'); 
INSERT INTO `tbl_logindetails` VALUES ('Delivery Boy','567fac0b4d21b7c285272bd515f68ee4','1','Y','6','Y','N',NULL,NULL,NULL,NULL,'N'),
('manager','1d0258c2440a8d19e716292b231e3190','1','Y','2','Y','N',NULL,NULL,NULL,NULL,'N'),
('steward1','567fac0b4d21b7c285272bd515f68ee4','1','Y','4','Y','N','Y','2026-04-20 11:23:59',NULL,'192.168.0.49','N'); 
INSERT INTO `tbl_logindetails` VALUES ('Store Manager','567fac0b4d21b7c285272bd515f68ee4','1','Y','5','Y','N',NULL,NULL,NULL,NULL,'N'); 


DROP TABLE IF EXISTS `tbl_loy_coupon`;
CREATE TABLE `tbl_loy_coupon` (
  `tlc_id` int(11) NOT NULL AUTO_INCREMENT,
  `tlc_coupon_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlc_coupon_from` date DEFAULT NULL,
  `tlc_to` date DEFAULT NULL,
  `tlc_code` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlc_customer` int(11) DEFAULT NULL,
  `tlc_status` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tlc_date` date DEFAULT NULL,
  `tlc_value` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`tlc_id`),
  UNIQUE KEY `tlc_coupon_name` (`tlc_coupon_name`,`tlc_code`,`tlc_customer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_loyalty_campaign`;
CREATE TABLE `tbl_loyalty_campaign` (
  `lc_id` int(11) NOT NULL AUTO_INCREMENT,
  `lc_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lc_from` date NOT NULL,
  `lc_to` date NOT NULL,
  `lc_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `lc_condent` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`lc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_loyalty_campaign_group`;
CREATE TABLE `tbl_loyalty_campaign_group` (
  `gp_id` int(11) NOT NULL AUTO_INCREMENT,
  `gp_groupname` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gp_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `gp_value` decimal(6,3) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`gp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_loyalty_discount`;
CREATE TABLE `tbl_loyalty_discount` (
  `ld_visitcount` int(11) NOT NULL,
  `ld_discount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `ld_type` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ld_visitcount`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_loyalty_group_details`;
CREATE TABLE `tbl_loyalty_group_details` (
  `tgp_groupid` int(11) NOT NULL,
  `tgp_customerid` int(11) NOT NULL,
  `tgp_groupcode` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tgp_datetime` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tgp_code_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `tgp_campaign_id` int(11) NOT NULL,
  `tgp_id` int(11) NOT NULL AUTO_INCREMENT,
  `tgp_bill_amount` decimal(15,3) DEFAULT NULL,
  `tgp_coupon_amount` decimal(15,3) DEFAULT NULL,
  `tgp_bill_date_time` datetime DEFAULT NULL,
  `tgp_billno` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tgp_id`),
  UNIQUE KEY `tgp_groupid` (`tgp_groupid`,`tgp_customerid`,`tgp_campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_loyalty_levels`;
CREATE TABLE `tbl_loyalty_levels` (
  `ll_id` int(11) NOT NULL AUTO_INCREMENT,
  `ll_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ll_description` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ll_condition_value` int(11) DEFAULT NULL,
  `ll_reward_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ll_reward_code` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ll_reward_value` int(11) DEFAULT NULL,
  `ll_minorder_value` int(11) DEFAULT NULL,
  `ll_customers` int(11) DEFAULT NULL,
  `ll_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ll_special_rewards` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_loyalty_point_transfers`;
CREATE TABLE `tbl_loyalty_point_transfers` (
  `lpt_id` int(11) NOT NULL AUTO_INCREMENT,
  `lpt_from_id` int(11) NOT NULL,
  `lpt_to_id` int(11) NOT NULL,
  `lpt_points` int(11) NOT NULL,
  `lpt_reason` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lpt_secret_key` int(11) DEFAULT NULL,
  `lpt_date` datetime NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`lpt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_loyalty_pointadd_bill`;
CREATE TABLE `tbl_loyalty_pointadd_bill` (
  `lob_id` int(11) NOT NULL AUTO_INCREMENT,
  `lob_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `lob_bill_amount` decimal(15,3) DEFAULT NULL,
  `lob_point_add` decimal(15,2) DEFAULT NULL,
  `lob_point_redeem` decimal(15,2) DEFAULT NULL,
  `lob_redeem_amount` decimal(15,3) DEFAULT NULL,
  `lob_date` datetime DEFAULT NULL,
  `lob_loyalty_customer` int(11) DEFAULT NULL,
  `lob_mode` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`lob_id`),
  UNIQUE KEY `lob_billno` (`lob_billno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_loyalty_pointrule`;
CREATE TABLE `tbl_loyalty_pointrule` (
  `lyp_id` int(11) NOT NULL AUTO_INCREMENT,
  `lyp_point` decimal(15,2) DEFAULT NULL,
  `lyp_amount` decimal(15,3) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`lyp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_loyalty_redeem_rule`;
CREATE TABLE `tbl_loyalty_redeem_rule` (
  `lyr_id` int(11) NOT NULL AUTO_INCREMENT,
  `lyr_point` decimal(15,2) DEFAULT NULL,
  `lyr_amount` decimal(15,3) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`lyr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_loyalty_reg`;
CREATE TABLE `tbl_loyalty_reg` (
  `ly_id` int(11) NOT NULL AUTO_INCREMENT,
  `ly_firstname` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `ly_lastname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_gender` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_mobileno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_emailid` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_birthdaydate` date DEFAULT NULL,
  `ly_maritalstatus` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_anniversarydate` date DEFAULT NULL,
  `ly_profession` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_totalvisit` int(11) NOT NULL DEFAULT '0',
  `ly_mailreceive` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ly_smsreceive` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ly_entrydatetime` datetime DEFAULT NULL,
  `ly_branchid` int(11) DEFAULT '1',
  `ly_status` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `ly_entry_from` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Credit',
  `ly_points` decimal(15,2) DEFAULT '0.00',
  `ly_voucher_count` int(11) NOT NULL DEFAULT '1',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ly_loy_dayclose` date DEFAULT NULL,
  `ly_loy_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_gst` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_default` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_module` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_customer_table` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_customer_floor` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_otp` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_discount` decimal(15,3) DEFAULT NULL,
  PRIMARY KEY (`ly_id`),
  UNIQUE KEY `ly_firstname` (`ly_firstname`,`ly_mobileno`),
  KEY `name_index` (`ly_firstname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_loyalty_rules`;
CREATE TABLE `tbl_loyalty_rules` (
  `lr_id` int(11) NOT NULL AUTO_INCREMENT,
  `lr_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lr_description` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lr_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `lr_start_at` date NOT NULL,
  `lr_end_at` date NOT NULL,
  `lr_type` int(11) NOT NULL,
  `lr_bill_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `lr_redemption_min_point` int(11) NOT NULL DEFAULT '0',
  `lr_redemption_cash_value` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`lr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_loyalty_rules_type`;
CREATE TABLE `tbl_loyalty_rules_type` (
  `lrt_id` int(11) NOT NULL AUTO_INCREMENT,
  `lrt_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lrt_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`lrt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_loyalty_sendto`;
CREATE TABLE `tbl_loyalty_sendto` (
  `ls_id` int(11) NOT NULL AUTO_INCREMENT,
  `ls_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ls_query` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ls_selected` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ls_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_loyalty_sms_source`;
CREATE TABLE `tbl_loyalty_sms_source` (
  `ls_id` int(11) NOT NULL AUTO_INCREMENT,
  `ls_sms_data` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ls_date_sendon` datetime DEFAULT NULL,
  `ls_login_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ls_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_loyalty_voucher`;
CREATE TABLE `tbl_loyalty_voucher` (
  `vr_voucherid` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `vr_vouchername` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `vr_voucherfrom` date NOT NULL,
  `vr_voucherexpiry` date NOT NULL,
  `vr_vouchercost` decimal(15,2) NOT NULL DEFAULT '0.00',
  `vr_vouchercost_unit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'V',
  `vr_voucherholder` int(11) NOT NULL,
  `vr_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`vr_voucherid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menu_addons`;
CREATE TABLE `tbl_menu_addons` (
  `ma_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ma_addon_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ma_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ma_menuid`,`ma_addon_menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_menu_discount`;
CREATE TABLE `tbl_menu_discount` (
  `md_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `md_slno` int(11) NOT NULL,
  `md_discount` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `md_date_limit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `md_time_limit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `md_day_limit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `md_day` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `md_from_date` date DEFAULT NULL,
  `md_to_date` date DEFAULT NULL,
  `md_di_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `md_cs_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `md_ta_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `md_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `md_from_time` time DEFAULT NULL,
  `md_to_time` time DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `md_cloud_added` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `md_cloud_edited` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`md_menuid`,`md_slno`),
  KEY `fk_menud_discount_id` (`md_discount`),
  CONSTRAINT `fk_menud_discount_id` FOREIGN KEY (`md_discount`) REFERENCES `tbl_discountmaster` (`ds_discountid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_menud_discount_menudis` FOREIGN KEY (`md_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_menu_import`;
CREATE TABLE `tbl_menu_import` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CATEGORY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SUB_CATEGORY` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MENU_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `MENU_CODE` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KOT_KITCHEN` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `DIET` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TYPE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNIT` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEIGHT` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RATE_1` float NOT NULL DEFAULT '0',
  `RATE_2` float NOT NULL DEFAULT '0',
  `RATE_3` float NOT NULL DEFAULT '0',
  `RATE_4` float NOT NULL DEFAULT '0',
  `RATE_5` float NOT NULL DEFAULT '0',
  `RATE_6` float NOT NULL DEFAULT '0',
  `DYNAMIC_RATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DAILY_STOCK` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `STOCK_IN_NUMBERS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ESTIMATED_TIME` tinyint(4) NOT NULL DEFAULT '10',
  `PREPARATION_MODE` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'General',
  `CATEGORY_ID` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUB_CATEGORY_ID` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KOT_COUNTER_ID` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MENU_ID` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNIT_ID` int(11) DEFAULT NULL,
  `FLOOR_ID_1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FLOOR_ID_2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FLOOR_ID_3` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FLOOR_ID_4` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FLOOR_ID_5` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ITEM_SHORTCODE` varchar(17) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_menu_import` VALUES ('1','FRIES','','French Fries',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'90','0','0','0','0','0','N','Y','N','10','General','1','1','1','47','1','1',NULL,NULL,NULL,NULL,'French Fries','N'),
('2','FRIES','','Spicy Fries',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'100','0','0','0','0','0','N','Y','N','10','General','1','1','1','103','1','1',NULL,NULL,NULL,NULL,'Spicy Fries','N'); 
INSERT INTO `tbl_menu_import` VALUES ('3','FRIES','','Nuggets',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'120','0','0','0','0','0','N','Y','N','10','General','1','1','1','76','1','1',NULL,NULL,NULL,NULL,'Nuggets','N'),
('4','LOADER','','Loader Fries',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'140','0','0','0','0','0','N','Y','N','10','General','2','1','1','66','1','1',NULL,NULL,NULL,NULL,'Loader Fries','N'); 
INSERT INTO `tbl_menu_import` VALUES ('5','LOADER','','Dirty Cheese Fries',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'160','0','0','0','0','0','N','Y','N','10','General','2','1','1','40','1','1',NULL,NULL,NULL,NULL,'Dirty Cheese Fri','N'),
('6','LOADER','','Beef Loader',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'180','0','0','0','0','0','N','Y','N','10','General','2','1','1','10','1','1',NULL,NULL,NULL,NULL,'Beef Loader','N'); 
INSERT INTO `tbl_menu_import` VALUES ('7','POPCORN','','Chicken Popcorn',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'150','0','0','0','0','0','N','Y','N','10','General','3','1','1','29','1','1',NULL,NULL,NULL,NULL,'Chicken Popcorn','N'),
('8','POPCORN','','Mexican Popcorn',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'160','0','0','0','0','0','N','Y','N','10','General','3','1','1','70','1','1',NULL,NULL,NULL,NULL,'Mexican Popcorn','N'); 
INSERT INTO `tbl_menu_import` VALUES ('9','POPCORN','','Dynamic Chicken',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'190','0','0','0','0','0','N','Y','N','10','General','3','1','1','43','1','1',NULL,NULL,NULL,NULL,'Dynamic Chicken','N'),
('10','BURGER','','Veg Burger',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'110','0','0','0','0','0','N','Y','N','10','General','4','1','1','113','1','1',NULL,NULL,NULL,NULL,'Veg Burger','N'); 
INSERT INTO `tbl_menu_import` VALUES ('11','BURGER','','Grilled Burger',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'130','0','0','0','0','0','N','Y','N','10','General','4','1','1','54','1','1',NULL,NULL,NULL,NULL,'Grilled Burger','N'),
('12','BURGER','','BBQ Burger',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'140','0','0','0','0','0','N','Y','N','10','General','4','1','1','4','1','1',NULL,NULL,NULL,NULL,'BBQ Burger','N'); 
INSERT INTO `tbl_menu_import` VALUES ('13','BURGER','','Zinger Burger',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'140','0','0','0','0','0','N','Y','N','10','General','4','1','1','120','1','1',NULL,NULL,NULL,NULL,'Zinger Burger','N'),
('14','BURGER','','Royal Burger',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'180','0','0','0','0','0','N','Y','N','10','General','4','1','1','91','1','1',NULL,NULL,NULL,NULL,'Royal Burger','N'); 
INSERT INTO `tbl_menu_import` VALUES ('15','BURGER','','Beef Special Burger',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'180','0','0','0','0','0','N','Y','N','10','General','4','1','1','11','1','1',NULL,NULL,NULL,NULL,'Beef Special Bur','N'),
('16','BURGER','','Tower Burger',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'220','0','0','0','0','0','N','Y','N','10','General','4','1','1','111','1','1',NULL,NULL,NULL,NULL,'Tower Burger','N'); 
INSERT INTO `tbl_menu_import` VALUES ('17','BURGER','','Sizzler Burger',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'200','0','0','0','0','0','N','Y','N','10','General','4','1','1','100','1','1',NULL,NULL,NULL,NULL,'Sizzler Burger','N'),
('18','WRAPS','','Veg Wrap',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'100','0','0','0','0','0','N','Y','N','10','General','5','1','1','117','1','1',NULL,NULL,NULL,NULL,'Veg Wrap','N'); 
INSERT INTO `tbl_menu_import` VALUES ('19','WRAPS','','Zinger Wrap',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'130','0','0','0','0','0','N','Y','N','10','General','5','1','1','122','1','1',NULL,NULL,NULL,NULL,'Zinger Wrap','N'),
('20','WRAPS','','Grilled Wrap',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'120','0','0','0','0','0','N','Y','N','10','General','5','1','1','57','1','1',NULL,NULL,NULL,NULL,'Grilled Wrap','N'); 
INSERT INTO `tbl_menu_import` VALUES ('21','WRAPS','','BBQ Wraps',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'140','0','0','0','0','0','N','Y','N','10','General','5','1','1','9','1','1',NULL,NULL,NULL,NULL,'BBQ Wraps','N'),
('22','WRAPS','','Chicken Fajita',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'160','0','0','0','0','0','N','Y','N','10','General','5','1','1','24','1','1',NULL,NULL,NULL,NULL,'Chicken Fajita','N'); 
INSERT INTO `tbl_menu_import` VALUES ('23','CLUB','','Veg Club Sandwich',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'120','0','0','0','0','0','N','Y','N','10','General','6','1','1','114','1','1',NULL,NULL,NULL,NULL,'Veg Club Sandwic','N'),
('24','CLUB','','Grilled Club Sandwich',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'160','0','0','0','0','0','N','Y','N','10','General','6','1','1','55','1','1',NULL,NULL,NULL,NULL,'Grilled Club San','N'); 
INSERT INTO `tbl_menu_import` VALUES ('25','CLUB','','Zinger Club Sandwich',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'170','0','0','0','0','0','N','Y','N','10','General','6','1','1','121','1','1',NULL,NULL,NULL,NULL,'Zinger Club Sand','N'),
('26','CLUB','','Chicken Steak Club',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'180','0','0','0','0','0','N','Y','N','10','General','6','1','1','30','1','1',NULL,NULL,NULL,NULL,'Chicken Steak Cl','N'); 
INSERT INTO `tbl_menu_import` VALUES ('27','SANDWICH','','Veg Sandwich',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'100','0','0','0','0','0','N','Y','N','10','General','7','1','1','116','1','1',NULL,NULL,NULL,NULL,'Veg Sandwich','N'),
('28','SANDWICH','','Grilled Sandwich',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'110','0','0','0','0','0','N','Y','N','10','General','7','1','1','56','1','1',NULL,NULL,NULL,NULL,'Grilled Sandwich','N'); 
INSERT INTO `tbl_menu_import` VALUES ('29','SANDWICH','','BBQ Sandwich',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'120','0','0','0','0','0','N','Y','N','10','General','7','1','1','7','1','1',NULL,NULL,NULL,NULL,'BBQ Sandwich','N'),
('30','LOLLIPOP','','Chicken Lollipop 5 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'159','0','0','0','0','0','N','Y','N','10','General','8','1','1','27','1','1',NULL,NULL,NULL,NULL,'Chicken Lollipop','N'); 
INSERT INTO `tbl_menu_import` VALUES ('31','LOLLIPOP','','BBQ Lollipop 5 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'169','0','0','0','0','0','N','Y','N','10','General','8','1','1','5','1','1',NULL,NULL,NULL,NULL,'BBQ Lollipop 5 p','N'),
('32','LOLLIPOP','','Schezwan Lollipop 5 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'174','0','0','0','0','0','N','Y','N','10','General','8','1','1','95','1','1',NULL,NULL,NULL,NULL,'Schezwan Lollipo','N'); 
INSERT INTO `tbl_menu_import` VALUES ('33','MOMOS','','Veg Momo',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'1','0','0','0','0','0','Y','Y','N','10','General','9','1','1','115','1','1',NULL,NULL,NULL,NULL,'Veg Momo','N'),
('34','MOMOS','','Chicken Steam Momos H',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'89','0','0','0','0','0','N','Y','N','10','General','9','1','1','32','1','1',NULL,NULL,NULL,NULL,'Chicken Steam Mo','N'); 
INSERT INTO `tbl_menu_import` VALUES ('35','MOMOS','','Chicken Steam Momos F',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'119','0','0','0','0','0','N','Y','N','10','General','9','1','1','31','1','1',NULL,NULL,NULL,NULL,'Chicken Steam Mo','N'),
('36','MOMOS','','Chicken Fried Momos  H',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'99','0','0','0','0','0','N','Y','N','10','General','9','1','1','25','1','1',NULL,NULL,NULL,NULL,'Chicken Fried Mo','N'); 
INSERT INTO `tbl_menu_import` VALUES ('37','MOMOS','','Chicken Fried Momos F',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'129','0','0','0','0','0','N','Y','N','10','General','9','1','1','26','1','1',NULL,NULL,NULL,NULL,'Chicken Fried Mo','N'),
('38','MOMOS','','Peri Peri Fried Momo H',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'109','0','0','0','0','0','N','Y','N','10','General','9','1','1','85','1','1',NULL,NULL,NULL,NULL,'Peri Peri Fried','N'); 
INSERT INTO `tbl_menu_import` VALUES ('39','MOMOS','','Peri Peri Fried Momo F',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'139','0','0','0','0','0','N','Y','N','10','General','9','1','1','84','1','1',NULL,NULL,NULL,NULL,'Peri Peri Fried','N'),
('40','MOMOS','','Schezwan Fried Momo H',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'119','0','0','0','0','0','N','Y','N','10','General','9','1','1','94','1','1',NULL,NULL,NULL,NULL,'Schezwan Fried M','N'); 
INSERT INTO `tbl_menu_import` VALUES ('41','MOMOS','','Schezwan Fried Momo F',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'149','0','0','0','0','0','N','Y','N','10','General','9','1','1','93','1','1',NULL,NULL,NULL,NULL,'Schezwan Fried M','N'),
('42','MOMOS','','Dynamite Momo H',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'129','0','0','0','0','0','N','Y','N','10','General','9','1','1','45','1','1',NULL,NULL,NULL,NULL,'Dynamite Momo H','N'); 
INSERT INTO `tbl_menu_import` VALUES ('43','MOMOS','','Dynamite Momo F',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'159','0','0','0','0','0','N','Y','N','10','General','9','1','1','44','1','1',NULL,NULL,NULL,NULL,'Dynamite Momo F','N'),
('44','MOMOS','','Cheesy Momo H',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'159','0','0','0','0','0','N','Y','N','10','General','9','1','1','22','1','1',NULL,NULL,NULL,NULL,'Cheesy Momo H','N'); 
INSERT INTO `tbl_menu_import` VALUES ('45','MOMOS','','Cheesy Momo F',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'199','0','0','0','0','0','N','Y','N','10','General','9','1','1','21','1','1',NULL,NULL,NULL,NULL,'Cheesy Momo F','N'),
('46','STRIPS','','Buffalo Chicken 3 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'180','0','0','0','0','0','N','Y','N','10','General','10','1','1','17','1','1',NULL,NULL,NULL,NULL,'Buffalo Chicken','N'); 
INSERT INTO `tbl_menu_import` VALUES ('47','STRIPS','','Buffalo Chicken 6 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'299','0','0','0','0','0','N','Y','N','10','General','10','1','1','18','1','1',NULL,NULL,NULL,NULL,'Buffalo Chicken','N'),
('48','STRIPS','','Chicken Strips 6 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'229','0','0','0','0','0','N','Y','N','10','General','10','1','1','33','1','1',NULL,NULL,NULL,NULL,'Chicken Strips 6','N'); 
INSERT INTO `tbl_menu_import` VALUES ('49','STRIPS','','Peri Peri Strips 6 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'249','0','0','0','0','0','N','Y','N','10','General','10','1','1','86','1','1',NULL,NULL,NULL,NULL,'Peri Peri Strips','N'),
('50','STRIPS','','Dragon Chicken',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'199','0','0','0','0','0','N','Y','N','10','General','10','1','1','41','1','1',NULL,NULL,NULL,NULL,'Dragon Chicken','N'); 
INSERT INTO `tbl_menu_import` VALUES ('51','WINGS','','Hot Wings 5 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'139','0','0','0','0','0','N','Y','N','10','General','11','1','1','59','1','1',NULL,NULL,NULL,NULL,'Hot Wings 5 pcs','N'),
('52','WINGS','','BBQ Wings 5 pcs',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'149','0','0','0','0','0','N','Y','N','10','General','11','1','1','8','1','1',NULL,NULL,NULL,NULL,'BBQ Wings 5 pcs','N'); 
INSERT INTO `tbl_menu_import` VALUES ('53','WINGS','','Schezwan Wings',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'149','0','0','0','0','0','N','Y','N','10','General','11','1','1','96','1','1',NULL,NULL,NULL,NULL,'Schezwan Wings','N'),
('54','PASTA','','Chicken Alfredo Pasta',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'199','0','0','0','0','0','N','Y','N','10','General','12','1','1','23','1','1',NULL,NULL,NULL,NULL,'Chicken Alfredo','N'); 
INSERT INTO `tbl_menu_import` VALUES ('55','PASTA','','Red Sauce Arabian Past',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'219','0','0','0','0','0','N','Y','N','10','General','12','1','1','90','1','1',NULL,NULL,NULL,NULL,'Red Sauce Arabia','N'),
('56','PASTA','','Chicken Macaroni',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'189','0','0','0','0','0','N','Y','N','10','General','12','1','1','28','1','1',NULL,NULL,NULL,NULL,'Chicken Macaroni','N'); 
INSERT INTO `tbl_menu_import` VALUES ('57','PIZZA','','Tandoori Pizza Large',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'349','0','0','0','0','0','N','Y','N','10','General','13','1','1','108','1','1',NULL,NULL,NULL,NULL,'Tandoori Pizza L','N'),
('58','PIZZA','','BBQ Pizza',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'319','0','0','0','0','0','N','Y','N','10','General','13','1','1','6','1','1',NULL,NULL,NULL,NULL,'BBQ Pizza','N'); 
INSERT INTO `tbl_menu_import` VALUES ('59','PIZZA','','Loader Castal Special Pizza',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'399','0','0','0','0','0','N','Y','N','10','General','13','1','1','65','1','1',NULL,NULL,NULL,NULL,'Loader Castal Sp','N'),
('60','FRESH JUICE','','Orange Juice',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'60','0','0','0','0','0','N','Y','N','10','General','14','1','1','78','1','1',NULL,NULL,NULL,NULL,'Orange Juice','N'); 
INSERT INTO `tbl_menu_import` VALUES ('61','FRESH JUICE','','Pineapple Juice',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'60','0','0','0','0','0','N','Y','N','10','General','14','1','1','87','1','1',NULL,NULL,NULL,NULL,'Pineapple Juice','N'),
('62','FRESH JUICE','','Apple Juice',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'60','0','0','0','0','0','N','Y','N','10','General','14','1','1','3','1','1',NULL,NULL,NULL,NULL,'Apple Juice','N'); 
INSERT INTO `tbl_menu_import` VALUES ('63','FRESH JUICE','','Watermelon Juice',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'60','0','0','0','0','0','N','Y','N','10','General','14','1','1','118','1','1',NULL,NULL,NULL,NULL,'Watermelon Juice','N'),
('64','FRESH JUICE','','Grape Juice',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'60','0','0','0','0','0','N','Y','N','10','General','14','1','1','51','1','1',NULL,NULL,NULL,NULL,'Grape Juice','N'); 
INSERT INTO `tbl_menu_import` VALUES ('65','FRESH JUICE','','Papaya Juice',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'60','0','0','0','0','0','N','Y','N','10','General','14','1','1','80','1','1',NULL,NULL,NULL,NULL,'Papaya Juice','N'),
('66','FRESH JUICE','','Anar Juice',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','14','1','1','1','1','1',NULL,NULL,NULL,NULL,'Anar Juice','N'); 
INSERT INTO `tbl_menu_import` VALUES ('67','LIME JUICE','','Fresh Lime',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'20','0','0','0','0','0','N','Y','N','10','General','15','1','1','48','1','1',NULL,NULL,NULL,NULL,'Fresh Lime','N'),
('68','LIME JUICE','','Mint Lime',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'30','0','0','0','0','0','N','Y','N','10','General','15','1','1','72','1','1',NULL,NULL,NULL,NULL,'Mint Lime','N'); 
INSERT INTO `tbl_menu_import` VALUES ('69','LIME JUICE','','Blue Lime',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'25','0','0','0','0','0','N','Y','N','10','General','15','1','1','13','1','1',NULL,NULL,NULL,NULL,'Blue Lime','N'),
('70','LIME JUICE','','Grape Lime',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'30','0','0','0','0','0','N','Y','N','10','General','15','1','1','52','1','1',NULL,NULL,NULL,NULL,'Grape Lime','N'); 
INSERT INTO `tbl_menu_import` VALUES ('71','LIME JUICE','','Pineapple Lime',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'30','0','0','0','0','0','N','Y','N','10','General','15','1','1','88','1','1',NULL,NULL,NULL,NULL,'Pineapple Lime','N'),
('72','HOT','','Sulaimani',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'10','0','0','0','0','0','N','Y','N','10','General','16','1','1','107','1','1',NULL,NULL,NULL,NULL,'Sulaimani','N'); 
INSERT INTO `tbl_menu_import` VALUES ('73','HOT','','Lemon Tea',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'15','0','0','0','0','0','N','Y','N','10','General','16','1','1','64','1','1',NULL,NULL,NULL,NULL,'Lemon Tea','N'),
('74','HOT','','Tea',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'20','0','0','0','0','0','N','Y','N','10','General','16','1','1','109','1','1',NULL,NULL,NULL,NULL,'Tea','N'); 
INSERT INTO `tbl_menu_import` VALUES ('75','HOT','','Coffee',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'20','0','0','0','0','0','N','Y','N','10','General','16','1','1','37','1','1',NULL,NULL,NULL,NULL,'Coffee','N'),
('76','HOT','','Boost',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'25','0','0','0','0','0','N','Y','N','10','General','16','1','1','15','1','1',NULL,NULL,NULL,NULL,'Boost','N'); 
INSERT INTO `tbl_menu_import` VALUES ('77','HOT','','Horlicks',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'25','0','0','0','0','0','N','Y','N','10','General','16','1','1','58','1','1',NULL,NULL,NULL,NULL,'Horlicks','N'),
('78','COLD COFFEE','','Chocolate Coffee',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'100','0','0','0','0','0','N','Y','N','10','General','17','1','1','36','1','1',NULL,NULL,NULL,NULL,'Chocolate Coffee','N'); 
INSERT INTO `tbl_menu_import` VALUES ('79','COLD COFFEE','','Caramel Coffee',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'100','0','0','0','0','0','N','Y','N','10','General','17','1','1','20','1','1',NULL,NULL,NULL,NULL,'Caramel Coffee','N'),
('80','COLD COFFEE','','Bubble Coffee',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'120','0','0','0','0','0','N','Y','N','10','General','17','1','1','16','1','1',NULL,NULL,NULL,NULL,'Bubble Coffee','N'); 
INSERT INTO `tbl_menu_import` VALUES ('81','COLD COFFEE','','Cold Coffee',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'90','0','0','0','0','0','N','Y','N','10','General','17','1','1','38','1','1',NULL,NULL,NULL,NULL,'Cold Coffee','N'),
('82','COLD COFFEE','','Ice Chocolate',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'90','0','0','0','0','0','N','Y','N','10','General','17','1','1','61','1','1',NULL,NULL,NULL,NULL,'Ice Chocolate','N'); 
INSERT INTO `tbl_menu_import` VALUES ('83','MILK SHAKE','','Kitkat Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'110','0','0','0','0','0','N','Y','N','10','General','18','1','1','62','1','1',NULL,NULL,NULL,NULL,'Kitkat Shake','N'),
('84','MILK SHAKE','','Nutella Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'120','0','0','0','0','0','N','Y','N','10','General','18','1','1','77','1','1',NULL,NULL,NULL,NULL,'Nutella Shake','N'); 
INSERT INTO `tbl_menu_import` VALUES ('85','MILK SHAKE','','Snickers Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'110','0','0','0','0','0','N','Y','N','10','General','18','1','1','101','1','1',NULL,NULL,NULL,NULL,'Snickers Shake','N'),
('86','MILK SHAKE','','Monster Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'130','0','0','0','0','0','N','Y','N','10','General','18','1','1','75','1','1',NULL,NULL,NULL,NULL,'Monster Shake','N'); 
INSERT INTO `tbl_menu_import` VALUES ('87','MILK SHAKE','','Peanut Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'130','0','0','0','0','0','N','Y','N','10','General','18','1','1','83','1','1',NULL,NULL,NULL,NULL,'Peanut Shake','N'),
('88','MILK SHAKE','','Oreo Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'100','0','0','0','0','0','N','Y','N','10','General','18','1','1','79','1','1',NULL,NULL,NULL,NULL,'Oreo Shake','N'); 
INSERT INTO `tbl_menu_import` VALUES ('89','MILK SHAKE','','Lotus Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'120','0','0','0','0','0','N','Y','N','10','General','18','1','1','67','1','1',NULL,NULL,NULL,NULL,'Lotus Shake','N'),
('90','MILK SHAKE','','Mixed Fruit Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'110','0','0','0','0','0','N','Y','N','10','General','18','1','1','74','1','1',NULL,NULL,NULL,NULL,'Mixed Fruit Shak','N'); 
INSERT INTO `tbl_menu_import` VALUES ('91','MILK SHAKE','','Chikoo Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'70','0','0','0','0','0','N','Y','N','10','General','18','1','1','34','1','1',NULL,NULL,NULL,NULL,'Chikoo Shake','N'),
('92','MILK SHAKE','','Strawberry Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','18','1','1','106','1','1',NULL,NULL,NULL,NULL,'Strawberry Shake','N'); 
INSERT INTO `tbl_menu_import` VALUES ('93','MILK SHAKE','','Tender Cashew Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'100','0','0','0','0','0','N','Y','N','10','General','18','1','1','110','1','1',NULL,NULL,NULL,NULL,'Tender Cashew Sh','N'),
('94','MILK SHAKE','','Mango Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'70','0','0','0','0','0','Y','Y','N','10','General','18','1','1','69','1','1',NULL,NULL,NULL,NULL,'Mango Shake','N'); 
INSERT INTO `tbl_menu_import` VALUES ('95','MILK SHAKE','','Shamam Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'70','0','0','0','0','0','Y','Y','N','10','General','18','1','1','97','1','1',NULL,NULL,NULL,NULL,'Shamam Shake','N'),
('96','MILK SHAKE','','Sharja Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'70','0','0','0','0','0','Y','Y','N','10','General','18','1','1','98','1','1',NULL,NULL,NULL,NULL,'Sharja Shake','N'); 
INSERT INTO `tbl_menu_import` VALUES ('97','MILK SHAKE','','Dry Fruit Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'99','0','0','0','0','0','Y','Y','N','10','General','18','1','1','42','1','1',NULL,NULL,NULL,NULL,'Dry Fruit Shake','N'),
('98','MILK SHAKE','','Anar Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'90','0','0','0','0','0','N','Y','N','10','General','18','1','1','2','1','1',NULL,NULL,NULL,NULL,'Anar Shake','N'); 
INSERT INTO `tbl_menu_import` VALUES ('99','MILK SHAKE','','Papaya Shake',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'70','0','0','0','0','0','N','Y','N','10','General','18','1','1','81','1','1',NULL,NULL,NULL,NULL,'Papaya Shake','N'),
('100','MOJITO','','Green Apple Mojito',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','19','1','1','53','1','1',NULL,NULL,NULL,NULL,'Green Apple Moji','N'); 
INSERT INTO `tbl_menu_import` VALUES ('101','MOJITO','','Strawberry Mojito',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','19','1','1','105','1','1',NULL,NULL,NULL,NULL,'Strawberry Mojit','N'),
('102','MOJITO','','Passion Fruit Mojito',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','19','1','1','82','1','1',NULL,NULL,NULL,NULL,'Passion Fruit Mo','N'); 
INSERT INTO `tbl_menu_import` VALUES ('103','MOJITO','','Mint Mojito',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'70','0','0','0','0','0','N','Y','N','10','General','19','1','1','73','1','1',NULL,NULL,NULL,NULL,'Mint Mojito','N'),
('104','MOJITO','','Watermelon Mojito',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'69','0','0','0','0','0','N','Y','N','10','General','19','1','1','119','1','1',NULL,NULL,NULL,NULL,'Watermelon Mojit','N'); 
INSERT INTO `tbl_menu_import` VALUES ('105','MOJITO','','Blue Curacao Mojito',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','19','1','1','12','1','1',NULL,NULL,NULL,NULL,'Blue Curacao Moj','N'),
('106','MOJITO','','Blueberry Mojito',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'90','0','0','0','0','0','N','Y','N','10','General','19','1','1','14','1','1',NULL,NULL,NULL,NULL,'Blueberry Mojito','N'); 
INSERT INTO `tbl_menu_import` VALUES ('107','MOJITO','','Kiwi Mojito',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'99','0','0','0','0','0','N','Y','N','10','General','19','1','1','63','1','1',NULL,NULL,NULL,NULL,'Kiwi Mojito','N'),
('108','FALOODA','','Fruit Salad',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'90','0','0','0','0','0','N','Y','N','10','General','20','1','1','49','1','1',NULL,NULL,NULL,NULL,'Fruit Salad','N'); 
INSERT INTO `tbl_menu_import` VALUES ('109','FALOODA','','Fruit Salad Creamy',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'110','0','0','0','0','0','N','Y','N','10','General','20','1','1','50','1','1',NULL,NULL,NULL,NULL,'Fruit Salad Crea','N'),
('110','FALOODA','','Mini Falooda',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'99','0','0','0','0','0','N','Y','N','10','General','20','1','1','71','1','1',NULL,NULL,NULL,NULL,'Mini Falooda','N'); 
INSERT INTO `tbl_menu_import` VALUES ('111','FALOODA','','Falooda',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'120','0','0','0','0','0','N','Y','N','10','General','20','1','1','46','1','1',NULL,NULL,NULL,NULL,'Falooda','N'),
('112','FALOODA','','Royal Falooda',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'159','0','0','0','0','0','N','Y','N','10','General','20','1','1','92','1','1',NULL,NULL,NULL,NULL,'Royal Falooda','N'); 
INSERT INTO `tbl_menu_import` VALUES ('113','FALOODA','','Magic Falooda',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'180','0','0','0','0','0','N','Y','N','10','General','20','1','1','68','1','1',NULL,NULL,NULL,NULL,'Magic Falooda','N'),
('114','DESSERTS','','Hungry Wife',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'160','0','0','0','0','0','N','Y','N','10','General','21','1','1','60','1','1',NULL,NULL,NULL,NULL,'Hungry Wife','N'); 
INSERT INTO `tbl_menu_import` VALUES ('115','DESSERTS','','Sizzler Brownie',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'180','0','0','0','0','0','N','Y','N','10','General','21','1','1','99','1','1',NULL,NULL,NULL,NULL,'Sizzler Brownie','N'),
('116','DESSERTS','','Daffodils',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'200','0','0','0','0','0','N','Y','N','10','General','21','1','1','39','1','1',NULL,NULL,NULL,NULL,'Daffodils','N'); 
INSERT INTO `tbl_menu_import` VALUES ('117','ICE CREAM SCOOPS','','Vanilla',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'60','0','0','0','0','0','N','Y','N','10','General','22','1','1','112','1','1',NULL,NULL,NULL,NULL,'Vanilla','N'),
('118','ICE CREAM SCOOPS','','Strawberry',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','22','1','1','104','1','1',NULL,NULL,NULL,NULL,'Strawberry','N'); 
INSERT INTO `tbl_menu_import` VALUES ('119','ICE CREAM SCOOPS','','Butter Scotch',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','22','1','1','19','1','1',NULL,NULL,NULL,NULL,'Butter Scotch','N'),
('120','ICE CREAM SCOOPS','','Pista',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','22','1','1','89','1','1',NULL,NULL,NULL,NULL,'Pista','N'); 
INSERT INTO `tbl_menu_import` VALUES ('121','ICE CREAM SCOOPS','','Chocolate',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','22','1','1','35','1','1',NULL,NULL,NULL,NULL,'Chocolate','N'),
('122','ICE CREAM SCOOPS','','Spanish',NULL,'MAIN KITCHEN','General',NULL,'Portion','Single',NULL,'80','0','0','0','0','0','N','Y','N','10','General','22','1','1','102','1','1',NULL,NULL,NULL,NULL,'Spanish','N'); 


DROP TABLE IF EXISTS `tbl_menu_ingredient_detail`;
CREATE TABLE `tbl_menu_ingredient_detail` (
  `tmi_id` int(11) NOT NULL AUTO_INCREMENT,
  `tmi_menuid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmi_ing_menuid` int(11) DEFAULT NULL,
  `tmi_ing_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmi_ing_qty` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmi_ing_unit` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmi_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmi_ing_rate` decimal(15,3) DEFAULT NULL,
  `tmi_ing_total` decimal(15,3) DEFAULT NULL,
  `tmi_ing_dayclosedate` datetime DEFAULT NULL,
  `tmi_weight` decimal(15,3) DEFAULT NULL,
  `tmi_wastage_qty` decimal(15,3) DEFAULT NULL,
  `tmi_wastage_rate` decimal(15,3) DEFAULT NULL,
  `tmi_di` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `tmi_ta` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `tmi_hd` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `tmi_cs` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `tmi_store` int(11) DEFAULT NULL,
  `tmi_yield` decimal(15,3) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tmi_portion` int(11) DEFAULT NULL,
  PRIMARY KEY (`tmi_id`),
  UNIQUE KEY `tmi_menuid` (`tmi_menuid`,`tmi_ing_menuid`,`tmi_portion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_menu_log`;
CREATE TABLE `tbl_menu_log` (
  `tml_id` int(11) NOT NULL AUTO_INCREMENT,
  `tml_date` datetime DEFAULT NULL,
  `tml_menu` int(11) DEFAULT NULL,
  `tml_data` varchar(2500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tml_staff` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tml_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tml_mode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tml_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_menu_log` VALUES ('45','2026-04-17 12:21:15','273','Rate : 40 ','admin','Rate All','DI'),
('46','2026-04-17 12:37:32','274','Rate : 50 ','admin','Rate All','DI'),
('47','2026-04-17 12:41:16','275','Rate : 100 ','admin','Rate All','DI'); 


DROP TABLE IF EXISTS `tbl_menu_preference_kot`;
CREATE TABLE `tbl_menu_preference_kot` (
  `tmp_id` int(11) NOT NULL AUTO_INCREMENT,
  `tmp_orderno_bill` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmp_qty` int(11) DEFAULT NULL,
  `tmp_mode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmp_menu` int(11) DEFAULT NULL,
  `tmp_pref_id` int(11) DEFAULT NULL,
  `tmp_pref_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tmp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_menu_rate_cs_upload`;
CREATE TABLE `tbl_menu_rate_cs_upload` (
  `mrc_id` int(11) NOT NULL AUTO_INCREMENT,
  `mrc_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mrc_rate_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `mrc_portion` int(11) DEFAULT NULL,
  `mrc_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mrc_unit_weight` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `mrc_unit_id` int(11) DEFAULT NULL,
  `mrc_base_unit_id` int(11) DEFAULT NULL,
  `mrc_branchid` bigint(20) NOT NULL,
  `mrc_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mrc_default` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mrc_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mrc_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mrc_id`),
  KEY `fk_menuroom_ser_branchid` (`mrc_branchid`),
  KEY `fk_menuroom_ser_portion` (`mrc_portion`),
  KEY `mrc_menuid` (`mrc_menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menu_rate_di_upload`;
CREATE TABLE `tbl_menu_rate_di_upload` (
  `mmr_id` int(11) NOT NULL AUTO_INCREMENT,
  `mmr_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mmr_floorid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mmr_rate_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `mmr_portion` int(11) DEFAULT NULL,
  `mmr_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mmr_unit_weight` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `mmr_unit_id` int(11) DEFAULT NULL,
  `mmr_base_unit_id` int(11) DEFAULT NULL,
  `mmr_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mmr_default` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mmr_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mmr_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mmr_id`),
  KEY `fk_menurate_floorid` (`mmr_floorid`),
  KEY `fk_menurate_portionid` (`mmr_portion`),
  KEY `mmr_menuid` (`mmr_menuid`),
  KEY `mmr_unit_id` (`mmr_unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menu_rate_ta_upload`;
CREATE TABLE `tbl_menu_rate_ta_upload` (
  `mta_id` int(11) NOT NULL AUTO_INCREMENT,
  `mta_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mta_rate_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `mta_portion` int(11) DEFAULT NULL,
  `mta_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mta_unit_weight` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `mta_unit_id` int(11) DEFAULT NULL,
  `mta_base_unit_id` int(11) DEFAULT NULL,
  `mta_branchid` bigint(20) NOT NULL,
  `mta_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mta_default` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mta_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mta_food_partner` int(11) DEFAULT NULL,
  PRIMARY KEY (`mta_id`),
  KEY `fk_menutakeaway_branchid` (`mta_branchid`),
  KEY `fk_menutakeaway_portionid` (`mta_portion`),
  KEY `mta_menuid` (`mta_menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menu_tax_master`;
CREATE TABLE `tbl_menu_tax_master` (
  `mtm_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mtm_slno` tinyint(4) NOT NULL,
  `mtm_tax_id` int(11) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mtm_menuid`,`mtm_slno`,`mtm_tax_id`),
  KEY `fk_menu_tax_master_taxid` (`mtm_tax_id`),
  CONSTRAINT `fk_menu_tax_master_menuid` FOREIGN KEY (`mtm_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_menu_tax_master_taxid` FOREIGN KEY (`mtm_tax_id`) REFERENCES `tbl_extra_tax_master` (`amc_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menu_upload`;
CREATE TABLE `tbl_menu_upload` (
  `mr_menuid` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_menuname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mr_maincatid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mr_subcatid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_description` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_diet` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mr_time_min` tinyint(4) NOT NULL,
  `mr_active` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `mr_kotcounter` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mr_modifieddate` datetime NOT NULL,
  `mr_modifieduser` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `mr_rating` tinyint(4) DEFAULT '0',
  `mr_prepmode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_branchid` bigint(20) NOT NULL,
  `mr_itemshortcode` varchar(17) COLLATE utf8_unicode_ci NOT NULL,
  `mr_dailystock` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_manualrateentry` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_itemcode` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_dailystock_in_number` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mr_show_in_kod` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mr_excempt_tax` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_maincatid_org` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_subcatid_org` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_kotcounter_org` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_menucombination`;
CREATE TABLE `tbl_menucombination` (
  `mn_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mn_menucombid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mn_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mn_menuid`,`mn_menucombid`),
  KEY `fk_menucomb_menucombid` (`mn_menucombid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_menuimage_delete_log`;
CREATE TABLE `tbl_menuimage_delete_log` (
  `tmi_id` int(11) NOT NULL AUTO_INCREMENT,
  `tmi_thumb_location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmi_menuid` int(11) DEFAULT NULL,
  `tmi_date_time` datetime DEFAULT NULL,
  `tmi_cloud_branch_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmi_cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tmi_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_menuimages`;
CREATE TABLE `tbl_menuimages` (
  `mes_imagename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mes_imagethumb` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mes_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mes_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mes_imagename`),
  KEY `mes_menuid` (`mes_menuid`),
  CONSTRAINT `(` FOREIGN KEY (`mes_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_menuingredients`;
CREATE TABLE `tbl_menuingredients` (
  `ms_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ms_ingridentid` bigint(20) NOT NULL,
  `ms_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ms_menuid`,`ms_ingridentid`),
  KEY `fk_menuingredient_ingredientid` (`ms_ingridentid`),
  KEY `ms_menu` (`ms_menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_menumaincategory`;
CREATE TABLE `tbl_menumaincategory` (
  `mmy_maincategoryid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mmy_maincategoryname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mmy_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mmy_branchid` bigint(20) NOT NULL,
  `mmy_displayorder` int(11) DEFAULT '1',
  `mmy_imagename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mmy_orderof_print` int(11) NOT NULL DEFAULT '1',
  `mmy_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mmy_qr_image` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mmy_inventory` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `mmy_is_central` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mmy_new_cate` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mmy_accepted_outlets` longtext COLLATE utf8_unicode_ci,
  `new_from_cloud` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `central_edited` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `central_id` int(11) DEFAULT NULL,
  `pref_ids` varchar(2500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `addons_id` varchar(2500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_printer_kitchen` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mmy_delete_mode` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `from_time` time DEFAULT NULL,
  `to_time` time DEFAULT NULL,
  PRIMARY KEY (`mmy_maincategoryid`),
  KEY `mmy_branchid` (`mmy_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_menumaincategory` VALUES ('1','FRIES','Y','1','1',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('10','STRIPS','Y','1','10',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('11','WINGS','Y','1','11',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL); 
INSERT INTO `tbl_menumaincategory` VALUES ('12','PASTA','Y','1','12',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('13','PIZZA','Y','1','13',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('14','FRESH JUICE','Y','1','14',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL); 
INSERT INTO `tbl_menumaincategory` VALUES ('15','LIME JUICE','Y','1','15',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('16','HOT','Y','1','16',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('17','COLD COFFEE','Y','1','17',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL); 
INSERT INTO `tbl_menumaincategory` VALUES ('18','MILK SHAKE','Y','1','18',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('19','MOJITO','Y','1','19',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('2','LOADER','Y','1','2',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL); 
INSERT INTO `tbl_menumaincategory` VALUES ('20','FALOODA','Y','1','20',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('21','DESSERTS','Y','1','21',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('22','ICE CREAM SCOOPS','Y','1','22',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL); 
INSERT INTO `tbl_menumaincategory` VALUES ('3','POPCORN','Y','1','3',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('4','BURGER','Y','1','4',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('5','WRAPS','Y','1','5',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL); 
INSERT INTO `tbl_menumaincategory` VALUES ('6','CLUB','Y','1','6',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('7','SANDWICH','Y','1','7',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL),
('8','LOLLIPOP','Y','1','8',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL); 
INSERT INTO `tbl_menumaincategory` VALUES ('9','MOMOS','Y','1','9',NULL,'1','Y','N',NULL,'N','N','N',NULL,'N','N',NULL,NULL,NULL,NULL,'N',NULL,NULL); 


DROP TABLE IF EXISTS `tbl_menumaster`;
CREATE TABLE `tbl_menumaster` (
  `mr_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mr_menuname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mr_maincatid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mr_subcatid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_description` varchar(5000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_diet` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mr_time_min` tinyint(4) NOT NULL,
  `mr_active` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `mr_kotcounter` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mr_modifieddate` datetime NOT NULL,
  `mr_modifieduser` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_rating` tinyint(4) DEFAULT '0',
  `mr_prepmode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_branchid` bigint(20) NOT NULL,
  `mr_itemshortcode` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `mr_dailystock` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_manualrateentry` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_itemcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_dailystock_in_number` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mr_show_in_kod` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mr_excempt_tax` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_rate_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `mr_unit_type` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_base_unit` int(11) DEFAULT NULL,
  `mr_add_on` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_show_in_kot_print` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `manual_barcode` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_ingredient` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_replacer` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_product_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT 'Menu',
  `inv_pdt_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_inventory_kitchen` int(11) DEFAULT NULL,
  `mr_pkd_date` date DEFAULT NULL,
  `mr_exp_date` date DEFAULT NULL,
  `mr_plu` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_reorder_level` decimal(15,3) DEFAULT '0.000',
  `mr_purchase_price` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mr_raw_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_qr_set` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mr_delete_mode` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_central_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_excempt_disc` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_central_menu` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_new_menu` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mr_copy_from` int(11) DEFAULT NULL,
  `mr_added_branches` longtext COLLATE utf8_unicode_ci,
  `mr_accepted_outlets` longtext COLLATE utf8_unicode_ci,
  `mr_stock_inventory` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `mr_hsn` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mr_stock_in_out` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`mr_menuid`),
  UNIQUE KEY `mr_menuname` (`mr_menuname`),
  UNIQUE KEY `mr_itemcode` (`mr_itemcode`),
  KEY `mr_base_unit` (`mr_base_unit`),
  KEY `mr_branchid` (`mr_branchid`),
  KEY `mr_kotcounter` (`mr_kotcounter`),
  KEY `mr_maincatid` (`mr_maincatid`),
  KEY `mr_modifieduser` (`mr_modifieduser`),
  KEY `mr_subcatid` (`mr_subcatid`),
  CONSTRAINT `fk_menumaster_kotcounter` FOREIGN KEY (`mr_kotcounter`) REFERENCES `tbl_kotcountermaster` (`kr_kotcode`),
  CONSTRAINT `fk_menumaster_maincatid` FOREIGN KEY (`mr_maincatid`) REFERENCES `tbl_menumaincategory` (`mmy_maincategoryid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_menumaster_subcatid` FOREIGN KEY (`mr_subcatid`) REFERENCES `tbl_menusubcategory` (`msy_subcategoryid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `tbl_menumaster` VALUES ('1','ANAR JUICE','14',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ANAR JUICE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('10','BEEF LOADER','2',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BEEF LOADER','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('100','SIZZLER BURGER','4',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SIZZLER BURGER','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('101','SNICKERS SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SNICKERS SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('102','SPANISH','22',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SPANISH','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('103','SPICY FRIES','1',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SPICY FRIES','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('104','STRAWBERRY','22',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','STRAWBERRY','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('105','STRAWBERRY MOJITO','19',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','STRAWBERRY MOJIT','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('106','STRAWBERRY SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','STRAWBERRY SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('107','SULAIMANI','16',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SULAIMANI','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('108','TANDOORI PIZZA LARGE','13',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','TANDOORI PIZZA L','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('109','TEA','16',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','TEA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('11','BEEF SPECIAL BURGER','4',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BEEF SPECIAL BUR','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('110','TENDER CASHEW SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','TENDER CASHEW SH','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('111','TOWER BURGER','4',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','TOWER BURGER','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('112','VANILLA','22',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','VANILLA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('113','VEG BURGER','4',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','VEG BURGER','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('114','VEG CLUB SANDWICH','6',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','VEG CLUB SANDWIC','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('115','VEG MOMO','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','VEG MOMO','Y','Y',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('116','VEG SANDWICH','7',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','VEG SANDWICH','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('117','VEG WRAP','5',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','VEG WRAP','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('118','WATERMELON JUICE','14',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','WATERMELON JUICE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('119','WATERMELON MOJITO','19',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','WATERMELON MOJIT','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('12','BLUE CURACAO MOJITO','19',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BLUE CURACAO MOJ','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('120','ZINGER BURGER','4',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ZINGER BURGER','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('121','ZINGER CLUB SANDWICH','6',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ZINGER CLUB SAND','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('122','ZINGER WRAP','5',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ZINGER WRAP','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('13','BLUE LIME','15',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BLUE LIME','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('14','BLUEBERRY MOJITO','19',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BLUEBERRY MOJITO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('15','BOOST','16',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BOOST','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('16','BUBBLE COFFEE','17',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BUBBLE COFFEE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('17','BUFFALO CHICKEN 3 PCS','10',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BUFFALO CHICKEN','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('18','BUFFALO CHICKEN 6 PCS','10',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BUFFALO CHICKEN','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('19','BUTTER SCOTCH','22',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BUTTER SCOTCH','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('2','ANAR SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ANAR SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('20','CARAMEL COFFEE','17',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CARAMEL COFFEE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('21','CHEESY MOMO F','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHEESY MOMO F','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('22','CHEESY MOMO H','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHEESY MOMO H','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('23','CHICKEN ALFREDO PASTA','12',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN ALFREDO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('24','CHICKEN FAJITA','5',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN FAJITA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('25','CHICKEN FRIED MOMOS  H','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN FRIED MO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('26','CHICKEN FRIED MOMOS F','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN FRIED MO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('27','CHICKEN LOLLIPOP 5 PCS','8',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN LOLLIPOP','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('28','CHICKEN MACARONI','12',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN MACARONI','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('29','CHICKEN POPCORN','3',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN POPCORN','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('3','APPLE JUICE','14',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','APPLE JUICE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('30','CHICKEN STEAK CLUB','6',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN STEAK CL','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('31','CHICKEN STEAM MOMOS F','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN STEAM MO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('32','CHICKEN STEAM MOMOS H','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN STEAM MO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('33','CHICKEN STRIPS 6 PCS','10',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHICKEN STRIPS 6','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('34','CHIKOO SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHIKOO SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('35','CHOCOLATE','22',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHOCOLATE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('36','CHOCOLATE COFFEE','17',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','CHOCOLATE COFFEE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('37','COFFEE','16',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','COFFEE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('38','COLD COFFEE','17',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','COLD COFFEE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('39','DAFFODILS','21',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','DAFFODILS','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('4','BBQ BURGER','4',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BBQ BURGER','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('40','DIRTY CHEESE FRIES','2',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','DIRTY CHEESE FRI','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('41','DRAGON CHICKEN','10',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','DRAGON CHICKEN','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('42','DRY FRUIT SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','DRY FRUIT SHAKE','Y','Y',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('43','DYNAMIC CHICKEN','3',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','DYNAMIC CHICKEN','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('44','DYNAMITE MOMO F','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','DYNAMITE MOMO F','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('45','DYNAMITE MOMO H','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','DYNAMITE MOMO H','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('46','FALOODA','20',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','FALOODA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('47','FRENCH FRIES','1',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','FRENCH FRIES','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('48','FRESH LIME','15',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','FRESH LIME','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('49','FRUIT SALAD','20',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','FRUIT SALAD','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('5','BBQ LOLLIPOP 5 PCS','8',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BBQ LOLLIPOP 5 P','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('50','FRUIT SALAD CREAMY','20',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','FRUIT SALAD CREA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('51','GRAPE JUICE','14',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','GRAPE JUICE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('52','GRAPE LIME','15',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','GRAPE LIME','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('53','GREEN APPLE MOJITO','19',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','GREEN APPLE MOJI','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('54','GRILLED BURGER','4',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','GRILLED BURGER','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('55','GRILLED CLUB SANDWICH','6',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','GRILLED CLUB SAN','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('56','GRILLED SANDWICH','7',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','GRILLED SANDWICH','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('57','GRILLED WRAP','5',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','GRILLED WRAP','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('58','HORLICKS','16',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','HORLICKS','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('59','HOT WINGS 5 PCS','11',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','HOT WINGS 5 PCS','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('6','BBQ PIZZA','13',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BBQ PIZZA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('60','HUNGRY WIFE','21',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','HUNGRY WIFE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('61','ICE CHOCOLATE','17',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ICE CHOCOLATE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('62','KITKAT SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','KITKAT SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('63','KIWI MOJITO','19',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','KIWI MOJITO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('64','LEMON TEA','16',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','LEMON TEA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('65','LOADER CASTAL SPECIAL PIZZA','13',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','LOADER CASTAL SP','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('66','LOADER FRIES','2',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','LOADER FRIES','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('67','LOTUS SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','LOTUS SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('68','MAGIC FALOODA','20',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','MAGIC FALOODA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('69','MANGO SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','MANGO SHAKE','Y','Y',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('7','BBQ SANDWICH','7',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BBQ SANDWICH','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('70','MEXICAN POPCORN','3',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','MEXICAN POPCORN','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('71','MINI FALOODA','20',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','MINI FALOODA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('72','MINT LIME','15',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','MINT LIME','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('73','MINT MOJITO','19',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','MINT MOJITO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('74','MIXED FRUIT SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','MIXED FRUIT SHAK','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('75','MONSTER SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','MONSTER SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('76','NUGGETS','1',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','NUGGETS','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('77','NUTELLA SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','NUTELLA SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('78','ORANGE JUICE','14',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ORANGE JUICE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('79','OREO SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','OREO SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('8','BBQ WINGS 5 PCS','11',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BBQ WINGS 5 PCS','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('80','PAPAYA JUICE','14',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PAPAYA JUICE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('81','PAPAYA SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PAPAYA SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('82','PASSION FRUIT MOJITO','19',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PASSION FRUIT MO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('83','PEANUT SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PEANUT SHAKE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('84','PERI PERI FRIED MOMO F','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PERI PERI FRIED','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('85','PERI PERI FRIED MOMO H','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PERI PERI FRIED','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('86','PERI PERI STRIPS 6 PCS','10',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PERI PERI STRIPS','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('87','PINEAPPLE JUICE','14',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PINEAPPLE JUICE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('88','PINEAPPLE LIME','15',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PINEAPPLE LIME','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('89','PISTA','22',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','PISTA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('9','BBQ WRAPS','5',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','BBQ WRAPS','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('90','RED SAUCE ARABIAN PAST','12',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','RED SAUCE ARABIA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('91','ROYAL BURGER','4',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ROYAL BURGER','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('92','ROYAL FALOODA','20',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','ROYAL FALOODA','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('93','SCHEZWAN FRIED MOMO F','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SCHEZWAN FRIED M','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('94','SCHEZWAN FRIED MOMO H','9',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SCHEZWAN FRIED M','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('95','SCHEZWAN LOLLIPOP 5 PCS','8',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SCHEZWAN LOLLIPO','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('96','SCHEZWAN WINGS','11',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SCHEZWAN WINGS','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('97','SHAMAM SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SHAMAM SHAKE','Y','Y',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('98','SHARJA SHAKE','18',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SHARJA SHAKE','Y','Y',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 
INSERT INTO `tbl_menumaster` VALUES ('99','SIZZLER BROWNIE','21',NULL,NULL,'General','10','Y','1','2026-04-20 11:14:32',NULL,'0','General','1','SIZZLER BROWNIE','Y','N',NULL,'N','Y','Y','N','Portion',NULL,NULL,'N','Y','N','N','N','N','Menu',NULL,NULL,NULL,NULL,NULL,'0.000','0.000',NULL,'Y','N',NULL,'N','N','N',NULL,NULL,NULL,'N',NULL,'Y'); 


DROP TABLE IF EXISTS `tbl_menunutitionfacts`;
CREATE TABLE `tbl_menunutitionfacts` (
  `mnf_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mnf_nutrition` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mnf_value` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mnf_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mnf_menuid`,`mnf_nutrition`),
  CONSTRAINT `fk_menunutrition_menuid` FOREIGN KEY (`mnf_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_menuprefmaster`;
CREATE TABLE `tbl_menuprefmaster` (
  `mpr_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mpr_prefeernce` int(11) NOT NULL,
  `mpr_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mpr_menuid`,`mpr_prefeernce`),
  KEY `fk_menurate_portionid` (`mpr_prefeernce`),
  CONSTRAINT `fk_menuprefmaster_menuid` FOREIGN KEY (`mpr_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menurate_counter`;
CREATE TABLE `tbl_menurate_counter` (
  `mrc_id` int(11) NOT NULL AUTO_INCREMENT,
  `mrc_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mrc_rate_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `mrc_portion` int(11) DEFAULT NULL,
  `mrc_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mrc_unit_weight` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `mrc_unit_id` int(11) DEFAULT NULL,
  `mrc_base_unit_id` int(11) DEFAULT NULL,
  `mrc_branchid` bigint(20) NOT NULL,
  `mrc_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mrc_default` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mrc_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mrc_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mrc_menu_tax_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mrc_menu_final_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mrc_menu_tax_value` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`mrc_id`),
  KEY `fk_menuroom_ser_branchid` (`mrc_branchid`),
  KEY `fk_menuroom_ser_portion` (`mrc_portion`),
  KEY `mrc_menuid` (`mrc_menuid`),
  CONSTRAINT `fk_menurate_counter_menuid` FOREIGN KEY (`mrc_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_menurate_counter_portion` FOREIGN KEY (`mrc_portion`) REFERENCES `tbl_portionmaster` (`pm_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menurate_delete_log`;
CREATE TABLE `tbl_menurate_delete_log` (
  `tmd_id` int(11) NOT NULL AUTO_INCREMENT,
  `tmd_menuid` int(11) DEFAULT NULL,
  `tmd_mmr_id` int(11) DEFAULT NULL,
  `tmd_mode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmd_date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmd_cloud_sync` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tmd_id`)
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_menurate_roomservice`;
CREATE TABLE `tbl_menurate_roomservice` (
  `mrs_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mrs_portion` int(11) NOT NULL,
  `mrs_branchid` bigint(20) NOT NULL,
  `mrs_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mrs_menuid`,`mrs_portion`,`mrs_branchid`),
  KEY `fk_menuroom_ser_branchid` (`mrs_branchid`),
  KEY `fk_menuroom_ser_portion` (`mrs_portion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menuratemaster`;
CREATE TABLE `tbl_menuratemaster` (
  `mmr_id` int(11) NOT NULL AUTO_INCREMENT,
  `mmr_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mmr_floorid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mmr_rate_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `mmr_portion` int(11) DEFAULT NULL,
  `mmr_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mmr_unit_weight` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `mmr_unit_id` int(11) DEFAULT NULL,
  `mmr_base_unit_id` int(11) DEFAULT NULL,
  `mmr_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mmr_default` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mmr_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mmr_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mmr_menu_tax_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mmr_menu_final_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mmr_menu_tax_value` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`mmr_id`),
  KEY `fk_menurate_floorid` (`mmr_floorid`),
  KEY `fk_menurate_portionid` (`mmr_portion`),
  KEY `mmr_menuid` (`mmr_menuid`),
  KEY `mmr_unit_id` (`mmr_unit_id`),
  CONSTRAINT `fk_menurate_dine_menuid` FOREIGN KEY (`mmr_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_menurate_floor` FOREIGN KEY (`mmr_floorid`) REFERENCES `tbl_floormaster` (`fr_floorid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_menurate_portion` FOREIGN KEY (`mmr_portion`) REFERENCES `tbl_portionmaster` (`pm_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_menurate_unit` FOREIGN KEY (`mmr_unit_id`) REFERENCES `tbl_unit_master` (`u_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_menuratemaster` VALUES ('1','47','1','Portion','1',NULL,'0.00000',NULL,NULL,'90.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('2','103','1','Portion','1',NULL,'0.00000',NULL,NULL,'100.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('3','76','1','Portion','1',NULL,'0.00000',NULL,NULL,'120.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('4','66','1','Portion','1',NULL,'0.00000',NULL,NULL,'140.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('5','40','1','Portion','1',NULL,'0.00000',NULL,NULL,'160.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('6','10','1','Portion','1',NULL,'0.00000',NULL,NULL,'180.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('7','29','1','Portion','1',NULL,'0.00000',NULL,NULL,'150.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('8','70','1','Portion','1',NULL,'0.00000',NULL,NULL,'160.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('9','43','1','Portion','1',NULL,'0.00000',NULL,NULL,'190.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('10','113','1','Portion','1',NULL,'0.00000',NULL,NULL,'110.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('11','54','1','Portion','1',NULL,'0.00000',NULL,NULL,'130.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('12','4','1','Portion','1',NULL,'0.00000',NULL,NULL,'140.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('13','120','1','Portion','1',NULL,'0.00000',NULL,NULL,'140.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('14','91','1','Portion','1',NULL,'0.00000',NULL,NULL,'180.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('15','11','1','Portion','1',NULL,'0.00000',NULL,NULL,'180.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('16','111','1','Portion','1',NULL,'0.00000',NULL,NULL,'220.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('17','100','1','Portion','1',NULL,'0.00000',NULL,NULL,'200.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('18','117','1','Portion','1',NULL,'0.00000',NULL,NULL,'100.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('19','122','1','Portion','1',NULL,'0.00000',NULL,NULL,'130.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('20','57','1','Portion','1',NULL,'0.00000',NULL,NULL,'120.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('21','9','1','Portion','1',NULL,'0.00000',NULL,NULL,'140.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('22','24','1','Portion','1',NULL,'0.00000',NULL,NULL,'160.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('23','114','1','Portion','1',NULL,'0.00000',NULL,NULL,'120.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('24','55','1','Portion','1',NULL,'0.00000',NULL,NULL,'160.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('25','121','1','Portion','1',NULL,'0.00000',NULL,NULL,'170.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('26','30','1','Portion','1',NULL,'0.00000',NULL,NULL,'180.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('27','116','1','Portion','1',NULL,'0.00000',NULL,NULL,'100.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('28','56','1','Portion','1',NULL,'0.00000',NULL,NULL,'110.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('29','7','1','Portion','1',NULL,'0.00000',NULL,NULL,'120.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('30','27','1','Portion','1',NULL,'0.00000',NULL,NULL,'159.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('31','5','1','Portion','1',NULL,'0.00000',NULL,NULL,'169.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('32','95','1','Portion','1',NULL,'0.00000',NULL,NULL,'174.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('33','115','1','Portion','1',NULL,'0.00000',NULL,NULL,'1.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('34','32','1','Portion','1',NULL,'0.00000',NULL,NULL,'89.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('35','31','1','Portion','1',NULL,'0.00000',NULL,NULL,'119.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('36','25','1','Portion','1',NULL,'0.00000',NULL,NULL,'99.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('37','26','1','Portion','1',NULL,'0.00000',NULL,NULL,'129.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('38','85','1','Portion','1',NULL,'0.00000',NULL,NULL,'109.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('39','84','1','Portion','1',NULL,'0.00000',NULL,NULL,'139.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('40','94','1','Portion','1',NULL,'0.00000',NULL,NULL,'119.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('41','93','1','Portion','1',NULL,'0.00000',NULL,NULL,'149.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('42','45','1','Portion','1',NULL,'0.00000',NULL,NULL,'129.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('43','44','1','Portion','1',NULL,'0.00000',NULL,NULL,'159.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('44','22','1','Portion','1',NULL,'0.00000',NULL,NULL,'159.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('45','21','1','Portion','1',NULL,'0.00000',NULL,NULL,'199.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('46','17','1','Portion','1',NULL,'0.00000',NULL,NULL,'180.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('47','18','1','Portion','1',NULL,'0.00000',NULL,NULL,'299.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('48','33','1','Portion','1',NULL,'0.00000',NULL,NULL,'229.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('49','86','1','Portion','1',NULL,'0.00000',NULL,NULL,'249.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('50','41','1','Portion','1',NULL,'0.00000',NULL,NULL,'199.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('51','59','1','Portion','1',NULL,'0.00000',NULL,NULL,'139.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('52','8','1','Portion','1',NULL,'0.00000',NULL,NULL,'149.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('53','96','1','Portion','1',NULL,'0.00000',NULL,NULL,'149.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('54','23','1','Portion','1',NULL,'0.00000',NULL,NULL,'199.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('55','90','1','Portion','1',NULL,'0.00000',NULL,NULL,'219.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('56','28','1','Portion','1',NULL,'0.00000',NULL,NULL,'189.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('57','108','1','Portion','1',NULL,'0.00000',NULL,NULL,'349.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('58','6','1','Portion','1',NULL,'0.00000',NULL,NULL,'319.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('59','65','1','Portion','1',NULL,'0.00000',NULL,NULL,'399.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('60','78','1','Portion','1',NULL,'0.00000',NULL,NULL,'60.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('61','87','1','Portion','1',NULL,'0.00000',NULL,NULL,'60.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('62','3','1','Portion','1',NULL,'0.00000',NULL,NULL,'60.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('63','118','1','Portion','1',NULL,'0.00000',NULL,NULL,'60.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('64','51','1','Portion','1',NULL,'0.00000',NULL,NULL,'60.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('65','80','1','Portion','1',NULL,'0.00000',NULL,NULL,'60.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('66','1','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('67','48','1','Portion','1',NULL,'0.00000',NULL,NULL,'20.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('68','72','1','Portion','1',NULL,'0.00000',NULL,NULL,'30.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('69','13','1','Portion','1',NULL,'0.00000',NULL,NULL,'25.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('70','52','1','Portion','1',NULL,'0.00000',NULL,NULL,'30.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('71','88','1','Portion','1',NULL,'0.00000',NULL,NULL,'30.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('72','107','1','Portion','1',NULL,'0.00000',NULL,NULL,'10.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('73','64','1','Portion','1',NULL,'0.00000',NULL,NULL,'15.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('74','109','1','Portion','1',NULL,'0.00000',NULL,NULL,'20.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('75','37','1','Portion','1',NULL,'0.00000',NULL,NULL,'20.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('76','15','1','Portion','1',NULL,'0.00000',NULL,NULL,'25.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('77','58','1','Portion','1',NULL,'0.00000',NULL,NULL,'25.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('78','36','1','Portion','1',NULL,'0.00000',NULL,NULL,'100.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('79','20','1','Portion','1',NULL,'0.00000',NULL,NULL,'100.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('80','16','1','Portion','1',NULL,'0.00000',NULL,NULL,'120.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('81','38','1','Portion','1',NULL,'0.00000',NULL,NULL,'90.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('82','61','1','Portion','1',NULL,'0.00000',NULL,NULL,'90.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('83','62','1','Portion','1',NULL,'0.00000',NULL,NULL,'110.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('84','77','1','Portion','1',NULL,'0.00000',NULL,NULL,'120.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('85','101','1','Portion','1',NULL,'0.00000',NULL,NULL,'110.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('86','75','1','Portion','1',NULL,'0.00000',NULL,NULL,'130.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('87','83','1','Portion','1',NULL,'0.00000',NULL,NULL,'130.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('88','79','1','Portion','1',NULL,'0.00000',NULL,NULL,'100.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('89','67','1','Portion','1',NULL,'0.00000',NULL,NULL,'120.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('90','74','1','Portion','1',NULL,'0.00000',NULL,NULL,'110.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('91','34','1','Portion','1',NULL,'0.00000',NULL,NULL,'70.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('92','106','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('93','110','1','Portion','1',NULL,'0.00000',NULL,NULL,'100.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('94','69','1','Portion','1',NULL,'0.00000',NULL,NULL,'70.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('95','97','1','Portion','1',NULL,'0.00000',NULL,NULL,'70.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('96','98','1','Portion','1',NULL,'0.00000',NULL,NULL,'70.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('97','42','1','Portion','1',NULL,'0.00000',NULL,NULL,'99.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('98','2','1','Portion','1',NULL,'0.00000',NULL,NULL,'90.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('99','81','1','Portion','1',NULL,'0.00000',NULL,NULL,'70.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('100','53','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('101','105','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('102','82','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('103','73','1','Portion','1',NULL,'0.00000',NULL,NULL,'70.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('104','119','1','Portion','1',NULL,'0.00000',NULL,NULL,'69.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('105','12','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('106','14','1','Portion','1',NULL,'0.00000',NULL,NULL,'90.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('107','63','1','Portion','1',NULL,'0.00000',NULL,NULL,'99.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('108','49','1','Portion','1',NULL,'0.00000',NULL,NULL,'90.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('109','50','1','Portion','1',NULL,'0.00000',NULL,NULL,'110.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('110','71','1','Portion','1',NULL,'0.00000',NULL,NULL,'99.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('111','46','1','Portion','1',NULL,'0.00000',NULL,NULL,'120.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('112','92','1','Portion','1',NULL,'0.00000',NULL,NULL,'159.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('113','68','1','Portion','1',NULL,'0.00000',NULL,NULL,'180.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('114','60','1','Portion','1',NULL,'0.00000',NULL,NULL,'160.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('115','99','1','Portion','1',NULL,'0.00000',NULL,NULL,'180.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('116','39','1','Portion','1',NULL,'0.00000',NULL,NULL,'200.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('117','112','1','Portion','1',NULL,'0.00000',NULL,NULL,'60.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('118','104','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('119','19','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('120','89','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 
INSERT INTO `tbl_menuratemaster` VALUES ('121','35','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'),
('122','102','1','Portion','1',NULL,'0.00000',NULL,NULL,'80.000','Y',NULL,'Y','N','0.000','0.000','0.000'); 


DROP TABLE IF EXISTS `tbl_menuratetakeaway`;
CREATE TABLE `tbl_menuratetakeaway` (
  `mta_id` int(11) NOT NULL AUTO_INCREMENT,
  `mta_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mta_rate_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `mta_portion` int(11) DEFAULT NULL,
  `mta_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mta_unit_weight` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `mta_unit_id` int(11) DEFAULT NULL,
  `mta_base_unit_id` int(11) DEFAULT NULL,
  `mta_branchid` bigint(20) NOT NULL,
  `mta_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mta_default` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mta_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mta_food_partner` int(11) DEFAULT NULL,
  `mta_menu_tax_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mta_menu_final_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mta_menu_tax_value` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`mta_id`),
  KEY `fk_menutakeaway_branchid` (`mta_branchid`),
  KEY `fk_menutakeaway_portionid` (`mta_portion`),
  KEY `mta_menuid` (`mta_menuid`),
  CONSTRAINT `fk_menutakeaway_branchid` FOREIGN KEY (`mta_branchid`) REFERENCES `tbl_branchmaster` (`be_branchid`),
  CONSTRAINT `fk_menutakeaway_menuid` FOREIGN KEY (`mta_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_menutakeaway_portionid` FOREIGN KEY (`mta_portion`) REFERENCES `tbl_portionmaster` (`pm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_menusearchtype`;
CREATE TABLE `tbl_menusearchtype` (
  `me_id` int(11) NOT NULL AUTO_INCREMENT,
  `me_type` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `me_description` text COLLATE utf8_unicode_ci NOT NULL,
  `me_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`me_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_menusearchtype` VALUES ('1','name_with_rate','first two letters of menuname ,- quantity','N','N'),
('2','name_only','fullname search','Y','N'); 


DROP TABLE IF EXISTS `tbl_menustock`;
CREATE TABLE `tbl_menustock` (
  `mk_id` int(11) NOT NULL AUTO_INCREMENT,
  `mk_date` date NOT NULL,
  `mk_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mk_portion` int(11) DEFAULT NULL,
  `mk_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mk_unit_weight` decimal(15,5) DEFAULT '0.00000',
  `mk_unit_id` int(11) DEFAULT NULL,
  `mk_base_unit_id` int(11) DEFAULT NULL,
  `mk_stock` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `mk_stocktime` datetime DEFAULT NULL,
  `mk_stock_number` decimal(10,2) DEFAULT '0.00',
  `mk_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mk_opening_stock` int(11) DEFAULT '0',
  `mk_open_stock_date` date DEFAULT NULL,
  `mk_added_stock_total` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mk_id`),
  KEY `fk_menustock_menuid` (`mk_menuid`),
  KEY `fk_menustock_portion` (`mk_portion`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_menustock` VALUES ('1','2026-04-20','47','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:08','0.00','Y','N','0',NULL,'0'),
('2','2026-04-20','103','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('3','2026-04-20','76','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('4','2026-04-20','66','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('5','2026-04-20','40','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('6','2026-04-20','10','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('7','2026-04-20','29','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('8','2026-04-20','70','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('9','2026-04-20','43','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('10','2026-04-20','113','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('11','2026-04-20','54','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('12','2026-04-20','4','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('13','2026-04-20','120','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('14','2026-04-20','91','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('15','2026-04-20','11','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('16','2026-04-20','111','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('17','2026-04-20','100','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('18','2026-04-20','117','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('19','2026-04-20','122','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('20','2026-04-20','57','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('21','2026-04-20','9','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('22','2026-04-20','24','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('23','2026-04-20','114','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('24','2026-04-20','55','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('25','2026-04-20','121','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('26','2026-04-20','30','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('27','2026-04-20','116','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('28','2026-04-20','56','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('29','2026-04-20','7','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('30','2026-04-20','27','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('31','2026-04-20','5','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('32','2026-04-20','95','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('33','2026-04-20','115','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('34','2026-04-20','32','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('35','2026-04-20','31','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'),
('36','2026-04-20','25','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:09','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('37','2026-04-20','26','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('38','2026-04-20','85','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('39','2026-04-20','84','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('40','2026-04-20','94','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('41','2026-04-20','93','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('42','2026-04-20','45','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('43','2026-04-20','44','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('44','2026-04-20','22','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('45','2026-04-20','21','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('46','2026-04-20','17','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('47','2026-04-20','18','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('48','2026-04-20','33','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('49','2026-04-20','86','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('50','2026-04-20','41','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('51','2026-04-20','59','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('52','2026-04-20','8','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('53','2026-04-20','96','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('54','2026-04-20','23','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('55','2026-04-20','90','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('56','2026-04-20','28','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('57','2026-04-20','108','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('58','2026-04-20','6','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('59','2026-04-20','65','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('60','2026-04-20','78','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('61','2026-04-20','87','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('62','2026-04-20','3','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('63','2026-04-20','118','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('64','2026-04-20','51','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('65','2026-04-20','80','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('66','2026-04-20','1','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('67','2026-04-20','48','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('68','2026-04-20','72','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('69','2026-04-20','13','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('70','2026-04-20','52','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('71','2026-04-20','88','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'),
('72','2026-04-20','107','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:10','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('73','2026-04-20','64','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('74','2026-04-20','109','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('75','2026-04-20','37','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('76','2026-04-20','15','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('77','2026-04-20','58','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('78','2026-04-20','36','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('79','2026-04-20','20','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('80','2026-04-20','16','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('81','2026-04-20','38','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('82','2026-04-20','61','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('83','2026-04-20','62','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('84','2026-04-20','77','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('85','2026-04-20','101','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('86','2026-04-20','75','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('87','2026-04-20','83','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('88','2026-04-20','79','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('89','2026-04-20','67','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('90','2026-04-20','74','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('91','2026-04-20','34','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('92','2026-04-20','106','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('93','2026-04-20','110','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('94','2026-04-20','69','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('95','2026-04-20','97','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('96','2026-04-20','98','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('97','2026-04-20','42','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('98','2026-04-20','2','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('99','2026-04-20','81','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('100','2026-04-20','53','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('101','2026-04-20','105','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('102','2026-04-20','82','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('103','2026-04-20','73','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('104','2026-04-20','119','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('105','2026-04-20','12','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('106','2026-04-20','14','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('107','2026-04-20','63','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('108','2026-04-20','49','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('109','2026-04-20','50','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('110','2026-04-20','71','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('111','2026-04-20','46','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('112','2026-04-20','92','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('113','2026-04-20','68','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('114','2026-04-20','60','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('115','2026-04-20','99','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('116','2026-04-20','39','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:11','0.00','Y','N','0',NULL,'0'),
('117','2026-04-20','112','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:12','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('118','2026-04-20','104','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:12','0.00','Y','N','0',NULL,'0'),
('119','2026-04-20','19','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:12','0.00','Y','N','0',NULL,'0'),
('120','2026-04-20','89','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:12','0.00','Y','N','0',NULL,'0'); 
INSERT INTO `tbl_menustock` VALUES ('121','2026-04-20','35','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:12','0.00','Y','N','0',NULL,'0'),
('122','2026-04-20','102','1',NULL,'0.00000',NULL,NULL,'Y','2026-04-20 11:21:12','0.00','Y','N','0',NULL,'0'); 


DROP TABLE IF EXISTS `tbl_menusubcategory`;
CREATE TABLE `tbl_menusubcategory` (
  `msy_subcategoryid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `msy_branchid` bigint(20) NOT NULL,
  `msy_subcategoryname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `msy_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `msy_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `msy_sub_displayorder` int(11) NOT NULL DEFAULT '1',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `msy_is_central` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `msy_accepted_outlets` longtext COLLATE utf8_unicode_ci,
  `msy_new_subcat` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'N',
  `new_from_cloud` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `central_edited` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `central_id` int(11) DEFAULT NULL,
  `msy_delete_mode` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`msy_subcategoryid`),
  UNIQUE KEY `msy_subcategoryname` (`msy_subcategoryname`),
  KEY `msy_headofficeid` (`msy_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_modulemaster`;
CREATE TABLE `tbl_modulemaster` (
  `mer_moduleid` int(11) NOT NULL AUTO_INCREMENT,
  `mer_modulename` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `mer_modulelink` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mer_moduleid`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_modulemaster` VALUES ('1','Master Tables','','N'),
('2','Menu Masters','','N'),
('3','Reports','report','N'),
('6','Table Order','table_selection','N'),
('8','Bill Generation ','bill_generation_screen1','N'),
('9','Alerts','','N'),
('10','User Permission','user_permission','N'),
('11','Home Page','index','N'); 
INSERT INTO `tbl_modulemaster` VALUES ('12','Admin Home','admin_home','N'),
('14','Feedback','feedback','N'),
('15','Analytics Report Old','main_report','N'),
('16','Manage Stock','stock','N'),
('17','Inventory','inventory','N'),
('18','Take Away','take_away_','N'),
('19','General Branch settings','branch_settings','N'); 
INSERT INTO `tbl_modulemaster` VALUES ('20','Bill History','bill_history','N'),
('21','Loyality Registration','registration','N'),
('23','Food Recipe','food_recipe','N'),
('24','Completed Order','completed_order','N'),
('25','Payment Pending','payment_pending','N'),
('26','Day In View','dayin','N'); 
INSERT INTO `tbl_modulemaster` VALUES ('27','Day Close View','dayclose','N'),
('28','Credit Settlement','credit','N'),
('29','Credit Master','credit_master','N'),
('30','Clear Assigned','clear_assigned','N'),
('31','KOT History','kot_history','N'),
('32','Load ','','N'),
('33','KOD Screen','kod_screen','N'); 
INSERT INTO `tbl_modulemaster` VALUES ('34','Total Analytics','main_report','N'),
('35','Packing Counter','packingcounter','N'),
('36','Vouchers','voucher','N'),
('37','Dine In','dinein','N'),
('38','Counter Sales','counter_sales','N'),
('39','Home Delivery Report','hd_report','N'),
('40','Take Away Report','ta_report','N'); 
INSERT INTO `tbl_modulemaster` VALUES ('41','Database Backup','database_backup','N'),
('42','Consolidated Reports','consolidatedreport','N'),
('43','Day Close Details','dayclosedetails','N'),
('44','KOT TAHD History','kot_tahd_history','N'),
('45','KOT CS History','kot_cs_history','N'),
('46','Stock Master','stock_master','N'); 
INSERT INTO `tbl_modulemaster` VALUES ('47','Banquet','','N'),
('48','Multi Language','','N'),
('49','Shift Details','shiftdetails','N'),
('50','KOT TAHD History','kot_tahd_history','N'),
('51','KOT CS History','kot_cs_history','N'),
('52','Stock Master New','stock_master','N'),
('53','Banquet','','N'); 
INSERT INTO `tbl_modulemaster` VALUES ('55','Menu Upload','menu_uploads','N'),
('56','Banquet Report','banquet_report','N'),
('57','Day Close Old','dayclosedetails1','N'),
('58','Loyalty setting','loyalty_settings','N'),
('59','Dayclose Settings','dayclose_report_settings','N'),
('60','firebase','firebase_setting','N'); 
INSERT INTO `tbl_modulemaster` VALUES ('61','Ledger','ledger','N'),
('62','advance','advance_pay_bill','N'),
('63','CONSOLIDATED KOT HISTORY','cons_kot_history','N'),
('64','Online Integration','urban_piper','N'); 


DROP TABLE IF EXISTS `tbl_modulesubmaster`;
CREATE TABLE `tbl_modulesubmaster` (
  `mser_submoduleid` int(11) NOT NULL AUTO_INCREMENT,
  `mser_moduleid` int(11) NOT NULL,
  `mser_subname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mser_submodulelink` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`mser_submoduleid`),
  KEY `mser_moduleid` (`mser_moduleid`),
  CONSTRAINT `fk_modulesub_modulemaster` FOREIGN KEY (`mser_moduleid`) REFERENCES `tbl_modulemaster` (`mer_moduleid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=277 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_modulesubmaster` VALUES ('1','1','Default','','N'),
('3','1','Country','country_master','N'),
('4','2','Category','category_master','N'),
('5','2','Sub Category','sub_category_master','N'),
('6','2','Menu Manager','menu','N'),
('7','9','Kot Alert','kot','N'),
('8','9','Bill Alert','bill','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('9','9','Water Alert','water','N'),
('10','9','Steward Alert','steward','N'),
('11','1','State','state_master','N'),
('13','1','City','city_master','N'),
('14','1','Department','department_master','N'),
('15','1','Designation','designation_master','N'),
('16','1','Ingredient','ingredient_master','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('17','1','Floor','floor_master','N'),
('18','1','Table','table_master','N'),
('19','1','Portion','portion_master','N'),
('20','1','Kot counter','kot_counter_master','N'),
('21','1','Staff','staff_master','N'),
('22','1','Discount','discount_master','N'),
('23','1','Corporate Discount','corporate_discount','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('24','1','Voucher','voucher_master','N'),
('25','1','Coupon','coupon_company','N'),
('26','6','Load Menu Order','menu_order','N'),
('27','6','Load Div','load_div','N'),
('28','6','Load Response','response','N'),
('29','6','Load View Items','viewitems','N'),
('30','6','Load Item Edit','itemedit','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('31','6','Load Print Details','print_details','N'),
('32','2','Load Subcategory','load_divsubcategory','N'),
('34','1','Load Country','load_divcountry','N'),
('35','1','Load State','load_divstate','N'),
('36','1','Load City','load_divcity','N'),
('37','1','Load Department','load_divdepartment','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('38','1','Load Designation','load_divdesignation','N'),
('39','1','Load Ingredient','load_divingr','N'),
('40','1','Load Floor','load_divfloor','N'),
('41','1','Load Table','load_divtable','N'),
('42','1','Load Portion','load_divportion','N'),
('43','1','Load KOT','load_divkot','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('44','1','Load Staff','load_divstaff','N'),
('45','1','Load Discount','load_divdiscount','N'),
('46','1','Load Corporate Discount','load_divcorporate','N'),
('47','1','Load Voucher Master','load_divvoucher','N'),
('48','1','Load Coupon Company','load_divcompany','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('49','2','Load Category','load_divcategory','N'),
('50','2','Load Menu','load_divmenu','N'),
('51','2','Load Image','load_divimage','N'),
('52','2','Load Takeaway Rate','load_divtakeawayrate','N'),
('53','2','Load Dinein Rate','load_divdinein','N'),
('54','2','Load Combination','load_divcombination','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('55','2','Load Preference','load_divpreference','N'),
('56','2','Load Ingredient','load_divingredient','N'),
('57','2','Load Nutrition','load_divnutrition','N'),
('59','6','Load popup','load_popupmenu','N'),
('60','10','Load Permission','load_permission','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('62','8','Load Bill','load_bill','N'),
('63','8','Load Bill2','bill_generation_screen2','N'),
('64','8','Load Bill3','bill_generation_screen3','N'),
('66','3','Load Report','load_report','N'),
('67','3','Load Print Bill','print_bill','N'),
('68','3','Load Pdf Bill','pdf_bill','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('69','1','Load Maater all','load_divmaster','N'),
('70','2','Load MenuTab','load_menu','N'),
('71','1','Printer Master','printer_master','N'),
('72','1','Database Backup Old','database_backup','N'),
('75','2','Load popup rate','menu_rate','N'),
('76','2','Load popup comb','menu_comb','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('77','2','Load popup image','menu_image','N'),
('78','2','Load popup ingr','menu_ingr','N'),
('79','2','Load popup nutr','menu_nutr','N'),
('80','2','Load popup pref','menu_pref','N'),
('81','2','Load menu edit','menu_edit','N'),
('82','1','Load country edit','country_edit','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('83','1','Load State edit','state_edit','N'),
('84','2','Load Category Edit','category_edit','N'),
('85','1','Load City Edit','city_edit','N'),
('87','2','Load Subcategory edit','subcategory_edit','N'),
('88','1','Load Printer edit','printer_edit','N'),
('89','1','Load KOT edit','kot_edit','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('90','1','Load Table edit','table_edit','N'),
('91','1','Load Department Edit','dept_edit','N'),
('92','1','Load  Floor Edit','floor_edit','N'),
('93','1','Load Designation Edit','desg_edit','N'),
('94','2','Load Portion edit','portion_edit','N'),
('95','1','Load Discount Edit','disc_edit','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('96','1','Load Corporate edit','corp_edit','N'),
('97','1','Load Voucher edit','voucher_edit','N'),
('98','1','Load Coupon Edit','coupon_edit','N'),
('99','1','Load Staff Edit','staff_edit','N'),
('100','2','Load autocomplete','find_keywords','N'),
('101','1','Load Change Password Edit','chng_password_edit','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('102','1','Load Staff View','staff_view','N'),
('103','2','Load chkkkk','','N'),
('104','2','Load Ingredient Edit','ingredient_edit','N'),
('105','2','Load menu view','menu_view','N'),
('106','2','Load Upload gal file','uploadGalFile','N'),
('107','1','Branch master','branch_master','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('108','1','Load Feedback Rating','feedback_rating','N'),
('109','1','Preference Master','preference_master','N'),
('110','2','Edit Preference','preference_edit','N'),
('111','2','Load upload categoryimage','uploadCategory','N'),
('112','16','Load stock','load_divstock','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('113','3','Load Report checker','load_reportcheck','N'),
('114','18','Load Take Away','load_takeaway','N'),
('115','18','Take away staff assign','take_away_staff_assign','N'),
('116','18','Take away KOT','take_away_kot','N'),
('117','18','Load Take Away print','print_details_kot','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('118','18','Load take away pop up','takeaway_list','N'),
('119','18','Take away HD staff Bill','take_away_staff','N'),
('120','18','Take away Bill','take_away_list_bill','N'),
('121','1','Load Printer Type','printer_type_master','N'),
('122','1','Load Printer Type Edit','printer_type_edit','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('123','1','Load  Country Flag','uploadFlag','N'),
('124','2','Load portion default','load_portiondefault','N'),
('125','15','Load analytics report check','load_analyiticscheck','N'),
('126','15','Load total sales report','total_sales_report','N'),
('128','3','Load excel_download','excel_download','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('129','3','Load pdf_bill','pdf_bill','N'),
('130','3','Load  pdf_bill_page','pdf_bill_page','N'),
('131','3','Load pdfexcelcheck','load_pdfexcelcheck','N'),
('143','10','User Permission Edit','User_permission_edit','N'),
('144','19','Branch Settings edit','Edit branch','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('145','18','Load Div Check Menu','load_divcheckmenu','N'),
('146','18','Take away Search todays','take_away_search','N'),
('147','20','Load Bill History','load_bill_history','N'),
('148','24','Load Completed order','load_completedorder','N'),
('149','25','Load Payment Pending','load_paymentpending','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('150','28','Load Credit','load_credit','N'),
('151','31','Load KOT History','load_kothistory','N'),
('152','25','Bill Split','bill_split','N'),
('153','25','Load Bill split','load_billsplit','N'),
('154','1','Bank Master','bank_master','N'),
('155','1','Load Bank Master','bank_edit','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('156','18','TA Bill History','ta_bill_history','N'),
('157','18','Load TA Bill History ','load_ta_history','N'),
('158','33','Load KOD screen two','kod_screen_two','N'),
('159','18','Payment Pending  TA','payments_ta_cs','N'),
('160','18','Total bill history TA','total_ta_bill_history','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('161','18','Customer History TA','ta_customer_history','N'),
('162','36','Voucher payment','voucher_payment','N'),
('163','36','Voucher Head','voucher_head','N'),
('164','38','Load counter sales','load_counter_sales','N'),
('165','38','Load Counter popup','counter_popup','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('166','18','Takeaway Popup','takeaway_popup','N'),
('167','18','Load Takeaway','load_takeaway','N'),
('168','18','Load Payments Takeaway','load_payments_takeaway','N'),
('169','18','Load Payments Takeaway','load_payments_takeaway','N'),
('170','18','Load Staff Assign','load_staff_assign','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('171','18','Staff Assign Quaries','staff_assign_quaries','N'),
('172','18','Assigned Order','staff_assign_detail','N'),
('173','18','Load Staff Assign Detail','load_staff_assign_detail','N'),
('174','38','Counter Sale Kot','counter_sale_kot','N'),
('175','39','Load  HD Report','load_hdreport','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('176','39','Load  HD Report Check','load_hdreportcheck','N'),
('177','39','load_hdrptcheck','load_hdrptcheck','N'),
('178','39','Printer Check_1','printercheck_1','N'),
('181','40','Load TA Report Check','load_tareportcheck','N'),
('182','40','Load TA Report','load_tareport','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('183','40','Load TA rptcheck','load_tarptcheck','N'),
('184','40','TA Print Report','ta_print_report','N'),
('185','6','dinein_Editpopup','dine_Edit_popup','N'),
('186','38','Bill History','cs_bill_history','N'),
('187','18','Settle Bill','payments_takeaway','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('188','6','load_kotcancel_popup','load_kotcancel_popup','N'),
('189','1','cancellation','cancellation','N'),
('190','42','Load Consolidatedreport','load_consolidatedreport','N'),
('191','42','Load consolidatedreportcheck','load_consolidatedreportcheck','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('192','42','Load consolidated_a4print','consolidated_a4print','N'),
('193','1','complimentary_reason','complimentary_reason','N'),
('194','1','load_compedit','load_compedit','N'),
('195','1','cancel_edit','load_canceledit','N'),
('196','1','Denomination','denomination','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('197','1','Load denomination edit','denomination_edit','N'),
('198','1','Regeneration Reason','regeneration','N'),
('199','1','Load regedit','regeneration_edit','N'),
('200','38','Payment_settle_cs','payments_ta_cs','N'),
('201','42','Load consolidatedexcel','consolidatedexcel_download','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('202','42','Load consolidatedexcel','consolidatedexcel_download','N'),
('203','3','Load tacsexcel_download','taexcel_download','N'),
('204','40','Load taa4print','taprint_bill','N'),
('205','42','Load consolidatedexcel','consolidatedexcel_download','N'),
('206','3','Load tacsexcel_download','taexcel_download','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('207','40','Load taa4print','taprint_bill','N'),
('208','1','Expodine Machines','expodine_machines','N'),
('211','1','Load machineedit','machines_edit','N'),
('212','1','Report Master','report_masternew','N'),
('213','43','Load Day Close Details','load_dayclosedetails','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('214','44','Load TA KOT History','load_takothistory','N'),
('215','47','Banquet Registration','banquet_registration','N'),
('216','47','Banquet List','banquet_list','N'),
('217','47','Function Master','function_master','N'),
('218','47','Venue Master','venue_master','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('219','47','Function Extracost Master','function_extracost_master','N'),
('220','47','Reminders','reminders','N'),
('221','1','Currency master','currencymaster','N'),
('222','1','Conversion Rate','conversionrate','N'),
('223','1','Cardmaster','cardmaster','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('224','38','Load CS Bill History','load_cs_history','N'),
('226','56','Load Banquet Report','load_banquet_report','N'),
('227','2','Addons','addons_master','N'),
('228','2','Load addon_edit','load_addon_edit','N'),
('229','2','Load menu_addon','menu_addon','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('230','2','Load addonadd','load_div_addon','N'),
('231','53','Load Banquest List Print','print_function_list','N'),
('232','49','Load Shift Details','load_shiftdetails','N'),
('233','1','Game station','game_station','N'),
('234','18','Hold TA','view_hold','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('235','38','Hold CS','view_hold','N'),
('236','2','Unit master','unit_master','N'),
('237','2','Load unit_master','load_unitmaster_edit','N'),
('238','2','Baseunit','base_unit_master','N'),
('239','2','Load base_unit','load_base_unitmaster','N'),
('240','1','extra_tax','extra_tax','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('241','48','Load multi_language_menu_download','multi_language_menu_download','N'),
('242','2','Load Menu Addons','menu_addons','N'),
('243','2','Load Addons','load_divaddons','N'),
('244','2','Load Menu Combo','combo_add_menuload','N'),
('245','2','Combo','combo','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('246','6','Load Combo Ordering Popup','combo_ordering_popup','N'),
('247','49','Load Shift Details','load_shiftdetails','N'),
('248','18','Load Combo Ordering Popup TA','combo_ordering_popup_ta','N'),
('249','38','Load Combo Ordering Popup CS','combo_ordering_popup_cs','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('250','42','Load banquet_a4','banquet_a4print','N'),
('251','42','Load banquet_excel','banquet_excel_download','N'),
('252','36','Ledger','ledger','N'),
('253','1','Load Salary','staff_salary_detail','N'),
('254','62','reminders_advance','load_advance_reminder','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('255','61','accounts_name','accounts_name','N'),
('256','61','Accounts Data','load_accounts_data','N'),
('257','61','accounts_a4_download','accounts_a4_download','N'),
('258','1','online_partners','online_partners','N'),
('259','1','Load online partners','online_partners_edit','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('260','61','stock_accounts','stock_accounts','N'),
('261','61','a4_daybook','a4_daybook','N'),
('262','61','excel_account_bl_pl','excel_account_bl_pl','N'),
('263','61','open_close_account','open_close_account','N'),
('264','3','online_order_report','online_order_report','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('265','1','inv_kitchen','inv_kitchen','N'),
('266','1','load_cat_image','cat_upload','N'),
('267','61','Ledger Add','journals','N'),
('268','61','Balance Sheet Profit Loss','load_ledger_sheet','N'),
('269','61','Supplier Master','supplier','N'),
('270','61','Expense Voucher','expense_voucher','N'); 
INSERT INTO `tbl_modulesubmaster` VALUES ('271','61','Employee Master','employees','N'),
('272','61','Contra Voucher','contra_voucher','N'),
('273','61','Fixed Asset','asset_master','N'),
('274','61','Receipts','receipts','N'),
('275','61','Loan Advance','loan_advance','N'),
('276','61','Day Book','daybook','N'); 


DROP TABLE IF EXISTS `tbl_monthly_inventory_stock`;
CREATE TABLE `tbl_monthly_inventory_stock` (
  `tms_id` int(11) NOT NULL AUTO_INCREMENT,
  `tms_date` date DEFAULT NULL,
  `tms_store` int(11) DEFAULT NULL,
  `tms_product` int(11) DEFAULT NULL,
  `tms_qty` decimal(15,3) DEFAULT NULL,
  `tms_weight` decimal(15,3) DEFAULT NULL,
  `tms_unit` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tms_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tms_rate` decimal(15,3) DEFAULT NULL,
  `tms_total` decimal(15,3) DEFAULT NULL,
  PRIMARY KEY (`tms_id`),
  UNIQUE KEY `tms_date` (`tms_date`,`tms_store`,`tms_product`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_notifications`;
CREATE TABLE `tbl_notifications` (
  `tbl_notificationid` int(11) NOT NULL AUTO_INCREMENT,
  `tbl_notificationtype` int(11) NOT NULL,
  `tbl_tableid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tbl_message` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `tbl_read` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tbl_readby` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tbl_insertdate` date DEFAULT NULL,
  `tbl_inserttime` time DEFAULT NULL,
  `tbl_readdate` date DEFAULT NULL,
  `tbl_readtime` time DEFAULT NULL,
  `tbl_billno` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tbl_notificationid`),
  KEY `tbl_billno` (`tbl_billno`),
  KEY `tbl_notificationtype` (`tbl_notificationtype`),
  KEY `tbl_readby` (`tbl_readby`),
  KEY `tbl_tableid` (`tbl_tableid`),
  CONSTRAINT `fk_notifications_read_userid` FOREIGN KEY (`tbl_readby`) REFERENCES `tbl_logindetails` (`ls_username`),
  CONSTRAINT `fk_notifications_tableid` FOREIGN KEY (`tbl_tableid`) REFERENCES `tbl_tablemaster` (`tr_tableid`),
  CONSTRAINT `fk_notifications_type_billno` FOREIGN KEY (`tbl_billno`) REFERENCES `tbl_tablebillmaster` (`bm_billno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_online_billdetails`;
CREATE TABLE `tbl_online_billdetails` (
  `tab_billno` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tab_slno` int(11) NOT NULL,
  `tab_menu` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_portion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_qty` int(11) NOT NULL DEFAULT '1',
  `tab_preferencetext` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_status` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_entrytime` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tab_billno`,`tab_slno`),
  CONSTRAINT `fk_online_billdetails_master` FOREIGN KEY (`tab_billno`) REFERENCES `tbl_online_billmaster` (`on_billno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_online_billmaster`;
CREATE TABLE `tbl_online_billmaster` (
  `on_billno` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `on_billdatetime` date NOT NULL,
  `on_orderno` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_kotno` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_customer_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_customer_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_customer_phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_total_items` int(11) DEFAULT NULL,
  `on_order_type` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_delivery_charge` decimal(15,3) DEFAULT NULL,
  `on_delivery_street` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_delivery_building` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_delivery_floor` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_delivery_apartment` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_delivery_state` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_delivery_zip_code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_subtotal` decimal(15,3) NOT NULL DEFAULT '0.000',
  `on_subtotal_final` decimal(15,3) DEFAULT '0.000',
  `on_discountvalue` decimal(15,3) NOT NULL DEFAULT '0.000',
  `on_taxable_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `on_total` decimal(15,3) NOT NULL DEFAULT '0.000',
  `on_roundoff_value` decimal(15,3) DEFAULT '0.000',
  `on_finaltotal` decimal(15,3) DEFAULT '0.000',
  `on_paymode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `on_billprinted` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `on_lastprintime` datetime DEFAULT NULL,
  `on_status` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Billed',
  `on_discountlabel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_bill_ref` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`on_billno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_online_order`;
CREATE TABLE `tbl_online_order` (
  `tol_id` int(11) NOT NULL AUTO_INCREMENT,
  `tol_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tol_discount` decimal(15,3) DEFAULT '0.000',
  `tol_tax` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `tol_tax_value` decimal(15,3) DEFAULT '0.000',
  `tol_credit_settle` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tol_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `tol_order_status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tol_logo_url` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tol_urban_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tol_local_order` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `tol_qr_order` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bu_is_central` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_online_order_counters`;
CREATE TABLE `tbl_online_order_counters` (
  `toc_id` int(11) NOT NULL AUTO_INCREMENT,
  `toc_partner` int(11) DEFAULT NULL,
  `toc_ip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `toc_status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`toc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_online_order_counters` VALUES ('25','1','192.168.0.49','Y'); 


DROP TABLE IF EXISTS `tbl_online_tax`;
CREATE TABLE `tbl_online_tax` (
  `tox_id` int(11) NOT NULL AUTO_INCREMENT,
  `tox_partner` int(11) DEFAULT NULL,
  `tox_tax_id` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`tox_id`),
  UNIQUE KEY `tox_partner` (`tox_partner`,`tox_tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_order_addon`;
CREATE TABLE `tbl_order_addon` (
  `ad_orderno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `ad_order_slno` int(11) NOT NULL,
  `ad_addon_menu` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ad_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `ad_qty` int(11) DEFAULT NULL,
  `ad_total_rate` decimal(15,3) DEFAULT '0.000',
  `ad_dayclosedate` date NOT NULL,
  `ad_entrydate` datetime DEFAULT NULL,
  `ad_kotno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ad_cancelled` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ad_orderno`,`ad_order_slno`,`ad_addon_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_order_addon_changes`;
CREATE TABLE `tbl_order_addon_changes` (
  `adc_cancel_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `adc_cancel_orderno` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `adc_cancel_order_slno` int(11) NOT NULL,
  `adc_cancel_menu` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `adc_cancelled_qty` int(11) NOT NULL,
  `adc_cancelledreason` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `adc_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `adc_cancelledby_careof` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adc_cancelled_date` datetime DEFAULT NULL,
  `adc_dayclosedate` date DEFAULT NULL,
  `adc_kotno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`adc_cancel_id`,`adc_cancel_orderno`,`adc_cancel_order_slno`,`adc_cancel_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_payment_auth_log`;
CREATE TABLE `tbl_payment_auth_log` (
  `tp_id` int(11) NOT NULL AUTO_INCREMENT,
  `tp_datetime` datetime DEFAULT NULL,
  `tp_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_auth_staff` int(11) DEFAULT NULL,
  `tp_pay_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_billno` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tp_id`),
  UNIQUE KEY `tp_billno` (`tp_billno`)
) ENGINE=MyISAM AUTO_INCREMENT=224 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_paymentmode`;
CREATE TABLE `tbl_paymentmode` (
  `pym_id` int(11) NOT NULL,
  `pym_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pym_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pym_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `pym_credit_view` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `pym_changesettled_view` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `pym_takeaway_view` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `pym_counter_view` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`pym_id`),
  UNIQUE KEY `pym_code` (`pym_code`),
  UNIQUE KEY `pym_name` (`pym_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_paymentmode` VALUES ('1','cash','Cash','Y','Y','Y','Y','Y','N'),
('2','credit','Credit / Debit','Y','Y','Y','Y','Y','N'),
('3','coupon','Coupons','N','N','N','Y','Y','N'),
('4','voucher','Voucher','N','N','N','N','N','N'),
('5','cheque','Cheque','N','N','N','N','N','N'),
('6','credit_person','Credit Types','Y','N','N','Y','Y','N'); 
INSERT INTO `tbl_paymentmode` VALUES ('7','complimentary','Complimentary','Y','N','N','Y','Y','N'),
('8','upi','UPI ','N','N','N','Y','Y','N'); 


DROP TABLE IF EXISTS `tbl_physical_default`;
CREATE TABLE `tbl_physical_default` (
  `tpf_id` int(11) NOT NULL AUTO_INCREMENT,
  `tpf_product` int(11) DEFAULT NULL,
  `tpf_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpf_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpf_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpf_qty` decimal(15,3) DEFAULT NULL,
  `tpf_weight` decimal(15,3) DEFAULT NULL,
  `tpf_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpf_unit_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpf_store` int(11) DEFAULT NULL,
  PRIMARY KEY (`tpf_id`),
  UNIQUE KEY `tpf_product` (`tpf_product`,`tpf_store`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_physical_stock`;
CREATE TABLE `tbl_physical_stock` (
  `tps_id` int(11) NOT NULL AUTO_INCREMENT,
  `tps_phy_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_product` int(11) DEFAULT NULL,
  `tps_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_unittype` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_qty` int(11) NOT NULL DEFAULT '0',
  `tps_weight` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tps_store_qty` int(11) DEFAULT NULL,
  `tps_store_weight` decimal(15,3) DEFAULT NULL,
  `tps_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_date` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_set` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tps_store` int(11) DEFAULT NULL,
  `tps_rate` decimal(15,3) DEFAULT NULL,
  `tps_total` decimal(15,3) DEFAULT NULL,
  `tps_approve_date` date DEFAULT NULL,
  `tps_approved_by` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_reason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tps_aprroving_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tps_id`),
  UNIQUE KEY `tps_phy_id` (`tps_phy_id`,`tps_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_pinmode_log`;
CREATE TABLE `tbl_pinmode_log` (
  `tpn_id` int(11) NOT NULL AUTO_INCREMENT,
  `tpn_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpn_staff` int(11) DEFAULT NULL,
  `tpn_date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`tpn_id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_portionmaster`;
CREATE TABLE `tbl_portionmaster` (
  `pm_id` int(11) NOT NULL AUTO_INCREMENT,
  `pm_portionname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pm_portionshortcode` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `pm_viewinbill` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `pm_viewinkot` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `pm_ratio` decimal(3,2) DEFAULT '1.00',
  `pm_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT '1',
  `pm_is_central` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`pm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_portionmaster` VALUES ('1','Single','S','N','Y','1.00','Y','N','1','N'),
('2','Half','H','Y','Y','1.00','Y','N','1','N'),
('3','Quarter','Q','Y','Y','1.00','Y','N','1','N'),
('4','Full','F','Y','Y','1.00','Y','N','1','N'),
('5','Small','S','Y','Y','1.00','Y','N','1','N'),
('6','Medium','M','Y','Y','1.00','Y','N','1','N'); 
INSERT INTO `tbl_portionmaster` VALUES ('7','Large','L','Y','Y','1.00','Y','N','1','N'); 


DROP TABLE IF EXISTS `tbl_preferencemaster`;
CREATE TABLE `tbl_preferencemaster` (
  `pmr_id` int(11) NOT NULL AUTO_INCREMENT,
  `pmr_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pmr_android_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`pmr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_printer_function_log`;
CREATE TABLE `tbl_printer_function_log` (
  `tpf_id` int(11) NOT NULL AUTO_INCREMENT,
  `tpf_log_data` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpf_date_time` datetime DEFAULT NULL,
  `tpf_print_status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tpf_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62308 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_printer_styles`;
CREATE TABLE `tbl_printer_styles` (
  `ps_id` int(11) NOT NULL AUTO_INCREMENT,
  `ps_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ps_description` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ps_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_printer_styles` VALUES ('1','style 1','length 46-','N'),
('2','style 2','length 42-TVS MODELS','N'),
('3','style 3','china rocket 300 - 60','N'),
('4','style 4','rugtek - 60','N'); 


DROP TABLE IF EXISTS `tbl_printersettings`;
CREATE TABLE `tbl_printersettings` (
  `pr_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pr_printername` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pr_printerip` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pr_printerport` int(11) DEFAULT NULL,
  `pr_branchid` bigint(20) NOT NULL,
  `pr_printertype` int(11) NOT NULL,
  `pr_floorid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pr_kotcode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pr_usbprinterip` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pr_usbprinter` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pr_defaultusb` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `pr_enable` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `pr_printcount` int(11) NOT NULL DEFAULT '1',
  `pr_style` int(11) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`pr_id`),
  KEY `pr_branchid` (`pr_branchid`),
  KEY `pr_floorid` (`pr_floorid`),
  KEY `pr_kotcode` (`pr_kotcode`),
  KEY `pr_printertype` (`pr_printertype`),
  KEY `pr_style` (`pr_style`),
  CONSTRAINT `fk_kotcountermaster_kotcode` FOREIGN KEY (`pr_kotcode`) REFERENCES `tbl_kotcountermaster` (`kr_kotcode`) ON UPDATE CASCADE,
  CONSTRAINT `fk_printersettings_branchid` FOREIGN KEY (`pr_branchid`) REFERENCES `tbl_branchmaster` (`be_branchid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_printersettings_floorid` FOREIGN KEY (`pr_floorid`) REFERENCES `tbl_floormaster` (`fr_floorid`),
  CONSTRAINT `fk_printersettings_printertype` FOREIGN KEY (`pr_printertype`) REFERENCES `tbl_printertype` (`pt_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_printersettings_printstyle` FOREIGN KEY (`pr_style`) REFERENCES `tbl_printer_styles` (`ps_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_printersettings` VALUES ('1','KOT MAIN KITCHEN','192.168.1.88','9100','1','1','1','1',NULL,NULL,'N','Y','1','1','N'),
('2','KOT CONS Dine In','192.168.1.88','9100','1','6','1',NULL,NULL,NULL,'N','Y','1','1','N'),
('3','BILL Dine In','192.168.1.88','9100','1','2','1',NULL,NULL,NULL,'N','Y','1','1','N'); 
INSERT INTO `tbl_printersettings` VALUES ('4','TA KOT','192.168.1.88','9100','1','4',NULL,'1',NULL,NULL,'N','Y','1','1','N'),
('5','TA KOT CONS','192.168.1.88','9100','1','7',NULL,NULL,NULL,NULL,'N','Y','1','1','N'),
('6','TA BILL','192.168.1.88','9100','1','5',NULL,NULL,NULL,NULL,'N','Y','1','1','N'); 
INSERT INTO `tbl_printersettings` VALUES ('7','CS BILL','192.168.1.88','9100','1','11',NULL,NULL,NULL,NULL,'N','Y','1','1','N'),
('8','REPORT','192.168.1.88','9100','1','3',NULL,NULL,NULL,NULL,'N','Y','1','1','N'); 


DROP TABLE IF EXISTS `tbl_printersettings_ip`;
CREATE TABLE `tbl_printersettings_ip` (
  `pr_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pr_slno` int(11) NOT NULL DEFAULT '1',
  `pr_machine_ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '127.0.0.1',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`pr_id`,`pr_machine_ip`),
  CONSTRAINT `fk_printersettings_ip_printid` FOREIGN KEY (`pr_id`) REFERENCES `tbl_printersettings` (`pr_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_printersettings_log`;
CREATE TABLE `tbl_printersettings_log` (
  `l_id` int(11) NOT NULL AUTO_INCREMENT,
  `l_log` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `l_date_time` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_printertype`;
CREATE TABLE `tbl_printertype` (
  `pt_id` int(11) NOT NULL AUTO_INCREMENT,
  `pt_typename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pt_kotstatus` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `pt_floorvisible` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`pt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_printertype` VALUES ('1','KOT Print','Y','Y','N'),
('2','Bill Print','N','Y','N'),
('3','Report Print','N','N','N'),
('4','KOT Print TA CS','Y','N','N'),
('5','Bill Print TA CS','N','N','N'),
('6','Consolidated','Y','Y','N'),
('7','Consolidated TA CS','N','N','N'),
('8','Shift Report Print','N','N','N'); 
INSERT INTO `tbl_printertype` VALUES ('9','Online KOT','Y','N','N'),
('10','Online Bill','N','N','N'),
('11','Bill Print CS','N','N','N'); 


DROP TABLE IF EXISTS `tbl_product_conversion`;
CREATE TABLE `tbl_product_conversion` (
  `tpc_id` int(11) NOT NULL AUTO_INCREMENT,
  `tpc_from_product` int(11) DEFAULT NULL,
  `tpc_to_product` int(11) DEFAULT NULL,
  `tpc_from_store` int(11) DEFAULT NULL,
  `tpc_to_store` int(11) DEFAULT NULL,
  `tpc_date` date DEFAULT NULL,
  `tpc_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpc_qty` decimal(15,3) DEFAULT NULL,
  `tpc_weight` decimal(15,3) DEFAULT NULL,
  `tpc_from_weight` decimal(15,3) DEFAULT NULL,
  `tpc_from_qty` decimal(15,3) DEFAULT NULL,
  `tpc_set` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tpc_from_cloud` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`tpc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_production`;
CREATE TABLE `tbl_production` (
  `tp_id` int(11) NOT NULL AUTO_INCREMENT,
  `tp_production_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_product` int(11) DEFAULT NULL,
  `tp_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_unit_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_qty` decimal(15,3) DEFAULT NULL,
  `tp_weight` decimal(15,3) DEFAULT NULL,
  `tp_date` date DEFAULT NULL,
  `tp_set` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tp_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_store` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tp_portion` int(11) DEFAULT NULL,
  `tp_prod_central_id` int(11) DEFAULT NULL,
  `tp_cloud_added` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`tp_id`),
  UNIQUE KEY `tp_production_id` (`tp_production_id`,`tp_product`,`tp_portion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_profession_master`;
CREATE TABLE `tbl_profession_master` (
  `pr_id` int(11) NOT NULL AUTO_INCREMENT,
  `pr_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`pr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_purchase_order`;
CREATE TABLE `tbl_purchase_order` (
  `tp_id` int(11) NOT NULL AUTO_INCREMENT,
  `tp_purchase_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_dayclosedate` date DEFAULT NULL,
  `tp_product` int(11) DEFAULT NULL,
  `tp_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_unittype` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_weight` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tp_qty` int(11) DEFAULT NULL,
  `tp_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_supplier` int(11) DEFAULT NULL,
  `tp_store` int(11) DEFAULT NULL,
  `tp_set` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tp_login` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `tp_status_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tp_status_date` datetime DEFAULT NULL,
  `tp_status` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tp_ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tp_id`),
  UNIQUE KEY `tp_purchase_id` (`tp_purchase_id`,`tp_dayclosedate`,`tp_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_purchase_return`;
CREATE TABLE `tbl_purchase_return` (
  `tpr_id` int(11) NOT NULL AUTO_INCREMENT,
  `tpr_return_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpr_store` int(11) DEFAULT NULL,
  `tpr_menu` int(11) DEFAULT NULL,
  `tpr_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpr_unit_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpr_qty` int(11) DEFAULT NULL,
  `tpr_weight` decimal(15,3) DEFAULT NULL,
  `tpr_rate` decimal(15,3) DEFAULT NULL,
  `tpr_total` decimal(15,3) DEFAULT NULL,
  `tp_tax` decimal(15,3) DEFAULT NULL,
  `tpp_tax_rate` decimal(15,3) DEFAULT NULL,
  `tpr_final` decimal(15,3) DEFAULT NULL,
  `tpr_date` date DEFAULT NULL,
  `tpr_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpr_grn` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpr_remarks` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tpr_set` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tpr_batch` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tpr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_receipts`;
CREATE TABLE `tbl_receipts` (
  `tr_id` int(11) NOT NULL AUTO_INCREMENT,
  `tr_date` date DEFAULT NULL,
  `tr_acc_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_from` int(11) DEFAULT NULL,
  `tr_to` int(11) DEFAULT NULL,
  `tr_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tr_transaction` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_received` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_particulars` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_entry_date` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_regenerate_reasons`;
CREATE TABLE `tbl_regenerate_reasons` (
  `rr_id` int(11) NOT NULL AUTO_INCREMENT,
  `rr_reason` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `rr_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`rr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_regenerate_reasons` VALUES ('1','Quantity change','Y','N'),
('2','Kot Cancellation','Y','N'); 


DROP TABLE IF EXISTS `tbl_regenrate_log`;
CREATE TABLE `tbl_regenrate_log` (
  `re_id` int(11) NOT NULL AUTO_INCREMENT,
  `re_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `re_datetime` datetime DEFAULT NULL,
  `re_staffid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `re_reason` text COLLATE utf8_unicode_ci,
  `re_loginid` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `re_secretkey` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `re_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `re_order_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `re_new_bill_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`re_id`),
  KEY `re_loginid` (`re_loginid`),
  KEY `re_staffid` (`re_staffid`),
  CONSTRAINT `fk_regenrate_loginid` FOREIGN KEY (`re_loginid`) REFERENCES `tbl_logindetails` (`ls_username`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_regenrate_staffid` FOREIGN KEY (`re_staffid`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_report_bydate`;
CREATE TABLE `tbl_report_bydate` (
  `rbd_id` int(11) NOT NULL AUTO_INCREMENT,
  `rbd_typename` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `rbd_date_limit` int(11) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`rbd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_reportmaster`;
CREATE TABLE `tbl_reportmaster` (
  `rm_id` int(11) NOT NULL AUTO_INCREMENT,
  `rm_reportid` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `rm_reportname` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `rm_reportview` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `rm_printa4` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `rm_posprintofanother` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rm_daycloseprint` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `rm_dayclosemail` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `rm_reporttype` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'DI',
  `rm_dayclose_print_order` int(11) NOT NULL DEFAULT '0',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`rm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_reportmaster` VALUES ('1','tot_sales','Total sales','Y','Y','tot_sales','N','Y','DI','3','N'),
('2','order','Item Ordered','Y','Y','order','N','N','DI','0','N'),
('3','bill_details','Bill Details','Y','N','bill_details','N','N','DI','0','N'),
('4','summary','Summary Report','Y','Y','summary','N','N','DI','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('5','categorywise_report','Category Wise Report ','Y','Y','categorywise_report','N','N','DI','0','N'),
('6','cancel_history','Item Cancel History','Y','Y','cancel_history','N','Y','DI','0','N'),
('7','bill_cancel','Bill Cancel History','Y','Y','bill_cancel','N','Y','DI','11','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('8','steward','Steward','Y','Y','steward','N','N','DI','0','N'),
('9','item','Items','Y','N','item','N','N','DI','0','N'),
('10','regenerate_bill_logs','Regenerate Bill Logs','Y','N','regenerate_bill_logs','N','Y','DI','17','N'),
('11','table_turnoversummary','Table TurnOver Summary','Y','Y','table_turnoversummary','N','N','DI','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('12','tax_sales_summary','Tax Sales Summary','Y','Y','tax_sales_summary','N','N','DI','0','N'),
('13','steward_timely','Steward_Timely_Report','Y','N','steward_timely','N','N','DI','0','N'),
('14','loyality_customer','Loyality Customer Registration','Y','N','loyality_customer','N','N','DI','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('15','feedback_report','Item Feedback Report','Y','N','feedback_report','N','N','DI','0','N'),
('16','general_feedback','General Feedback Rating','Y','N','general_feedback','N','N','DI','0','N'),
('17','feedback_summary','General Feedback Summary','Y','N','feedback_summary','N','N','DI','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('18','no_sale_report','No Sale Report','Y','N','no_sale_report','N','N','DI','0','N'),
('19','stewards_performance_report','Stewards Performance Report','Y','Y','stewards_performance_report','N','N','DI','0','N'),
('20','credit_details','Credit Details','N','Y','credit_details','N','Y','DI','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('21','totalsales_cs','Total Sales Counter','Y','Y','totalsales_cs','N','Y','CS','4','N'),
('22','itemordered_cs','Item ordered CS','Y','Y','itemordered_cs','N','N','CS','0','N'),
('23','categorywise_report_cs','Category Wise Report ','Y','Y','categorywise_report_cs','N','N','CS','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('24','billcancel_cs','Cancelled Bill ','Y','N','billcancel_cs','N','Y','CS','12','N'),
('25','billreport_cs','Bill Report','Y','Y','billreport_cs','N','N','CS','0','N'),
('26','cancelhistory_cs','Item Cancel History','Y','Y','cancelhistory_cs','N','Y','CS','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('27','summary_cs','Summary Report CS','Y','N','summary_cs','N','N','CS','0','N'),
('28','tot_sales_hd','Total sales','Y','Y','tot_sales_hd','N','Y','HD','5','N'),
('29','order_hd','Item Ordered','Y','Y','order_hd','N','N','HD','0','N'),
('30','categorywise_report_hd','Category Wise Report ','Y','Y','categorywise_report_hd','N','N','HD','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('31','cancel_history_hd','Bill Canceled History','Y','Y','cancel_history_hd','N','Y','HD','13','N'),
('32','summary_hd','Summary','Y','Y','summary_hd','N','N','HD','0','N'),
('33','tot_sales_ta','Total Sales','Y','Y','tot_sales_ta','N','Y','TA','6','N'),
('34','order_ta','Item Ordered','Y','Y','order_ta','N','N','TA','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('35','categorywise_report_ta','Category Wise Report ','Y','Y','categorywise_report_ta','N','N','TA','0','N'),
('36','cancel_history_ta','Bill Canceled History','Y','Y','cancel_history_ta','N','Y','TA','14','N'),
('37','summary_ta','Summary','Y','Y','summary_ta','N','N','TA','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('38','sales_summary_report_cr','Sale Summary Report','Y','Y','sales_summary_report_cr','Y','Y','CR','1','N'),
('39','summary_report_cr','Summary Report Consolidated','Y','Y','summary_report_cr','Y','Y','CR','2','N'),
('40','total_summary_details_cr','Total Summary Details','Y','N','total_summary_details_cr','N','N','CR','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('41','item_ordered_cr','Item Ordered Report','Y','Y','item_ordered_cr','N','Y','CR','7','N'),
('42','categorywise_report_cr','Categorywise Report','Y','Y','categorywise_report_cr','N','Y','CR','8','N'),
('43','cash_settling_report_cr','Staff Wise Settlement Report ','Y','Y','cash_settling_report_cr','N','N','CR','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('44','kitchen_wise_report_cr','Kitchen Wise Report','Y','Y','kitchen_wise_report_cr','N','N','CR','0','N'),
('45','discount_report_cr','Discount Report Consolidated','Y','Y','discount_report_cr','N','Y','CR','9','N'),
('46','complimentary_cr','Consolidated Complimentary Report','Y','Y','complimentary_cr','N','Y','CR','10','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('47','tax_report','Tax Report','Y','N','tax_report','N','N','CR','0','N'),
('48','consolidated_credit_summury','Credit Summary Report','Y','Y','consolidated_credit_summury','N','N','CR','0','N'),
('49','consolidated_cancel_report','Item Cancel Report ','Y','Y','consolidated_cancel_report','N','Y','CR','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('50','consolidated_payment_cr','Payment Report Consolidated','Y','Y','consolidated_payment_cr','N','Y','CR','0','N'),
('51','most_revenue_generated_item_cr','Most Revenue Generated Items','Y','Y','most_revenue_generated_item_cr','N','N','CR','0','N'),
('52','hourlywise_report_cr','Hourly Wise Report','Y','Y','hourlywise_report_cr','N','N','CR','15','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('53','consolidated_timely_report','Hourly Report Day Close','N','Y','consolidated_timely_report','N','N','CR','0','N'),
('54','consolidated_shift_report','Shift Login Report','Y','N','consolidated_shift_report','N','N','CR','0','N'),
('55','voucher_expense','Voucher Expense','Y','Y','voucher_expense','N','Y','CR','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('56','regenerate_logs','Regenerate','N','Y','regenerate_logs','N','Y','CR','0','N'),
('57','banquet_sales_report','Banquet Sales','Y','N','banquet_sales_report','N','N','BQ','0','N'),
('58','billreport_ta','Bill Report','Y','N','billreport_ta','N','N','TA','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('59','billreport_hd','Bill Report','Y','N','billreport_hd','N','N','HD','0','N'),
('60','billreport_cr','Bill Report','N','N','billreport_cr','N','N','CR','0','N'),
('61','summary_specified_consolidated','Specified Summary Report','Y','Y','summary_specified_consolidated','Y','Y','CR','16','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('62','tips_collected_consolidated','Tips Collected Report','Y','Y','tips_collected_consolidated','N','N','CR','0','N'),
('63','totalsales_consolidate_report_cr','ADSR Total Sales Report Consolidated','Y','N','totalsales_consolidate_report_cr','N','N','CR','2','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('64','delivery_report_hd','Delivery Report','Y','Y','delivery_report_hd','N','N','HD','24','N'),
('65','staff_change_log_report','Staff Change Log','Y','N','staff_change_log_report','N','N','CR','30','N'),
('66','customers_ta','Customer Details Takeaway','Y','N','customers_ta','N','N','TA','25','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('67','billwise_item_cr','Consolidated Bill Details Report','Y','N','billwise_item_cr','N','N','CR','0','N'),
('68','advance_payment_cr','Advance Payment Report','Y','N','advance_payment_cr','N','N','CR','0','N'),
('69','loyalty_staff_cr','Customer Loyalty Report','Y','N','loyalty_staff_cr','N','N','CR','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('70','bill_cancel_consolidated','Bill Cancel Consolidated','Y','N','bill_cancel_consolidated','N','N','CR','0','N'),
('71','tot_sale_online','Online Sale','Y','N','tot_sale_online','N','N','OL','0','N'),
('72','credit_summary_client','Summary Credit Report','Y','N','credit_summary_client','N','N','CR','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('73','stock_daywise_report','Stock Report','Y','N','stock_daywise_report','N','N','CR','0','N'),
('74','reprint_report','Reprint Report','Y','N','reprint_report','N','N','CR','0','N'),
('75','qr_sale_timely','QR Sale Timely','Y','N','qr_sale_timely','N','N','OL','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('76','qr_customer_report','QR Customer Report','Y','N','qr_customer_report','N','N','OL','0','N'),
('77','qr_item_report','QR Item Report','Y','N','qr_item_report','N','N','OL','0','N'),
('78','expense_acc_report','Expense Account Report','Y','N','expense_acc_report','N','N','CR','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('79','online_item_report','Online Item Report','Y','N','online_item_report','N','N','OL','0','N'),
('80','counter_shift_cr','Counter Shift Report','Y','Y','counter_shift_cr','N','N','CR','0','N'),
('81','bill_wise_lukado','Bill Wise Report','Y','N','bill_wise_lukado','N','N','CR','0','N'); 
INSERT INTO `tbl_reportmaster` VALUES ('82','purchase_acc_report','Purchase Account Report','Y','Y','purchase_acc_report','N','N','CR','0','N'),
('83','mult_card_bank_report','Multi Card / Bank Report','Y','Y','mult_card_bank_report','N','N','CR','0','N'),
('84','shift_detail_cr','Shift Detail Report','Y','N','shift_detail_cr','N','N','CR','0','N'); 


DROP TABLE IF EXISTS `tbl_reprint_details`;
CREATE TABLE `tbl_reprint_details` (
  `tr_id` int(11) NOT NULL AUTO_INCREMENT,
  `tr_bill` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_kot` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_date` datetime DEFAULT NULL,
  PRIMARY KEY (`tr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2632 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_requisition`;
CREATE TABLE `tbl_requisition` (
  `tr_id` int(11) NOT NULL AUTO_INCREMENT,
  `tr_req_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_dayclosedate` date DEFAULT NULL,
  `tr_product` int(11) DEFAULT NULL,
  `tr_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_unittype` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_weight` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tr_qty` int(11) NOT NULL DEFAULT '0',
  `tr_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_set` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tr_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_status_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_status` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_status_date` datetime DEFAULT NULL,
  `tr_store` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tr_branchid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_central` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tr_central_accept` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tr_indent` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tr_indent_done` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tr_indent_accepted` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tr_ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_central_menu_id` int(11) DEFAULT NULL,
  `tr_central_partial` varchar(2) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tr_partial_option` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_cancel_updated` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tr_cancel_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`tr_id`),
  UNIQUE KEY `tr_req_id` (`tr_req_id`,`tr_dayclosedate`,`tr_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_reset_bill_log`;
CREATE TABLE `tbl_reset_bill_log` (
  `rs_id` int(11) NOT NULL AUTO_INCREMENT,
  `rs_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rs_date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`rs_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_return_payment`;
CREATE TABLE `tbl_return_payment` (
  `tr_id` int(11) NOT NULL AUTO_INCREMENT,
  `tr_vendor` int(11) DEFAULT NULL,
  `tr_to_acc` int(11) DEFAULT NULL,
  `tr_return_amount` decimal(15,3) DEFAULT '0.000',
  `tr_date` datetime DEFAULT NULL,
  `tr_particulars` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_invoice` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tr_sv_id` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_roommaster`;
CREATE TABLE `tbl_roommaster` (
  `rm_roomid` int(11) NOT NULL AUTO_INCREMENT,
  `rm_roomno` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `rm_status` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`rm_roomid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_secretkeymaster`;
CREATE TABLE `tbl_secretkeymaster` (
  `sr_id` int(11) NOT NULL AUTO_INCREMENT,
  `sr_staffid` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `sr_key` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sr_password` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sr_generatedtime` datetime NOT NULL,
  `sr_expiredtime` datetime DEFAULT NULL,
  `sr_defaultkey` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`sr_id`),
  KEY `sr_staffid` (`sr_staffid`),
  CONSTRAINT `fk_secretkey_staffid` FOREIGN KEY (`sr_staffid`) REFERENCES `tbl_staffmaster` (`ser_staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_shift_card_detail_close`;
CREATE TABLE `tbl_shift_card_detail_close` (
  `sb_shiftdate_close` date NOT NULL,
  `sb_shiftid_close` smallint(6) NOT NULL,
  `sb_bankid_close` int(11) NOT NULL,
  `sb_card_amount_close` decimal(15,3) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`sb_shiftdate_close`,`sb_shiftid_close`,`sb_bankid_close`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_shift_card_detail_open`;
CREATE TABLE `tbl_shift_card_detail_open` (
  `sb_shiftdate` date NOT NULL,
  `sb_shiftid` smallint(6) NOT NULL,
  `sb_bankid` int(11) NOT NULL,
  `sb_card_amount` decimal(15,3) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`sb_shiftdate`,`sb_shiftid`,`sb_bankid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_shift_close_denomination`;
CREATE TABLE `tbl_shift_close_denomination` (
  `dod_day` date NOT NULL,
  `dod_shidt_slno` smallint(6) NOT NULL,
  `dod_deno_id` int(11) NOT NULL,
  `dod_count` int(11) NOT NULL DEFAULT '0',
  `dod_value` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`dod_day`,`dod_shidt_slno`,`dod_deno_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_shift_details`;
CREATE TABLE `tbl_shift_details` (
  `sd_day` date NOT NULL,
  `sd_id` smallint(6) NOT NULL,
  `sd_open` datetime NOT NULL,
  `sd_open_staff` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sd_open_balance` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sd_open_petty` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sd_total_value` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sd_total_deno_value` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sd_open_machineid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sd_close` datetime DEFAULT NULL,
  `sd_close_balance` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sd_close_petty` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sd_total_value_close` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sd_total_deno_value_close` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sd_close_machineid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sd_changein_open` decimal(15,4) DEFAULT NULL,
  `sd_changein_close` decimal(15,4) DEFAULT NULL,
  `sd_open_method` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`sd_day`,`sd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_shift_open_denomination`;
CREATE TABLE `tbl_shift_open_denomination` (
  `dod_day` date NOT NULL,
  `dod_shidt_slno` smallint(6) NOT NULL,
  `dod_deno_id` int(11) NOT NULL,
  `dod_count` int(11) NOT NULL DEFAULT '0',
  `dod_value` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`dod_day`,`dod_shidt_slno`,`dod_deno_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_sms_report_settings`;
CREATE TABLE `tbl_sms_report_settings` (
  `ss_id` int(11) NOT NULL,
  `ss_label` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ss_show` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ss_timely_report_show` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ss_last_updated` datetime DEFAULT NULL,
  `ss_updated_login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ss_last_updated_timely` datetime DEFAULT NULL,
  `ss_timely_update_login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `tbl_sms_report_settings` VALUES ('1','Total Sales Inclusive Tax','Y','Y',NULL,NULL,NULL,NULL),
('2','Total Sales Exclusive Tax','Y','Y',NULL,NULL,NULL,NULL),
('3','Kot Value','Y','Y',NULL,NULL,NULL,NULL),
('4','Stewards Sale','Y','Y',NULL,NULL,NULL,NULL),
('5','Total Bill Count','Y','Y',NULL,NULL,NULL,NULL); 
INSERT INTO `tbl_sms_report_settings` VALUES ('6','Total Pax','Y','Y',NULL,NULL,NULL,NULL),
('7','DI Sale','Y','Y',NULL,NULL,NULL,NULL),
('8','TA Sale','Y','Y',NULL,NULL,NULL,NULL),
('9','HD Sale','Y','Y',NULL,NULL,NULL,NULL),
('10','CS Sale','Y','Y',NULL,NULL,NULL,NULL),
('11','Bill Cancel Value','Y','Y',NULL,NULL,NULL,NULL); 


DROP TABLE IF EXISTS `tbl_sms_report_slab`;
CREATE TABLE `tbl_sms_report_slab` (
  `sr_id` int(11) NOT NULL,
  `sr_salevalue` decimal(15,2) NOT NULL,
  `sms_text` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `sr_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`sr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_sms_time_settings`;
CREATE TABLE `tbl_sms_time_settings` (
  `tsr_id` int(11) NOT NULL AUTO_INCREMENT,
  `tsr_time` time DEFAULT NULL,
  PRIMARY KEY (`tsr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_staff_salary_detail`;
CREATE TABLE `tbl_staff_salary_detail` (
  `ts_id` int(11) NOT NULL AUTO_INCREMENT,
  `ts_staff_id` int(11) DEFAULT NULL,
  `ts_date_time` datetime DEFAULT NULL,
  `ts_amount` decimal(15,3) DEFAULT NULL,
  `ts_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_staffmaster`;
CREATE TABLE `tbl_staffmaster` (
  `ser_staffid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ser_firstname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ser_lastname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_gender` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ser_designation` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_department` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_dob` date DEFAULT NULL,
  `ser_address1` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_address2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_dateofjoin` date DEFAULT NULL,
  `ser_mobileno` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_alternateno` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_employeestatus` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_remarks` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_idtype` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_idno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_branchofficeid` bigint(20) DEFAULT NULL,
  `ser_cancelpermission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_cancelwithkey` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ser_defaultfloor` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_mode` char(1) COLLATE utf8_unicode_ci DEFAULT 'B',
  `ser_discountpermission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_compl_mgmt` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_stockchng_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_discount_manual` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_counter_enable_generate` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_counter_enable_hold` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `ser_permit_cash_drawer_open` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_kot_cancel_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_confirm_code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_authorisation_code` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_bill_cancel_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_rate_edit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_dayclose_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_shift_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_release_login` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_bill_regen_per` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_bill_reprint_per` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_kot_reprint_per` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_bill_settle_change_per` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_order_split_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_tip_edit_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_dayclose_revert_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_bill_reset` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_salary` decimal(15,3) DEFAULT NULL,
  `ser_credit_view` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_comp_view` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_credit_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_comp_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_bill_print_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_bill_settle_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_bill_edit_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_change_table_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_advance_pay_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_counter_settle_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_reset_accounts` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `ser_last_inherit_staff` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_online_order` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_inv_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_physical_stock_permission` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_wastage_entry` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_stock_entry` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_req` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_po` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_rps` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_store_transfer` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_return_history` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_inventory_reports` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_purchase_return` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_consumption` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_store_stock` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_dashboard` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_recipe` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_production` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_central_kitchen` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_central_accept` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_com_item` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_inv_check_all` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_force_close` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_discount_after` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_all_shift_closer` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_item_discount_manual` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_indent` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_delete_menu` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_menu_unit_edit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_store_inv` int(11) DEFAULT '1',
  `ser_stores` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_approve_cancel_inv` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_direct_transfer` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_indent_accept` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `ser_normal_transfer_accept` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_direct_transfer_accept` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_created_by` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_created_time` datetime DEFAULT NULL,
  `ser_last_update` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_cloud_added` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_cloud_edit` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_perm_edited_cloud` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_delete_mode` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_last_inherit_permision` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_last_inherit_user_permision` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_last_inherit_app_permision` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ser_app_change` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ser_enable_type` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ser_staffid`),
  UNIQUE KEY `ser_authorisation_code` (`ser_authorisation_code`),
  UNIQUE KEY `ser_confirm_code` (`ser_confirm_code`),
  KEY `ser_branchofficeid` (`ser_branchofficeid`),
  KEY `ser_defaultfloor` (`ser_defaultfloor`),
  KEY `ser_department` (`ser_department`),
  KEY `ser_designation` (`ser_designation`),
  CONSTRAINT `fk_staffmaster_branchid` FOREIGN KEY (`ser_branchofficeid`) REFERENCES `tbl_branchmaster` (`be_branchid`),
  CONSTRAINT `fk_staffmaster_defaultfloor` FOREIGN KEY (`ser_defaultfloor`) REFERENCES `tbl_floormaster` (`fr_floorid`),
  CONSTRAINT `fk_staffmaster_department` FOREIGN KEY (`ser_department`) REFERENCES `tbl_departmentmaster` (`der_departmentid`),
  CONSTRAINT `fk_staffmaster_designation` FOREIGN KEY (`ser_designation`) REFERENCES `tbl_designationmaster` (`dr_designationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_staffmaster` VALUES ('1','Admin',NULL,'Male','3','1',NULL,'Explore',NULL,NULL,'',NULL,NULL,'Active',NULL,NULL,NULL,'1','Y','N',NULL,'B','Y','N','N','Y','N','Y','Y','Y',NULL,'3681','Y','N','Y','N','Y','Y','Y','Y','Y','N','N','Y','Y','Y',NULL,'Y','Y','Y','Y','N','N','N','N','N','N','Y',NULL,'Y','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','1',NULL,'N','N','N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,'Y','N'); 
INSERT INTO `tbl_staffmaster` VALUES ('2','Manager',NULL,'Male','1','1',NULL,'Explore','',NULL,'','','','Active','','','','1','Y','N',NULL,'B','Y','N','N','Y','N','Y','N','Y',NULL,'4127','Y','N','Y','N','N','Y','Y','Y','Y','Y','N','Y','Y','N',NULL,'Y','Y','Y','Y','N','N','N','N','N','N','N',NULL,'N','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','1',NULL,'N','N','N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,'Y','N'); 
INSERT INTO `tbl_staffmaster` VALUES ('3','Cashier',NULL,'Male','8','1',NULL,'Explore','',NULL,'','','','Active',NULL,NULL,NULL,'1','N','N',NULL,'B','Y','N','N','Y','N','Y','N','Y',NULL,'4321','N','N','Y','N','N','Y','Y','N','Y','Y','N','Y','Y','N',NULL,'Y','Y','Y','Y','N','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','1',NULL,'N','N','N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,'Y','N'); 
INSERT INTO `tbl_staffmaster` VALUES ('4','steward1','','Male','7','1',NULL,'Explore','',NULL,'','','','Active','','','','1','Y','N',NULL,'B','N','N','N','N','N','Y','N','Y',NULL,'1111','N','N','N','N','N','Y','N','Y','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','1',NULL,'N','N','N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,'Y','N'); 
INSERT INTO `tbl_staffmaster` VALUES ('5','Store Manager','','Male','5','1',NULL,'Explore','',NULL,'','','','Active','','','','1','Y','N',NULL,'B','N','N','N','N','N','Y','N','Y',NULL,'2222','N','N','N','N','N','Y','N','Y','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','1',NULL,'N','N','N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,'Y','N'); 
INSERT INTO `tbl_staffmaster` VALUES ('6','Delivery Boy','','Male','6','1',NULL,'Explore','',NULL,'','','','Active','','','','1','Y','N',NULL,'B','N','N','N','N','N','Y','N','Y',NULL,'3333','N','N','N','N','N','Y','N','Y','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','1',NULL,'N','N','N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,'Y','N'); 
INSERT INTO `tbl_staffmaster` VALUES ('7','Accountant','','Male','12','1',NULL,'Explore','',NULL,'','','','Active','','','','1','Y','N',NULL,'B','N','N','N','N','N','Y','N','Y',NULL,'4444','N','N','N','N','N','Y','N','Y','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N',NULL,'N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','1',NULL,'N','N','N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,'Y','N'); 


DROP TABLE IF EXISTS `tbl_staffmaster_logs`;
CREATE TABLE `tbl_staffmaster_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_state`;
CREATE TABLE `tbl_state` (
  `se_stateid` bigint(20) NOT NULL,
  `se_statename` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `se_countryid` smallint(6) NOT NULL,
  PRIMARY KEY (`se_stateid`),
  UNIQUE KEY `se_statename` (`se_statename`),
  KEY `se_countryid` (`se_countryid`),
  KEY `se_countryid_2` (`se_countryid`),
  CONSTRAINT `fk_state_countyid` FOREIGN KEY (`se_countryid`) REFERENCES `tbl_country` (`cy_countyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_stock_details`;
CREATE TABLE `tbl_stock_details` (
  `sd_id` int(11) NOT NULL AUTO_INCREMENT,
  `sd_date` date DEFAULT NULL,
  `sd_opening_stock` decimal(15,3) DEFAULT NULL,
  `sd_stock_value` decimal(15,3) DEFAULT NULL,
  `sd_stock_transfer` decimal(15,3) DEFAULT NULL,
  `sd_stock_purchase` decimal(15,3) DEFAULT NULL,
  `sd_closing_stock` decimal(15,3) DEFAULT NULL,
  `sd_store_id` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`sd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_store_stock`;
CREATE TABLE `tbl_store_stock` (
  `ts_id` int(11) NOT NULL AUTO_INCREMENT,
  `ts_store` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_product` int(11) DEFAULT NULL,
  `ts_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_qty` decimal(15,3) DEFAULT NULL,
  `ts_weight` decimal(15,3) DEFAULT NULL,
  `ts_unit` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_average` decimal(15,3) DEFAULT NULL,
  `ts_unit_price` decimal(15,3) NOT NULL DEFAULT '0.000',
  `ts_total` decimal(15,3) DEFAULT NULL,
  `ts_reorder` decimal(15,3) DEFAULT NULL,
  `ts_expiry` date DEFAULT NULL,
  `ts_last_grn` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_stock_update_date` date DEFAULT NULL,
  `ts_updating` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `ts_tax` decimal(15,3) DEFAULT NULL,
  `ts_tx_amount` decimal(15,3) DEFAULT NULL,
  `ts_last_qty_on_1st` decimal(15,3) DEFAULT '0.000',
  `ts_last_weight_on_1st` decimal(15,3) DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ts_id`),
  UNIQUE KEY `ts_store` (`ts_store`,`ts_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_store_transfer`;
CREATE TABLE `tbl_store_transfer` (
  `tt_id` int(11) NOT NULL AUTO_INCREMENT,
  `tt_trn_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_product` int(11) DEFAULT NULL,
  `tt_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_qty` int(11) DEFAULT NULL,
  `tt_weight` decimal(15,3) DEFAULT '0.000',
  `tt_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tt_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_unit_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_total` decimal(15,3) DEFAULT '0.000',
  `tt_reorder` decimal(15,3) DEFAULT '0.000',
  `tt_current_stock` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tt_from_store` int(11) DEFAULT NULL,
  `tt_to_store` int(11) DEFAULT NULL,
  `tt_transfer_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_transfer_date` datetime DEFAULT NULL,
  `tt_dayclosedate` date DEFAULT NULL,
  `tt_set` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tt_tax` decimal(15,3) DEFAULT NULL,
  `tt_tax_value` decimal(15,3) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tt_indent` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_transfer_from_central` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tt_indent_accepted` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tt_indent_accepted_time` datetime DEFAULT NULL,
  `tt_indent_accepted_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_direct_grn` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_normal` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tt_normal_accept` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tt_normal_accept_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_normal_accept_time` datetime DEFAULT NULL,
  `tt_direct_accept` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tt_direct_accept_by` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_batch_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_supplier_voucher`;
CREATE TABLE `tbl_supplier_voucher` (
  `sv_id` int(11) NOT NULL AUTO_INCREMENT,
  `sv_vendor_id` int(11) NOT NULL,
  `sv_date` date DEFAULT NULL,
  `sv_address` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_invoice_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_invoice_amount` decimal(15,3) DEFAULT NULL,
  `sv_from` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_paid_amount` decimal(15,3) DEFAULT NULL,
  `sv_credit_amount` decimal(15,3) DEFAULT NULL,
  `sv_entry_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_trn_detail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_remarks` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_entry_date` date DEFAULT NULL,
  `sv_type_pay` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_discount` decimal(15,3) DEFAULT NULL,
  `sv_pr_return` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sv_purchase_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_return_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sv_paid_fully` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_tax` decimal(15,3) DEFAULT '0.000',
  `sv_subtotal` decimal(15,3) NOT NULL DEFAULT '0.000',
  `sv_entry_time` datetime DEFAULT NULL,
  `sv_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sv_from_inventory` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sv_cloud_added` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sv_cloud_edited` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`sv_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_sync_log`;
CREATE TABLE `tbl_sync_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_datetime` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sync_remarks` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_table_cloud`;
CREATE TABLE `tbl_table_cloud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` text COLLATE utf8_unicode_ci NOT NULL,
  `columns` text COLLATE utf8_unicode_ci,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_tablebill_extra_tax_details`;
CREATE TABLE `tbl_tablebill_extra_tax_details` (
  `bet_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bet_billslno` smallint(6) NOT NULL,
  `bet_tax_id` int(11) NOT NULL,
  `bet_menuid` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bet_tax_value` decimal(8,3) NOT NULL DEFAULT '0.000',
  `bet_tax_amount` decimal(15,3) DEFAULT '0.000',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bet_dayclose` date DEFAULT NULL,
  PRIMARY KEY (`bet_billno`,`bet_billslno`,`bet_tax_id`),
  KEY `fk_tbil_ex_tax_det_taxid` (`bet_tax_id`),
  KEY `bill` (`bet_billno`),
  CONSTRAINT `fk_tbil_ex_tax_det_billno` FOREIGN KEY (`bet_billno`, `bet_billslno`) REFERENCES `tbl_tablebilldetails` (`bd_billno`, `bd_billslno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbil_ex_tax_det_taxid` FOREIGN KEY (`bet_tax_id`) REFERENCES `tbl_extra_tax_master` (`amc_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tablebill_extra_tax_master`;
CREATE TABLE `tbl_tablebill_extra_tax_master` (
  `bem_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bem_taxid` int(11) NOT NULL,
  `bem_total_value` decimal(15,2) NOT NULL,
  `bem_label` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bem_dayclose` date DEFAULT NULL,
  PRIMARY KEY (`bem_billno`,`bem_taxid`),
  KEY `fk_tbil_ex_tax_master_taxid` (`bem_taxid`),
  KEY `bill` (`bem_billno`),
  CONSTRAINT `fk_tbil_ex_tax_master_bill` FOREIGN KEY (`bem_billno`) REFERENCES `tbl_tablebillmaster` (`bm_billno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbil_ex_tax_master_taxid` FOREIGN KEY (`bem_taxid`) REFERENCES `tbl_extra_tax_master` (`amc_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tablebill_item_discount`;
CREATE TABLE `tbl_tablebill_item_discount` (
  `bd_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bd_billslno` smallint(6) NOT NULL,
  `bd_discount_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `bd_menuid` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bd_discount_of` decimal(8,3) NOT NULL,
  `bd_mode` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `bd_discount_remarks` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `bd_discount` decimal(15,3) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bd_billno`,`bd_billslno`,`bd_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_tablebill_paymentchange`;
CREATE TABLE `tbl_tablebill_paymentchange` (
  `bcp_old_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bcp_old_branchid` bigint(20) NOT NULL DEFAULT '0',
  `bcp_old_billno_slno` int(11) NOT NULL DEFAULT '0',
  `bcp_old_paymode` int(11) DEFAULT NULL,
  `bcp_old_credit` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_old_creditmasterid` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_old_complimentary` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_old_complimentaryremark` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_old_amountbalace` decimal(15,2) DEFAULT NULL,
  `bcp_old_transactionamount` decimal(15,2) DEFAULT NULL,
  `bcp_old_amountpaid` decimal(15,2) DEFAULT NULL,
  `bcp_old_transcbank` int(11) DEFAULT NULL,
  `bcp_old_voucherid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_old_couponcompany` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_old_couponamt` decimal(15,2) DEFAULT NULL,
  `bcp_old_chequeno` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_old_chequebankname` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_old_chequebankamount` decimal(15,2) DEFAULT NULL,
  `bcp_cancelledby_careof` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_cancelledreason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_cancelledsecret` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bcp_entrydate` datetime DEFAULT NULL,
  `bcp_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bcp_old_billno`,`bcp_old_branchid`,`bcp_old_billno_slno`),
  KEY `bcp_cancelledby_careof` (`bcp_cancelledby_careof`),
  KEY `bcp_cancelledlogin` (`bcp_cancelledlogin`),
  KEY `bcp_old_couponcompany` (`bcp_old_couponcompany`),
  KEY `bcp_old_creditmasterid` (`bcp_old_creditmasterid`),
  KEY `bcp_old_paymode` (`bcp_old_paymode`),
  KEY `bcp_old_transcbank` (`bcp_old_transcbank`),
  KEY `bcp_old_voucherid` (`bcp_old_voucherid`),
  KEY `fk_paymentchange_branchid` (`bcp_old_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tablebill_split`;
CREATE TABLE `tbl_tablebill_split` (
  `tbs_orderno` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `tbs_newbillno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tbs_billtotal` decimal(15,3) NOT NULL,
  `tbs_modifieddate` datetime NOT NULL,
  `tbs_billstatus` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tbs_orderno`,`tbs_newbillno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tablebilldetails`;
CREATE TABLE `tbl_tablebilldetails` (
  `bd_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bd_billslno` smallint(6) NOT NULL,
  `bd_bill_addon_slno` int(11) DEFAULT NULL,
  `bd_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `bd_rate_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `bd_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bd_portion` int(11) DEFAULT NULL,
  `bd_unit_weight` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bd_unit_id` int(11) DEFAULT NULL,
  `bd_base_unit_id` int(11) DEFAULT NULL,
  `bd_base_rate` decimal(15,3) DEFAULT '0.000',
  `bd_org_rate` decimal(15,3) DEFAULT '0.000',
  `bd_discount` decimal(15,3) DEFAULT '0.000',
  `bd_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bd_qty` int(11) NOT NULL,
  `bd_amount` decimal(15,3) DEFAULT '0.000',
  `bd_tax_total` decimal(15,3) DEFAULT '0.000',
  `bd_taxable_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bd_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `bd_printbill` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bd_cancelled` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bd_cancelledby_careof` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bd_cancelledreason` text COLLATE utf8_unicode_ci,
  `bd_cancelledtime` datetime DEFAULT NULL,
  `bd_cancelledsecret` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bd_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bd_complementary_staff` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bd_symbol_for_tax` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bd_count_combo_ordering` int(11) DEFAULT NULL,
  `bd_new_rate_incl` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bd_exempt_disc` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bd_cost` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bd_staff_store` int(11) DEFAULT NULL,
  `bd_dayclose_in` date DEFAULT NULL,
  PRIMARY KEY (`bd_billno`,`bd_billslno`),
  KEY `bd_cancelledby_careof` (`bd_cancelledby_careof`),
  KEY `bd_cancelledlogin` (`bd_cancelledlogin`),
  KEY `bd_menuid` (`bd_menuid`),
  KEY `bd_portion` (`bd_portion`),
  KEY `bm_bill` (`bd_billno`),
  CONSTRAINT `fk_billdetails_billid` FOREIGN KEY (`bd_billno`) REFERENCES `tbl_tablebillmaster` (`bm_billno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_billdetails_canclledstaff` FOREIGN KEY (`bd_cancelledby_careof`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_billdetails_loginid` FOREIGN KEY (`bd_cancelledlogin`) REFERENCES `tbl_logindetails` (`ls_username`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_billdetails_menuid` FOREIGN KEY (`bd_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_billdetails_portionid` FOREIGN KEY (`bd_portion`) REFERENCES `tbl_portionmaster` (`pm_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tablebillmaster`;
CREATE TABLE `tbl_tablebillmaster` (
  `bm_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bm_billdate` date NOT NULL,
  `bm_billtime` time NOT NULL,
  `bm_branchid` bigint(20) NOT NULL,
  `bm_orderno` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_totalpax` int(11) DEFAULT NULL,
  `bm_floorid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_subtotal` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bm_subtotal_final` decimal(15,3) DEFAULT '0.000',
  `bm_discountid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_discountvalue` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bm_tax_exempt` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bm_taxable_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bm_total` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bm_roundoff_value` decimal(15,3) DEFAULT '0.000',
  `bm_redeem_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bm_finaltotal` decimal(15,3) DEFAULT '0.000',
  `bm_corporatecode` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_paymode` int(11) DEFAULT NULL,
  `bm_credit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bm_room_credit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bm_creditmasterid` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_complimentary` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bm_complimentaryremark` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_amountbalace` decimal(15,3) DEFAULT '0.000',
  `bm_transactionamount` decimal(15,3) DEFAULT '0.000',
  `bm_amountpaid` decimal(15,3) DEFAULT '0.000',
  `bm_upi_amount` decimal(15,3) DEFAULT '0.000',
  `bm_upi_txn_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_transcbank` int(11) DEFAULT NULL,
  `bm_voucherid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_couponcompany` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_couponamt` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bm_chequeno` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_chequebankname` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_chequebankamount` decimal(15,3) DEFAULT '0.000',
  `bm_dayclosedate` date NOT NULL,
  `bm_billprinted` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bm_lastprintime` datetime DEFAULT NULL,
  `bm_status` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Billed',
  `bm_tableno` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_discountlabel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_bill_is_split` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `bm_bill_no_of_split` int(11) NOT NULL DEFAULT '0',
  `bm_compl_mgmt_staff` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_can_regenerate` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ter_cancelledby_careof` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_cancelledreason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_cancelledsecretkey` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_cancelled_date_time` datetime DEFAULT NULL,
  `bm_bill_ref` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_settlement_login` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_comments` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_steward` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_creditremark` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_cname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_cnumber` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_gst` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_upi_requestid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_qrcode_mode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_settlement_time` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bm_bill_printed_by` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_tips_given` decimal(15,3) NOT NULL DEFAULT '0.000',
  `bm_tips_mode` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'C',
  `bm_feedback_customer` int(11) DEFAULT NULL,
  `bm_loy_id` int(11) DEFAULT NULL,
  `bm_lukado_response` varchar(2500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_lukado_pay_response` varchar(2500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_qr_orderno` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_customer_display_status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`bm_billno`),
  UNIQUE KEY `bm_corporatecode` (`bm_corporatecode`),
  UNIQUE KEY `bm_voucherid` (`bm_voucherid`),
  KEY `bm_branchid` (`bm_branchid`),
  KEY `bm_compl_mgmt_staff` (`bm_compl_mgmt_staff`),
  KEY `bm_creditmasterid` (`bm_creditmasterid`),
  KEY `bm_discountid` (`bm_discountid`),
  KEY `bm_floorid` (`bm_floorid`),
  KEY `bm_paymode` (`bm_paymode`),
  KEY `bm_voucherid_2` (`bm_voucherid`),
  KEY `ter_cancelledby_careof` (`ter_cancelledby_careof`),
  KEY `ter_cancelledlogin` (`ter_cancelledlogin`),
  KEY `bm_dayclosedate` (`bm_dayclosedate`),
  CONSTRAINT `fk_billmaster_branchid` FOREIGN KEY (`bm_branchid`) REFERENCES `tbl_branchmaster` (`be_branchid`),
  CONSTRAINT `fk_billmaster_corpdisccode` FOREIGN KEY (`bm_corporatecode`) REFERENCES `tbl_corporatemaster` (`ct_corporatecode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_billmaster_discountid` FOREIGN KEY (`bm_discountid`) REFERENCES `tbl_discountmaster` (`ds_discountid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_billmaster_floorid` FOREIGN KEY (`bm_floorid`) REFERENCES `tbl_floormaster` (`fr_floorid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_billmaster_paymodeid` FOREIGN KEY (`bm_paymode`) REFERENCES `tbl_paymentmode` (`pym_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_billmaster_staffid` FOREIGN KEY (`ter_cancelledby_careof`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_billmaster_username` FOREIGN KEY (`ter_cancelledlogin`) REFERENCES `tbl_logindetails` (`ls_username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tabledetails`;
CREATE TABLE `tbl_tabledetails` (
  `ts_tableid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ts_tableidprefix` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `ts_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Vacant',
  `ts_dineintime` time DEFAULT NULL,
  `ts_noofpersons` tinyint(4) DEFAULT NULL,
  `ts_orderno` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_floorid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_orderstaff` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_reservetime` time DEFAULT NULL,
  `ts_totalamount` float NOT NULL DEFAULT '0',
  `ts_entrydate` datetime NOT NULL,
  `ts_interface` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `ts_billnumber` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_paxcount` int(11) DEFAULT NULL,
  `ts_username` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_in_access` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `ts_completed_order` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ts_machineid` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ts_tableid`,`ts_tableidprefix`),
  KEY `ts_floorid` (`ts_floorid`),
  KEY `ts_orderno` (`ts_orderno`),
  KEY `ts_orderstaff` (`ts_orderstaff`),
  KEY `ts_username` (`ts_username`),
  CONSTRAINT `fk_tablemaster_floor` FOREIGN KEY (`ts_floorid`) REFERENCES `tbl_floormaster` (`fr_floorid`),
  CONSTRAINT `fk_tablemaster_staffid` FOREIGN KEY (`ts_orderstaff`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_tablemaster_tableid` FOREIGN KEY (`ts_tableid`) REFERENCES `tbl_tablemaster` (`tr_tableid`),
  CONSTRAINT `fk_tablemaster_username` FOREIGN KEY (`ts_username`) REFERENCES `tbl_logindetails` (`ls_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tableinsertion`;
CREATE TABLE `tbl_tableinsertion` (
  `ts_id` int(11) NOT NULL AUTO_INCREMENT,
  `ts_tableid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ts_tableidprefix` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `ts_noofpersons` tinyint(4) NOT NULL,
  `ts_orderno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_tablemaster`;
CREATE TABLE `tbl_tablemaster` (
  `tr_tableid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tr_branchid` bigint(20) NOT NULL,
  `tr_floorid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tr_tableno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tr_status` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `tr_maxchaircount` int(11) NOT NULL,
  `tr_vaccantcount` int(11) NOT NULL DEFAULT '0',
  `tr_nextprefix_ascii` int(11) NOT NULL DEFAULT '65',
  `tr_displayorder` int(11) NOT NULL,
  `tr_max_ascii` int(11) NOT NULL,
  `tr_timealloted` int(3) DEFAULT '0',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tr_tableid`),
  KEY `tr_branchid` (`tr_branchid`),
  KEY `tr_floor` (`tr_floorid`),
  KEY `tr_floorid` (`tr_floorid`),
  CONSTRAINT `fk_tablemaster_branchid` FOREIGN KEY (`tr_branchid`) REFERENCES `tbl_branchmaster` (`be_branchid`),
  CONSTRAINT `fk_tablemaster_floorid` FOREIGN KEY (`tr_floorid`) REFERENCES `tbl_floormaster` (`fr_floorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_tablemaster` VALUES ('1','1','1','1','Active','4','4','65','1','69','0','N'),
('2','1','1','2','Active','4','4','65','2','69','0','N'),
('3','1','1','3','Active','4','4','65','3','69','0','N'),
('4','1','1','4','Active','4','4','65','4','69','0','N'),
('5','1','1','6','Active','6','6','65','6','71','0','N'); 
INSERT INTO `tbl_tablemaster` VALUES ('6','1','1','5','Active','4','4','65','5','69','0','N'),
('7','1','1','7','Active','6','6','65','7','71','0','N'),
('8','1','1','8','Active','4','4','65','8','69','0','N'); 


DROP TABLE IF EXISTS `tbl_tableorder`;
CREATE TABLE `tbl_tableorder` (
  `ter_orderno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `ter_slno` int(11) NOT NULL,
  `ter_branchid` bigint(20) NOT NULL,
  `ter_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ter_rate_type` varchar(30) COLLATE utf8_unicode_ci DEFAULT 'Portion',
  `ter_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_portion` int(11) DEFAULT NULL,
  `ter_unit_weight` decimal(15,5) DEFAULT '0.00000',
  `ter_unit_id` int(11) DEFAULT NULL,
  `ter_base_unit_id` int(11) DEFAULT NULL,
  `ter_base_rate` decimal(15,3) DEFAULT NULL,
  `ter_org_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `ter_discount` decimal(15,3) DEFAULT '0.000',
  `ter_rate` decimal(15,3) DEFAULT '0.000',
  `ter_qty` int(11) NOT NULL,
  `ter_total_rate` decimal(15,3) DEFAULT '0.000',
  `ter_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ter_preference` int(11) DEFAULT NULL,
  `ter_preferencetext` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_orderfrom` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ter_entrydate` date NOT NULL,
  `ter_entrytime` time NOT NULL,
  `ter_entryuser` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `ter_esttime` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_staff` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ter_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ter_kotno` varchar(20) COLLATE utf8_unicode_ci DEFAULT '0',
  `ter_billnumber` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_feedbackrating` decimal(2,1) NOT NULL DEFAULT '0.0',
  `ter_feedbackremarks` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_feedbackenter` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ter_dayclosedate` date NOT NULL,
  `ter_floorid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_cancel` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `ter_cancelledby_careof` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_cancelledreason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_cancelledsecretkey` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_orderno_temp` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_waiter_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_kot_canceltime` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ter_combo_entry_id` int(11) DEFAULT NULL,
  `ter_count_combo_ordering` int(11) DEFAULT NULL,
  `ter_addon_slno` int(11) DEFAULT NULL,
  `ter_new_rate_incl` decimal(15,3) NOT NULL DEFAULT '0.000',
  `ter_kot_printed` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ter_cons_printed` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ter_rate_before_comp` decimal(15,3) NOT NULL DEFAULT '0.000',
  `ter_item_disc_manual` decimal(15,3) NOT NULL DEFAULT '0.000',
  `ter_disc_type` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_disc_before` decimal(15,3) NOT NULL DEFAULT '0.000',
  `ter_qr_order` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ter_dynamic_rate` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ter_orderno`,`ter_slno`),
  KEY `fk_orderdetails_waitername` (`ter_waiter_id`),
  KEY `os_branchid` (`ter_branchid`),
  KEY `os_entryuser` (`ter_entryuser`),
  KEY `os_menuid` (`ter_menuid`),
  KEY `ter_preference` (`ter_preference`),
  KEY `ter_staff` (`ter_staff`),
  KEY `ter_dayclosedate` (`ter_dayclosedate`,`ter_orderno`) USING BTREE,
  CONSTRAINT `fk_orderdetails_branchid` FOREIGN KEY (`ter_branchid`) REFERENCES `tbl_branchmaster` (`be_branchid`),
  CONSTRAINT `fk_orderdetails_menuid` FOREIGN KEY (`ter_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_orderdetails_preferenceid` FOREIGN KEY (`ter_preference`) REFERENCES `tbl_preferencemaster` (`pmr_id`),
  CONSTRAINT `fk_orderdetails_staffid` FOREIGN KEY (`ter_staff`) REFERENCES `tbl_staffmaster` (`ser_staffid`),
  CONSTRAINT `fk_orderdetails_username` FOREIGN KEY (`ter_entryuser`) REFERENCES `tbl_logindetails` (`ls_username`),
  CONSTRAINT `fk_tableorder_waiterid` FOREIGN KEY (`ter_waiter_id`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tableorder_changes`;
CREATE TABLE `tbl_tableorder_changes` (
  `ch_kot_cancel_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ch_orderno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `ch_orderslno` int(11) NOT NULL,
  `ch_slno` int(11) NOT NULL,
  `ch_cancelled_qty` int(11) NOT NULL,
  `ch_cancelledby_careof` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ch_entrydate` datetime NOT NULL,
  `ch_kotno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ch_cancelledreason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ch_cancelledsecret` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `ch_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `ch_dayclosedate` date DEFAULT NULL,
  `sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ch_sms` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ch_email` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `ch_sms_time` datetime DEFAULT NULL,
  `ch_email_time` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ch_combo_pack_cancelled_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`ch_kot_cancel_id`,`ch_orderno`,`ch_orderslno`,`ch_slno`),
  KEY `ch_cancelledby_careof` (`ch_cancelledby_careof`),
  KEY `ch_cancelledlogin` (`ch_cancelledlogin`),
  CONSTRAINT `fk_tableorder_changes_loginid` FOREIGN KEY (`ch_cancelledlogin`) REFERENCES `tbl_logindetails` (`ls_username`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tableorder_changes_staffid` FOREIGN KEY (`ch_cancelledby_careof`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_tableorder_discount`;
CREATE TABLE `tbl_tableorder_discount` (
  `d_orderno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `d_slno` int(11) NOT NULL,
  `d_discount_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `d_discount_of` decimal(8,3) DEFAULT NULL,
  `d_mode` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `d_discount_remarks` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `d_discount` decimal(15,3) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`d_orderno`,`d_slno`,`d_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_takeaway_bill_extra_tax_details`;
CREATE TABLE `tbl_takeaway_bill_extra_tax_details` (
  `tbet_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tbet_slno` int(11) NOT NULL,
  `tbet_tax_id` int(11) NOT NULL,
  `tbet_menuid` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tbet_tax_value` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tbet_tax_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tbet_daycolse` date DEFAULT NULL,
  PRIMARY KEY (`tbet_billno`,`tbet_slno`,`tbet_tax_id`),
  KEY `fk_ta_bil_ex_tax_det_taxid` (`tbet_tax_id`),
  KEY `bill` (`tbet_billno`),
  CONSTRAINT `fk_ta_bil_ex_tax_det_billno` FOREIGN KEY (`tbet_billno`, `tbet_slno`) REFERENCES `tbl_takeaway_billdetails` (`tab_billno`, `tab_slno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ta_bil_ex_tax_det_taxid` FOREIGN KEY (`tbet_tax_id`) REFERENCES `tbl_extra_tax_master` (`amc_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_takeaway_bill_extra_tax_master`;
CREATE TABLE `tbl_takeaway_bill_extra_tax_master` (
  `tbe_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tbe_taxid` int(11) NOT NULL,
  `tbe_total_value` decimal(15,2) NOT NULL DEFAULT '0.00',
  `tbe_label` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tbe_dayclose` date DEFAULT NULL,
  PRIMARY KEY (`tbe_billno`,`tbe_taxid`),
  KEY `fk_ta_bil_ex_tax_master_taxid` (`tbe_taxid`),
  KEY `bill` (`tbe_billno`),
  CONSTRAINT `fk_ta_bil_ex_tax_master_billno` FOREIGN KEY (`tbe_billno`) REFERENCES `tbl_takeaway_billmaster` (`tab_billno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ta_bil_ex_tax_master_taxid` FOREIGN KEY (`tbe_taxid`) REFERENCES `tbl_extra_tax_master` (`amc_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_takeaway_billdetails`;
CREATE TABLE `tbl_takeaway_billdetails` (
  `tab_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tab_slno` int(11) NOT NULL,
  `tab_bill_addon_slno` int(11) DEFAULT NULL,
  `tab_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `tab_rate_type` varchar(30) COLLATE utf8_unicode_ci DEFAULT 'Portion',
  `tab_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_portion` int(11) DEFAULT NULL,
  `tab_unit_weight` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_unit_id` int(11) DEFAULT NULL,
  `tab_base_unit_id` int(11) DEFAULT NULL,
  `tab_base_rate` decimal(15,3) DEFAULT '0.000',
  `tab_qty` int(11) NOT NULL,
  `tab_preferencetext` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_org_rate` decimal(15,3) DEFAULT '0.000',
  `tab_discount` decimal(15,3) DEFAULT '0.000',
  `tab_rate` decimal(15,3) NOT NULL,
  `tab_amount` decimal(15,3) NOT NULL,
  `tab_status` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_modifieduser` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_packedtime` datetime DEFAULT NULL,
  `tab_cancelled` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_cancelledtime` datetime DEFAULT NULL,
  `tab_cancelledby_careof` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelledreason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelledsecretkey` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_entrytime` datetime DEFAULT NULL,
  `tab_symbol_for_tax` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_count_combo_ordering` int(11) DEFAULT NULL,
  `tab_food_partner_id` int(11) DEFAULT NULL,
  `tab_regen_status_menu` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_kotno_new` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_urban_order_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_qr_order_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_new_rate_incl` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_kot_printed` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_cons_printed` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_rate_before_comp` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_dayclose_in` date DEFAULT NULL,
  `tab_exempt_disc` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_cost` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_item_disc_manual` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_disc_type` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_disc_before` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_staff_store` int(11) DEFAULT NULL,
  `tab_addon_in` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_dynamic_rate` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tab_billno`,`tab_slno`),
  KEY `tab_menuid` (`tab_menuid`),
  KEY `tab_portion` (`tab_portion`),
  KEY `bill` (`tab_billno`),
  CONSTRAINT `fk_takeawaydetails_billno` FOREIGN KEY (`tab_billno`) REFERENCES `tbl_takeaway_billmaster` (`tab_billno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_takeawaydetails_menuid` FOREIGN KEY (`tab_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_takeawaydetails_portionid` FOREIGN KEY (`tab_portion`) REFERENCES `tbl_portionmaster` (`pm_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_takeaway_billmaster`;
CREATE TABLE `tbl_takeaway_billmaster` (
  `tab_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tab_date` date NOT NULL,
  `tab_time` time NOT NULL,
  `tab_branchid` int(11) NOT NULL,
  `tab_mode_of_entry` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_subtotal` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_subtotal_final` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_tax_exempt` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_taxable_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_total` decimal(15,3) DEFAULT '0.000',
  `tab_roundoff_value` decimal(10,3) NOT NULL DEFAULT '0.000',
  `tab_redeem_amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_netamt` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_payment_settled` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_kotno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_loginid` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_hd` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tab_hdcustomerid` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_status` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_assignedto` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_delivery_status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_esttime` datetime DEFAULT NULL,
  `tab_assignedtime` datetime DEFAULT NULL,
  `tab_paymode` int(11) DEFAULT NULL,
  `tab_cancelamount` decimal(15,3) DEFAULT '0.000',
  `tab_discountid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_discount_mode` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_discount_of` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_corporatecode` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_discountvalue` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_discount_label` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_complimentary` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tab_complimentaryremark` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_amountpaid` decimal(15,3) DEFAULT '0.000',
  `tab_upi_amount` decimal(15,3) DEFAULT '0.000',
  `tab_upi_txn_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_amountbalace` decimal(15,3) DEFAULT '0.000',
  `tab_transcbank` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_transactionamount` decimal(15,3) DEFAULT '0.000',
  `tab_voucherid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_couponcompany` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_couponamt` decimal(15,3) DEFAULT '0.000',
  `tab_chequeno` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_chequebankname` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_chequebankamount` decimal(15,3) DEFAULT '0.000',
  `tab_dayclosedate` date NOT NULL,
  `tbl_takeaway_printed` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tbl_takeaway_print_time` datetime DEFAULT NULL,
  `tab_mode` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `tab_credit` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_room_credit` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_creditmasterid` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelledby_careof` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelledreason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelledsecretkey` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelled` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_cancelledtime` datetime DEFAULT NULL,
  `tab_on_hold` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_bill_ref` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_msg_customerstatus` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_msg_staffstatus` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_bill_gen_login` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_settlement_login` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_comments` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_sms_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_email_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_sms_time` datetime DEFAULT NULL,
  `tab_email_time` datetime DEFAULT NULL,
  `tab_creditremark` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_gst` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_upi_requestid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_qrcode_mode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_settlement_time` datetime DEFAULT NULL,
  `tab_bill_print` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_bill_reorder` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_table_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_no_pax` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_c_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_c_no` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_c_veh_no` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_bill_printed_by` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_tips_given` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_tips_mode` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'C',
  `tab_delivery_charge` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_food_partner` int(11) DEFAULT NULL,
  `tab_food_partner_discount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_food_partner_total` decimal(15,3) DEFAULT '0.000',
  `tab_regen_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_urban_order_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_urban_partner` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_urban_partner_order_no` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_qr_order_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_qr_order_time` datetime DEFAULT NULL,
  `tab_qr_delivery_charge` decimal(15,3) DEFAULT NULL,
  `tab_loy_id` int(11) DEFAULT NULL,
  `tab_lukado_response` varchar(2500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_lukado_pay_response` varchar(2500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_system_ip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_ref_no_new` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_customer_display_status` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_phone_order` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_adv_orderno` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tab_billno`),
  KEY `tab_assignedto` (`tab_assignedto`),
  KEY `tab_dayclosedate` (`tab_dayclosedate`),
  CONSTRAINT `fk_takeaway_billmaster_staffid` FOREIGN KEY (`tab_assignedto`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_takeaway_cancel_items`;
CREATE TABLE `tbl_takeaway_cancel_items` (
  `tc_cancel_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `tc_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tc_bill_slno` int(11) NOT NULL,
  `tc_slno` int(11) NOT NULL,
  `tc_cancel_qty` int(11) DEFAULT NULL,
  `tc_cancelled_by` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_cancelled_login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_cancelled_time` datetime DEFAULT NULL,
  `tc_reason` int(11) DEFAULT NULL,
  `tc_cancel_kotno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tc_dayclosedate` date DEFAULT NULL,
  `tc_mode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tc_combo_pack_cancelled_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`tc_cancel_id`,`tc_billno`,`tc_bill_slno`,`tc_slno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_takeaway_customer`;
CREATE TABLE `tbl_takeaway_customer` (
  `tac_customerid` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tac_customername` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tac_contactno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tac_address` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tac_landmark` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tac_area` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tac_remarks` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `tac_branchid` bigint(20) DEFAULT NULL,
  `tac_per_address` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tac_takeaway_count` int(11) NOT NULL DEFAULT '1',
  `tac_homedelivery_count` int(11) NOT NULL DEFAULT '1',
  `tac_entrydate` datetime NOT NULL,
  `tac_gst` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tac_def` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tac_del_boy` int(11) DEFAULT NULL,
  `tac_ref_data` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tac_phone_order` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`tac_customerid`),
  UNIQUE KEY `tac_contactno` (`tac_contactno`),
  KEY `tac_branchid` (`tac_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_takeaway_item_discount`;
CREATE TABLE `tbl_takeaway_item_discount` (
  `tbd_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tbd_slno` smallint(6) NOT NULL,
  `tbd_discount_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tbd_discount_of` decimal(8,3) NOT NULL,
  `tbd_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `tbd_mode` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `tbd_discount_remarks` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `tbd_discount` decimal(15,3) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tbd_billno`,`tbd_slno`,`tbd_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_temp_orderno_details`;
CREATE TABLE `tbl_temp_orderno_details` (
  `to_temp_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `to_temp_createdtime` datetime NOT NULL,
  `to_orderno` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_orderno_createdtime` datetime DEFAULT NULL,
  `to_created_interface` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`to_temp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_temp_regenerate`;
CREATE TABLE `tbl_temp_regenerate` (
  `bill_no` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `order_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bill_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_temp_tablebilldetails`;
CREATE TABLE `tbl_temp_tablebilldetails` (
  `bd_temp_billno` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `bd_billslno` smallint(6) NOT NULL,
  `bd_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `bd_portion` int(11) NOT NULL,
  `bd_rate` float NOT NULL DEFAULT '0',
  `bd_qty` int(11) NOT NULL,
  `bd_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `bd_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bd_temp_billno`,`bd_billslno`),
  KEY `bd_menuid` (`bd_menuid`),
  KEY `bd_portion` (`bd_portion`),
  CONSTRAINT `fk_temp_billdetails_billid` FOREIGN KEY (`bd_temp_billno`) REFERENCES `tbl_temp_tablebillmaster` (`bm_temp_billno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_temp_billdetails_menuid` FOREIGN KEY (`bd_menuid`) REFERENCES `tbl_menumaster` (`mr_menuid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_temp_billdetails_portionid` FOREIGN KEY (`bd_portion`) REFERENCES `tbl_portionmaster` (`pm_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_temp_tablebillmaster`;
CREATE TABLE `tbl_temp_tablebillmaster` (
  `bm_temp_billno` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `bm_main_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bm_branchid` bigint(20) NOT NULL,
  `bm_floorid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_subtotal` decimal(15,2) NOT NULL DEFAULT '0.00',
  `bm_dayclosedate` date NOT NULL,
  `bm_tableno` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`bm_temp_billno`),
  KEY `bm_branchid` (`bm_branchid`),
  CONSTRAINT `fk_temp_billmaster_branchid` FOREIGN KEY (`bm_branchid`) REFERENCES `tbl_branchmaster` (`be_branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_timely_sms_entry`;
CREATE TABLE `tbl_timely_sms_entry` (
  `tml_id` int(11) NOT NULL AUTO_INCREMENT,
  `tml_time` time DEFAULT NULL,
  `tml_hour` decimal(15,1) DEFAULT NULL,
  `tml_dayclose` date DEFAULT NULL,
  `tml_sms` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tml_email` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tml_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_track_l`;
CREATE TABLE `tbl_track_l` (
  `l_username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `l_secure_code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `l_logged_status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`l_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_track_l_details`;
CREATE TABLE `tbl_track_l_details` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `l_datetime` datetime NOT NULL,
  `l_amount` int(11) NOT NULL,
  `l_msg_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_unit_master`;
CREATE TABLE `tbl_unit_master` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_unit_master_combination`;
CREATE TABLE `tbl_unit_master_combination` (
  `um_first_id` int(11) NOT NULL,
  `um_second_id` int(11) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`um_first_id`,`um_second_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_unit_master_combination` VALUES ('1','1','N'),
('1','2','N'),
('2','3','N'),
('2','4','N'),
('3','5','N'); 


DROP TABLE IF EXISTS `tbl_urban_charge_tax`;
CREATE TABLE `tbl_urban_charge_tax` (
  `tcx_id` int(11) NOT NULL AUTO_INCREMENT,
  `txc_order_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcx_title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcx_value` decimal(15,3) DEFAULT NULL,
  `tcx_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tcx_date` datetime DEFAULT NULL,
  PRIMARY KEY (`tcx_id`)
) ENGINE=MyISAM AUTO_INCREMENT=607 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_urban_order_temp_bill`;
CREATE TABLE `tbl_urban_order_temp_bill` (
  `tab_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tab_status` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_dayclose` date NOT NULL,
  `tab_entry` datetime DEFAULT NULL,
  `tab_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_address` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`tab_billno`,`tab_dayclose`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_urban_order_temp_detail`;
CREATE TABLE `tbl_urban_order_temp_detail` (
  `tab_billno` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tab_slno` int(11) NOT NULL,
  `tab_menuid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `tab_rate_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Portion',
  `tab_unit_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_portion` int(11) DEFAULT NULL,
  `tab_unit_weight` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_unit_id` int(11) DEFAULT NULL,
  `tab_base_unit_id` int(11) DEFAULT NULL,
  `tab_base_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_qty` int(11) NOT NULL,
  `tab_preferencetext` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_org_rate` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_discount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `tab_rate` decimal(15,3) NOT NULL,
  `tab_amount` decimal(15,3) NOT NULL,
  `tab_status` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_packedtime` datetime DEFAULT NULL,
  `tab_cancelled` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tab_cancelledtime` datetime DEFAULT NULL,
  `tab_cancelledreason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_cancelledlogin` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_symbol_for_tax` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tab_count_combo_ordering` int(11) DEFAULT NULL,
  `tab_food_partner_id` int(11) DEFAULT NULL,
  `tab_dayclose` date DEFAULT NULL,
  UNIQUE KEY `tab_billno` (`tab_billno`,`tab_slno`,`tab_menuid`,`tab_portion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_usermodules`;
CREATE TABLE `tbl_usermodules` (
  `um_username` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `um_moduleid` int(11) NOT NULL,
  `um_submoduleid` int(11) NOT NULL DEFAULT '0',
  `um_access` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`um_username`,`um_moduleid`,`um_submoduleid`),
  KEY `fk_usermodules_moduleid` (`um_moduleid`),
  KEY `fk_usermodules_submoduleid` (`um_submoduleid`),
  CONSTRAINT `fk_usermodules_moduleid` FOREIGN KEY (`um_moduleid`) REFERENCES `tbl_modulemaster` (`mer_moduleid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_usermodules_submoduleid` FOREIGN KEY (`um_submoduleid`) REFERENCES `tbl_modulesubmaster` (`mser_submoduleid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_usermodules_username` FOREIGN KEY (`um_username`) REFERENCES `tbl_logindetails` (`ls_username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_usermodules` VALUES ('admin','1','1','Y'),
('admin','1','3','Y'),
('admin','1','11','Y'),
('admin','1','13','Y'),
('admin','1','14','Y'),
('admin','1','15','Y'),
('admin','1','16','Y'),
('admin','1','17','Y'),
('admin','1','18','Y'),
('admin','1','19','Y'),
('admin','1','20','Y'),
('admin','1','21','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','1','22','Y'),
('admin','1','23','Y'),
('admin','1','24','Y'),
('admin','1','25','Y'),
('admin','1','34','Y'),
('admin','1','35','Y'),
('admin','1','36','Y'),
('admin','1','37','Y'),
('admin','1','38','Y'),
('admin','1','39','Y'),
('admin','1','40','Y'),
('admin','1','41','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','1','42','Y'),
('admin','1','43','Y'),
('admin','1','44','Y'),
('admin','1','45','Y'),
('admin','1','46','Y'),
('admin','1','47','Y'),
('admin','1','48','Y'),
('admin','1','69','Y'),
('admin','1','71','Y'),
('admin','1','72','Y'),
('admin','1','82','Y'),
('admin','1','83','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','1','85','Y'),
('admin','1','88','Y'),
('admin','1','89','Y'),
('admin','1','90','Y'),
('admin','1','91','Y'),
('admin','1','92','Y'),
('admin','1','93','Y'),
('admin','1','95','Y'),
('admin','1','96','Y'),
('admin','1','97','Y'),
('admin','1','98','Y'),
('admin','1','99','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','1','101','Y'),
('admin','1','102','Y'),
('admin','1','107','Y'),
('admin','1','108','Y'),
('admin','1','109','Y'),
('admin','1','121','Y'),
('admin','1','122','Y'),
('admin','1','123','Y'),
('admin','1','154','Y'),
('admin','1','155','Y'),
('admin','1','189','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','1','193','Y'),
('admin','1','194','Y'),
('admin','1','195','Y'),
('admin','1','196','Y'),
('admin','1','197','Y'),
('admin','1','198','Y'),
('admin','1','199','Y'),
('admin','1','208','Y'),
('admin','1','211','Y'),
('admin','1','212','Y'),
('admin','1','221','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','1','222','Y'),
('admin','1','223','Y'),
('admin','1','233','Y'),
('admin','1','240','Y'),
('admin','1','253','Y'),
('admin','1','258','Y'),
('admin','1','259','Y'),
('admin','1','265','Y'),
('admin','2','1','Y'),
('admin','2','4','Y'),
('admin','2','5','Y'),
('admin','2','6','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','2','32','Y'),
('admin','2','49','Y'),
('admin','2','50','Y'),
('admin','2','51','Y'),
('admin','2','52','Y'),
('admin','2','53','Y'),
('admin','2','54','Y'),
('admin','2','55','Y'),
('admin','2','56','Y'),
('admin','2','57','Y'),
('admin','2','70','Y'),
('admin','2','75','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','2','76','Y'),
('admin','2','77','Y'),
('admin','2','78','Y'),
('admin','2','79','Y'),
('admin','2','80','Y'),
('admin','2','81','Y'),
('admin','2','84','Y'),
('admin','2','87','Y'),
('admin','2','94','Y'),
('admin','2','100','Y'),
('admin','2','103','Y'),
('admin','2','104','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','2','105','Y'),
('admin','2','106','Y'),
('admin','2','110','Y'),
('admin','2','111','Y'),
('admin','2','124','Y'),
('admin','2','227','Y'),
('admin','2','228','Y'),
('admin','2','229','Y'),
('admin','2','230','Y'),
('admin','2','236','Y'),
('admin','2','237','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','2','238','Y'),
('admin','2','239','Y'),
('admin','2','242','Y'),
('admin','2','243','Y'),
('admin','2','244','Y'),
('admin','2','245','Y'),
('admin','2','258','Y'),
('admin','2','259','Y'),
('admin','2','265','Y'),
('admin','3','1','Y'),
('admin','3','66','Y'),
('admin','3','67','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','3','68','Y'),
('admin','3','113','Y'),
('admin','3','128','Y'),
('admin','3','129','Y'),
('admin','3','130','Y'),
('admin','3','131','Y'),
('admin','3','203','Y'),
('admin','3','206','Y'),
('admin','6','1','Y'),
('admin','6','26','Y'),
('admin','6','27','Y'),
('admin','6','28','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','6','29','Y'),
('admin','6','30','Y'),
('admin','6','31','Y'),
('admin','6','59','Y'),
('admin','6','185','Y'),
('admin','6','188','Y'),
('admin','6','246','Y'),
('admin','8','1','Y'),
('admin','8','62','Y'),
('admin','8','63','Y'),
('admin','8','64','Y'),
('admin','9','1','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','9','7','Y'),
('admin','9','8','Y'),
('admin','9','9','Y'),
('admin','9','10','Y'),
('admin','10','1','Y'),
('admin','10','60','Y'),
('admin','10','143','Y'),
('admin','11','1','Y'),
('admin','14','1','Y'),
('admin','15','1','Y'),
('admin','15','125','Y'),
('admin','15','126','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','16','1','Y'),
('admin','16','112','Y'),
('admin','17','1','Y'),
('admin','18','1','Y'),
('admin','18','114','Y'),
('admin','18','115','Y'),
('admin','18','116','Y'),
('admin','18','117','Y'),
('admin','18','118','Y'),
('admin','18','119','Y'),
('admin','18','120','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','18','145','Y'),
('admin','18','146','Y'),
('admin','18','156','Y'),
('admin','18','157','Y'),
('admin','18','159','Y'),
('admin','18','160','Y'),
('admin','18','161','Y'),
('admin','18','166','Y'),
('admin','18','167','Y'),
('admin','18','168','Y'),
('admin','18','169','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','18','170','Y'),
('admin','18','171','Y'),
('admin','18','172','Y'),
('admin','18','173','Y'),
('admin','18','187','Y'),
('admin','18','234','Y'),
('admin','18','248','Y'),
('admin','19','1','Y'),
('admin','19','144','Y'),
('admin','20','1','Y'),
('admin','20','147','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','21','1','Y'),
('admin','23','1','Y'),
('admin','24','1','Y'),
('admin','24','148','Y'),
('admin','25','1','Y'),
('admin','25','149','Y'),
('admin','25','152','Y'),
('admin','25','153','Y'),
('admin','26','1','Y'),
('admin','27','1','Y'),
('admin','28','1','Y'),
('admin','28','150','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','29','1','Y'),
('admin','30','1','Y'),
('admin','31','1','Y'),
('admin','31','151','Y'),
('admin','32','1','Y'),
('admin','33','1','Y'),
('admin','33','158','Y'),
('admin','34','1','Y'),
('admin','35','1','Y'),
('admin','36','1','Y'),
('admin','36','162','Y'),
('admin','36','163','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','36','252','Y'),
('admin','37','1','Y'),
('admin','38','1','Y'),
('admin','38','164','Y'),
('admin','38','165','Y'),
('admin','38','174','Y'),
('admin','38','186','Y'),
('admin','38','200','Y'),
('admin','38','224','Y'),
('admin','38','235','Y'),
('admin','38','249','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','39','1','Y'),
('admin','39','175','Y'),
('admin','39','176','Y'),
('admin','39','177','Y'),
('admin','39','178','Y'),
('admin','40','1','Y'),
('admin','40','181','Y'),
('admin','40','182','Y'),
('admin','40','183','Y'),
('admin','40','184','Y'),
('admin','40','204','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','40','207','Y'),
('admin','41','1','Y'),
('admin','42','1','Y'),
('admin','42','190','Y'),
('admin','42','191','Y'),
('admin','42','192','Y'),
('admin','42','201','Y'),
('admin','42','202','Y'),
('admin','42','205','Y'),
('admin','43','1','Y'),
('admin','43','213','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','44','1','Y'),
('admin','44','214','Y'),
('admin','45','1','Y'),
('admin','46','1','Y'),
('admin','48','1','Y'),
('admin','48','241','Y'),
('admin','49','1','Y'),
('admin','49','232','Y'),
('admin','49','247','Y'),
('admin','50','1','Y'),
('admin','51','1','Y'),
('admin','52','1','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','55','1','Y'),
('admin','57','1','Y'),
('admin','58','1','Y'),
('admin','59','1','Y'),
('admin','60','1','Y'),
('admin','61','1','Y'),
('admin','61','255','Y'),
('admin','61','256','Y'),
('admin','61','257','Y'),
('admin','61','260','Y'),
('admin','61','261','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('admin','61','262','Y'),
('admin','61','263','Y'),
('admin','63','1','Y'),
('admin','64','1','Y'),
('cashier','1','1','Y'),
('cashier','1','34','Y'),
('cashier','1','35','Y'),
('cashier','1','36','Y'),
('cashier','1','37','Y'),
('cashier','1','38','Y'),
('cashier','1','39','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','1','40','Y'),
('cashier','1','41','Y'),
('cashier','1','42','Y'),
('cashier','1','43','Y'),
('cashier','1','44','Y'),
('cashier','1','45','Y'),
('cashier','1','46','Y'),
('cashier','1','47','Y'),
('cashier','1','48','Y'),
('cashier','1','69','Y'),
('cashier','1','82','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','1','83','Y'),
('cashier','1','85','Y'),
('cashier','1','88','Y'),
('cashier','1','89','Y'),
('cashier','1','90','Y'),
('cashier','1','91','Y'),
('cashier','1','92','Y'),
('cashier','1','93','Y'),
('cashier','1','95','Y'),
('cashier','1','96','Y'),
('cashier','1','97','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','1','98','Y'),
('cashier','1','99','Y'),
('cashier','1','101','Y'),
('cashier','1','102','Y'),
('cashier','1','108','Y'),
('cashier','1','121','Y'),
('cashier','1','122','Y'),
('cashier','1','123','Y'),
('cashier','1','155','Y'),
('cashier','1','197','Y'),
('cashier','1','199','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','1','211','Y'),
('cashier','1','253','Y'),
('cashier','6','1','Y'),
('cashier','6','26','Y'),
('cashier','6','27','Y'),
('cashier','6','28','Y'),
('cashier','6','29','Y'),
('cashier','6','30','Y'),
('cashier','6','31','Y'),
('cashier','6','59','Y'),
('cashier','6','185','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','6','188','Y'),
('cashier','6','246','Y'),
('cashier','8','1','Y'),
('cashier','8','62','Y'),
('cashier','8','63','Y'),
('cashier','8','64','Y'),
('cashier','11','1','Y'),
('cashier','18','1','Y'),
('cashier','18','114','Y'),
('cashier','18','115','Y'),
('cashier','18','117','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','18','118','Y'),
('cashier','18','120','Y'),
('cashier','18','145','Y'),
('cashier','18','146','Y'),
('cashier','18','156','Y'),
('cashier','18','157','Y'),
('cashier','18','159','Y'),
('cashier','18','160','Y'),
('cashier','18','161','Y'),
('cashier','18','166','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','18','167','Y'),
('cashier','18','168','Y'),
('cashier','18','169','Y'),
('cashier','18','170','Y'),
('cashier','18','172','Y'),
('cashier','18','173','Y'),
('cashier','18','187','Y'),
('cashier','18','248','Y'),
('cashier','19','1','Y'),
('cashier','19','144','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','20','1','Y'),
('cashier','20','147','Y'),
('cashier','24','1','Y'),
('cashier','24','148','Y'),
('cashier','25','1','Y'),
('cashier','25','149','Y'),
('cashier','25','152','Y'),
('cashier','25','153','Y'),
('cashier','26','1','Y'),
('cashier','27','1','Y'),
('cashier','28','1','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','28','150','Y'),
('cashier','29','1','Y'),
('cashier','30','1','Y'),
('cashier','32','1','Y'),
('cashier','36','1','Y'),
('cashier','36','162','Y'),
('cashier','36','163','Y'),
('cashier','37','1','Y'),
('cashier','38','1','Y'),
('cashier','38','164','Y'),
('cashier','38','165','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('cashier','38','186','Y'),
('cashier','38','200','Y'),
('cashier','38','224','Y'),
('cashier','38','235','Y'),
('cashier','38','249','Y'),
('cashier','49','1','Y'),
('cashier','49','232','Y'),
('cashier','49','247','Y'),
('manager','1','1','Y'),
('manager','1','3','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','1','11','Y'),
('manager','1','13','Y'),
('manager','1','14','Y'),
('manager','1','15','Y'),
('manager','1','16','Y'),
('manager','1','17','Y'),
('manager','1','18','Y'),
('manager','1','19','Y'),
('manager','1','20','Y'),
('manager','1','21','Y'),
('manager','1','22','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','1','23','Y'),
('manager','1','24','Y'),
('manager','1','25','Y'),
('manager','1','34','Y'),
('manager','1','35','Y'),
('manager','1','36','Y'),
('manager','1','37','Y'),
('manager','1','38','Y'),
('manager','1','39','Y'),
('manager','1','40','Y'),
('manager','1','41','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','1','42','Y'),
('manager','1','43','Y'),
('manager','1','44','Y'),
('manager','1','45','Y'),
('manager','1','46','Y'),
('manager','1','47','Y'),
('manager','1','48','Y'),
('manager','1','69','Y'),
('manager','1','71','Y'),
('manager','1','72','Y'),
('manager','1','82','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','1','83','Y'),
('manager','1','85','Y'),
('manager','1','88','Y'),
('manager','1','89','Y'),
('manager','1','90','Y'),
('manager','1','91','Y'),
('manager','1','92','Y'),
('manager','1','93','Y'),
('manager','1','95','Y'),
('manager','1','96','Y'),
('manager','1','97','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','1','98','Y'),
('manager','1','99','Y'),
('manager','1','101','Y'),
('manager','1','102','Y'),
('manager','1','107','Y'),
('manager','1','108','Y'),
('manager','1','109','Y'),
('manager','1','121','Y'),
('manager','1','122','Y'),
('manager','1','123','Y'),
('manager','1','154','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','1','155','Y'),
('manager','1','189','Y'),
('manager','1','193','Y'),
('manager','1','194','Y'),
('manager','1','195','Y'),
('manager','1','196','Y'),
('manager','1','197','Y'),
('manager','1','198','Y'),
('manager','1','199','Y'),
('manager','1','208','Y'),
('manager','1','211','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','1','212','Y'),
('manager','1','221','Y'),
('manager','1','222','Y'),
('manager','1','223','Y'),
('manager','1','233','Y'),
('manager','1','240','Y'),
('manager','1','253','Y'),
('manager','2','1','Y'),
('manager','2','4','Y'),
('manager','2','5','Y'),
('manager','2','6','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','2','32','Y'),
('manager','2','49','Y'),
('manager','2','50','Y'),
('manager','2','51','Y'),
('manager','2','52','Y'),
('manager','2','53','Y'),
('manager','2','54','Y'),
('manager','2','55','Y'),
('manager','2','56','Y'),
('manager','2','57','Y'),
('manager','2','70','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','2','75','Y'),
('manager','2','76','Y'),
('manager','2','77','Y'),
('manager','2','78','Y'),
('manager','2','79','Y'),
('manager','2','80','Y'),
('manager','2','81','Y'),
('manager','2','84','Y'),
('manager','2','87','Y'),
('manager','2','94','Y'),
('manager','2','100','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','2','103','Y'),
('manager','2','104','Y'),
('manager','2','105','Y'),
('manager','2','106','Y'),
('manager','2','110','Y'),
('manager','2','111','Y'),
('manager','2','124','Y'),
('manager','2','227','Y'),
('manager','2','228','Y'),
('manager','2','229','Y'),
('manager','2','230','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','2','236','Y'),
('manager','2','237','Y'),
('manager','2','238','Y'),
('manager','2','239','Y'),
('manager','2','242','Y'),
('manager','2','243','Y'),
('manager','2','244','Y'),
('manager','2','245','Y'),
('manager','3','1','Y'),
('manager','3','66','Y'),
('manager','3','67','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','3','68','Y'),
('manager','3','113','Y'),
('manager','3','128','Y'),
('manager','3','129','Y'),
('manager','3','130','Y'),
('manager','3','131','Y'),
('manager','3','203','Y'),
('manager','3','206','Y'),
('manager','6','1','Y'),
('manager','6','26','Y'),
('manager','6','27','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','6','28','Y'),
('manager','6','29','Y'),
('manager','6','30','Y'),
('manager','6','31','Y'),
('manager','6','59','Y'),
('manager','6','185','Y'),
('manager','6','188','Y'),
('manager','6','246','Y'),
('manager','8','1','Y'),
('manager','8','62','Y'),
('manager','8','63','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','8','64','Y'),
('manager','9','1','Y'),
('manager','9','7','Y'),
('manager','9','8','Y'),
('manager','9','9','Y'),
('manager','9','10','Y'),
('manager','10','1','Y'),
('manager','10','60','Y'),
('manager','10','143','Y'),
('manager','11','1','Y'),
('manager','12','1','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','14','1','Y'),
('manager','15','1','Y'),
('manager','15','125','Y'),
('manager','15','126','Y'),
('manager','16','1','Y'),
('manager','16','112','Y'),
('manager','17','1','Y'),
('manager','18','1','Y'),
('manager','18','114','Y'),
('manager','18','115','Y'),
('manager','18','116','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','18','117','Y'),
('manager','18','118','Y'),
('manager','18','119','Y'),
('manager','18','120','Y'),
('manager','18','145','Y'),
('manager','18','146','Y'),
('manager','18','156','Y'),
('manager','18','157','Y'),
('manager','18','159','Y'),
('manager','18','160','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','18','161','Y'),
('manager','18','166','Y'),
('manager','18','167','Y'),
('manager','18','168','Y'),
('manager','18','169','Y'),
('manager','18','170','Y'),
('manager','18','171','Y'),
('manager','18','172','Y'),
('manager','18','173','Y'),
('manager','18','187','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','18','234','Y'),
('manager','18','248','Y'),
('manager','19','1','Y'),
('manager','19','144','Y'),
('manager','20','1','Y'),
('manager','20','147','Y'),
('manager','21','1','Y'),
('manager','23','1','Y'),
('manager','24','1','Y'),
('manager','24','148','Y'),
('manager','25','1','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','25','149','Y'),
('manager','25','152','Y'),
('manager','25','153','Y'),
('manager','26','1','Y'),
('manager','27','1','Y'),
('manager','28','1','Y'),
('manager','28','150','Y'),
('manager','29','1','Y'),
('manager','30','1','Y'),
('manager','31','1','Y'),
('manager','31','151','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','32','1','Y'),
('manager','33','1','Y'),
('manager','33','158','Y'),
('manager','34','1','Y'),
('manager','35','1','Y'),
('manager','36','1','Y'),
('manager','36','162','Y'),
('manager','36','163','Y'),
('manager','36','252','Y'),
('manager','37','1','Y'),
('manager','38','1','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','38','164','Y'),
('manager','38','165','Y'),
('manager','38','174','Y'),
('manager','38','186','Y'),
('manager','38','200','Y'),
('manager','38','224','Y'),
('manager','38','235','Y'),
('manager','38','249','Y'),
('manager','39','1','Y'),
('manager','39','175','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','39','176','Y'),
('manager','39','177','Y'),
('manager','39','178','Y'),
('manager','40','1','Y'),
('manager','40','181','Y'),
('manager','40','182','Y'),
('manager','40','183','Y'),
('manager','40','184','Y'),
('manager','40','204','Y'),
('manager','40','207','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','41','1','Y'),
('manager','42','1','Y'),
('manager','42','190','Y'),
('manager','42','191','Y'),
('manager','42','192','Y'),
('manager','42','201','Y'),
('manager','42','202','Y'),
('manager','42','205','Y'),
('manager','43','1','Y'),
('manager','43','213','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','44','1','Y'),
('manager','44','214','Y'),
('manager','45','1','Y'),
('manager','46','1','Y'),
('manager','48','1','Y'),
('manager','48','241','Y'),
('manager','49','1','Y'),
('manager','49','232','Y'),
('manager','49','247','Y'),
('manager','50','1','Y'),
('manager','51','1','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','52','1','Y'),
('manager','55','1','Y'),
('manager','57','1','Y'),
('manager','58','1','Y'),
('manager','59','1','Y'),
('manager','61','1','Y'),
('manager','61','255','Y'),
('manager','61','256','Y'),
('manager','61','257','Y'),
('manager','61','260','Y'),
('manager','61','261','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('manager','61','262','Y'),
('manager','61','263','Y'),
('manager','63','1','Y'),
('manager','64','1','Y'),
('steward1','1','1','Y'),
('steward1','1','34','Y'),
('steward1','1','35','Y'),
('steward1','1','36','Y'),
('steward1','1','37','Y'),
('steward1','1','38','Y'),
('steward1','1','39','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('steward1','1','40','Y'),
('steward1','1','41','Y'),
('steward1','1','42','Y'),
('steward1','1','43','Y'),
('steward1','1','44','Y'),
('steward1','1','45','Y'),
('steward1','1','46','Y'),
('steward1','1','47','Y'),
('steward1','1','48','Y'),
('steward1','1','69','Y'),
('steward1','1','82','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('steward1','1','83','Y'),
('steward1','1','85','Y'),
('steward1','1','88','Y'),
('steward1','1','89','Y'),
('steward1','1','90','Y'),
('steward1','1','91','Y'),
('steward1','1','92','Y'),
('steward1','1','93','Y'),
('steward1','1','95','Y'),
('steward1','1','96','Y'),
('steward1','1','97','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('steward1','1','98','Y'),
('steward1','1','99','Y'),
('steward1','1','101','Y'),
('steward1','1','102','Y'),
('steward1','1','108','Y'),
('steward1','1','121','Y'),
('steward1','1','122','Y'),
('steward1','1','123','Y'),
('steward1','1','155','Y'),
('steward1','1','197','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('steward1','1','199','Y'),
('steward1','1','211','Y'),
('steward1','6','1','Y'),
('steward1','6','26','Y'),
('steward1','6','27','Y'),
('steward1','6','28','Y'),
('steward1','6','29','Y'),
('steward1','6','30','Y'),
('steward1','6','31','Y'),
('steward1','6','59','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('steward1','6','185','Y'),
('steward1','6','188','Y'),
('steward1','6','246','Y'),
('steward1','8','1','Y'),
('steward1','8','62','Y'),
('steward1','8','63','Y'),
('steward1','8','64','Y'),
('steward1','11','1','Y'),
('steward1','18','1','Y'),
('steward1','18','114','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('steward1','18','117','Y'),
('steward1','18','118','Y'),
('steward1','18','145','Y'),
('steward1','18','157','Y'),
('steward1','18','166','Y'),
('steward1','18','167','Y'),
('steward1','18','168','Y'),
('steward1','18','169','Y'),
('steward1','18','170','Y'),
('steward1','18','173','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('steward1','18','248','Y'),
('steward1','24','1','Y'),
('steward1','24','148','Y'),
('steward1','34','1','Y'),
('steward1','36','1','Y'),
('steward1','36','162','Y'),
('steward1','37','1','Y'),
('steward1','38','1','Y'),
('steward1','38','164','Y'),
('steward1','38','165','Y'); 
INSERT INTO `tbl_usermodules` VALUES ('steward1','38','224','Y'),
('steward1','38','249','Y'); 


DROP TABLE IF EXISTS `tbl_vendor_master`;
CREATE TABLE `tbl_vendor_master` (
  `v_id` int(11) NOT NULL AUTO_INCREMENT,
  `v_name` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `v_branchid` bigint(20) NOT NULL,
  `v_address` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_city` int(11) DEFAULT NULL,
  `v_state` int(11) DEFAULT NULL,
  `v_country` int(11) DEFAULT NULL,
  `v_email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_contact_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_open_bal` decimal(15,3) DEFAULT NULL,
  `v_tin_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gst` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_srvctax_reg_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_pan` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_bank_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_branch_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_acct_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_ifsc` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_mode_of_pay` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_credit_period` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_favour` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_conc_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_conc_desg` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_conc_contact` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_conc_email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `v_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `v_entry_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `v_entry_date` date DEFAULT NULL,
  `central_created` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_in_local` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `central_edited` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  PRIMARY KEY (`v_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;



DROP TABLE IF EXISTS `tbl_version`;
CREATE TABLE `tbl_version` (
  `pv_current_version` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pv_date_of_change` date NOT NULL,
  `pv_time_of_change` time NOT NULL,
  `pv_expodine_staff_by` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pv_apk_ver_name` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pv_apk_ver_code` int(11) DEFAULT NULL,
  `pve_apk_ver_name` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pve_apk_ver_code` int(11) DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `payment_overdue` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`pv_current_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_version` VALUES ('7.4','2026-04-20','11:13:56','Fresh-Installation','5.2.8','38',NULL,NULL,'N','N'); 


DROP TABLE IF EXISTS `tbl_version_log`;
CREATE TABLE `tbl_version_log` (
  `vl_old_version` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `vl_old_date_of change` date NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`vl_old_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_version_log` VALUES ('7.4','2026-04-20','N'); 


DROP TABLE IF EXISTS `tbl_voucher_delete_log`;
CREATE TABLE `tbl_voucher_delete_log` (
  `tvd_id` int(11) NOT NULL AUTO_INCREMENT,
  `tvd_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tvd_data` varchar(5000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tvd_date` datetime DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tv_cloud_id_deleted` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tv_deleted_local` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tvd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_voucherhead`;
CREATE TABLE `tbl_voucherhead` (
  `vh_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `vh_vouchername` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `vh_active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `vh_branchid` bigint(20) NOT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`vh_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_voucherpayment`;
CREATE TABLE `tbl_voucherpayment` (
  `vp_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `vp_vhid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `vp_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `vp_date` datetime DEFAULT NULL,
  `vp_paymentmode` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_paidto` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_chequebank` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_chequebranch` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_chequeleafno` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_receivedby` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_branchid` bigint(20) DEFAULT NULL,
  `vp_status` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_remarks` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_approveddate` datetime DEFAULT NULL,
  `vp_approvedby` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Expense',
  `vp_voucherno` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_add_remark` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vp_system_ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `vp_dayclose_date` date DEFAULT NULL,
  PRIMARY KEY (`vp_id`),
  KEY `vp_approvedby` (`vp_approvedby`),
  CONSTRAINT `tbl_voucherpayment_staffid` FOREIGN KEY (`vp_approvedby`) REFERENCES `tbl_staffmaster` (`ser_staffid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;



DROP TABLE IF EXISTS `tbl_wastage`;
CREATE TABLE `tbl_wastage` (
  `tw_id` int(11) NOT NULL AUTO_INCREMENT,
  `tw_wastage_id` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tw_product` int(11) DEFAULT NULL,
  `tw_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tw_barcode` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tw_qty` decimal(15,3) DEFAULT NULL,
  `tw_weight` decimal(15,3) DEFAULT NULL,
  `tw_rate_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tw_unit_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tw_rate` decimal(15,3) DEFAULT NULL,
  `tw_total` decimal(15,3) DEFAULT NULL,
  `tw_set` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `tw_date` date DEFAULT NULL,
  `tw_login` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tw_store` int(11) DEFAULT NULL,
  `tw_brand` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tw_current_stock` decimal(15,3) DEFAULT NULL,
  `tw_reason` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tw_central_return` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tw_item_central_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tw_id`),
  UNIQUE KEY `tw_wastage_id` (`tw_wastage_id`,`tw_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `tbl_year_bill_series`;
CREATE TABLE `tbl_year_bill_series` (
  `b_fin_year` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `b_series` int(11) NOT NULL,
  `b_count` int(11) NOT NULL DEFAULT '1',
  `b_alpahabet` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`b_fin_year`,`b_series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `tbl_year_bill_series` VALUES ('2627','1','1','A','N'); 


DROP TABLE IF EXISTS `tbl_yearsettings`;
CREATE TABLE `tbl_yearsettings` (
  `ys_fin_year` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `ys_fin_year_current` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ys_fin_year_start` date NOT NULL,
  `ys_fin_year_end` date NOT NULL,
  `ys_function_count` int(11) NOT NULL DEFAULT '1',
  `ys_function_invoice` int(11) NOT NULL DEFAULT '1',
  `cloud_sync` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ys_fin_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_yearsettings` VALUES ('2627','Y','2026-04-20','2027-03-31','1','1','N'); 


DROP TABLE IF EXISTS `temp_loyalty_reg`;
CREATE TABLE `temp_loyalty_reg` (
  `ly_id` int(11) NOT NULL AUTO_INCREMENT,
  `ly_firstname` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `ly_lastname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_gender` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_mobileno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_emailid` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_birthdaydate` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_maritalstatus` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_anniversarydate` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_profession` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ly_totalvisit` int(11) NOT NULL DEFAULT '1',
  `ly_mailreceive` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ly_smsreceive` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ly_entrydatetime` datetime DEFAULT NULL,
  `ly_branchid` int(11) DEFAULT NULL,
  `ly_status` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `ly_entry_from` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Credit',
  `ly_points` int(11) DEFAULT NULL,
  `ly_voucher_count` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ly_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;





/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

